import datetime as dt
from fastapi.testclient import TestClient
from app.main import app
from app import models
from app.services import similarity, gamification, analytics, contests as csvc
from conftest import make_user, client_for

GOOD = "a,b=map(int,input().split())\nprint(a+b)\n"
BAD = "a,b=map(int,input().split())\nprint(a-b)\n"


def post_submit(c, slug, code, lang="python", contest=""):
    return c.post(f"/problems/{slug}/submit", data={"language": lang, "source_code": code, "contest": contest})


# ---------------------------------------------------------------- auth / security
def test_pages_public():
    c = TestClient(app)
    for u in ("/", "/login", "/register", "/problems", "/student", "/health"):
        assert c.get(u).status_code == 200, u


def test_register_password_policy_and_login():
    c = TestClient(app, follow_redirects=False)
    r = c.post("/register", data={"username": "weak", "email": "w@t.io", "password": "abc"})
    assert r.status_code == 400
    r = c.post("/register", data={"username": "newbie", "email": "newbie@t.io", "password": "Str0ngPass!"})
    assert r.status_code == 303 and "judge_session" in r.headers.get("set-cookie", "")
    assert "httponly" in r.headers["set-cookie"].lower() and "samesite=lax" in r.headers["set-cookie"].lower()
    assert c.get("/dashboard").status_code == 200


def test_login_wrong_password(db):
    make_user(db, "lg")
    c = TestClient(app, follow_redirects=False)
    assert c.post("/login", data={"email": "lg@t.io", "password": "nope"}).status_code == 400


def test_csrf_cross_origin_blocked(db):
    make_user(db, "csrf")
    c = client_for("csrf")
    r = c.post("/judge/run", json={"language": "python", "source_code": "print(1)"},
               headers={"Origin": "http://evil.example"})
    assert r.status_code == 403


def test_rate_limit_login(db):
    c = TestClient(app, follow_redirects=False)
    codes = [c.post("/login", data={"email": "x@t.io", "password": "y"}).status_code for _ in range(13)]
    assert 429 in codes and codes[0] == 400


def test_auth_required_for_run_and_ai():
    c = TestClient(app)
    assert c.post("/judge/run", json={"language": "python", "source_code": "print(1)"}).status_code == 401
    assert c.post("/ai/review", json={"source_code": "x"}).status_code == 401
    assert c.post("/api/hint", json={}).status_code == 401


def test_extensions_admin_only(db):
    make_user(db, "stud1")
    c = client_for("stud1")
    r = c.post("/extensions/install", data={"language": "python", "name": "requests"})
    assert r.status_code == 403
    assert "Extensions" not in c.get("/dashboard").text


def test_authorization_staff_pages(db):
    make_user(db, "stud2")
    c = client_for("stud2")
    assert c.get("/faculty").status_code in (303, 403) or c.get("/faculty").headers.get("location") == "/login"
    assert c.get("/faculty/reports/class.pdf").status_code == 403
    assert c.post("/admin/users/1/delete").status_code == 303   # redirected to login, not executed


def test_custom_run_and_validation(db):
    make_user(db, "runner")
    c = client_for("runner")
    r = c.post("/judge/run", json={"language": "python", "source_code": "print(int(input())*2)", "stdin": "21"})
    assert r.json()["status"] == "OK" and r.json()["stdout"].strip() == "42"
    assert c.post("/judge/run", json={"language": "ruby", "source_code": "x"}).status_code == 422
    r = c.post("/judge/run", json={"language": "python", "source_code": "import os\nos.system('id')"})
    assert r.json()["status"] == "SECURITY_VIOLATION"
    assert c.post("/judge/run", content="not json", headers={"content-type": "application/json"}).status_code == 400


# ------------------------------------------------------------------ judging
def test_all_languages_judge(db, problem):
    make_user(db, "poly")
    c = client_for("poly")
    code = {
        "python": GOOD,
        "c": '#include <stdio.h>\nint main(){int a,b;scanf("%d %d",&a,&b);printf("%d\\n",a+b);}',
        "cpp": '#include <iostream>\nint main(){int a,b;std::cin>>a>>b;std::cout<<a+b<<"\\n";}',
        "java": 'import java.util.*;public class Solution{public static void main(String[] x){Scanner s=new Scanner(System.in);System.out.println(s.nextInt()+s.nextInt());}}',
    }
    for lang, src in code.items():
        r = post_submit(c, "add-two", src, lang)
        assert r.status_code == 303, lang
        sub = db.query(models.Submission).order_by(models.Submission.id.desc()).first()
        db.refresh(sub)
        assert sub.verdict == "Accepted" and sub.score == 100 and sub.passed_cases == 4, (lang, sub.verdict, sub.error_message)


def test_wrong_answer_does_not_leak_hidden(db, problem):
    make_user(db, "wa")
    c = client_for("wa")
    # passes public cases (1+2, 5+7) by coincidence but fails hidden
    sneaky = "a,b=map(int,input().split())\nprint(3 if (a,b)==(1,2) else 12 if (a,b)==(5,7) else 1)\n"
    post_submit(c, "add-two", sneaky)
    sub = db.query(models.Submission).filter_by(user_id=db.query(models.User).filter_by(username="wa").one().id).one()
    assert sub.verdict == "Wrong Answer" and sub.passed_cases == 2 and sub.score == 50
    assert "hidden test case" in sub.error_message
    assert "300" not in sub.error_message and "100 200" not in sub.error_message
    page = c.get(f"/submissions/{sub.id}")
    assert page.status_code == 200 and "300" not in page.text.split("Your Code")[0]


def test_tle_and_compile_error(db, problem):
    make_user(db, "bad")
    c = client_for("bad")
    post_submit(c, "add-two", "while True: pass")
    post_submit(c, "add-two", "int main(){ nope(); }", "cpp")
    uid = db.query(models.User).filter_by(username="bad").one().id
    verdicts = [s.verdict for s in db.query(models.Submission).filter_by(user_id=uid).order_by(models.Submission.id)]
    assert verdicts == ["Time Limit Exceeded", "Compilation Error"]


def test_run_samples_public_only(db, problem):
    make_user(db, "samp")
    c = client_for("samp")
    d = c.post("/api/problems/add-two/run-samples", json={"language": "python", "source_code": GOOD}).json()
    assert d["verdict"] == "Accepted" and d["total_cases"] == 2
    d = c.post("/api/problems/add-two/run-samples", json={"language": "python", "source_code": BAD}).json()
    assert d["verdict"] == "Wrong Answer" and d["case_results"][0]["expected"] == "3"


def test_submission_privacy(db, problem):
    make_user(db, "own1"); make_user(db, "own2")
    c1 = client_for("own1"); post_submit(c1, "add-two", GOOD)
    sid = db.query(models.Submission).order_by(models.Submission.id.desc()).first().id
    assert client_for("own2").get(f"/submissions/{sid}").status_code == 303
    assert TestClient(app, follow_redirects=False).get(f"/submissions/{sid}").status_code == 303


# ------------------------------------------------------- gamification / learning
def test_xp_badges_streak_heatmap(db, problem):
    u = make_user(db, "gam")
    c = client_for("gam"); post_submit(c, "add-two", GOOD)
    db.refresh(u)
    assert u.xp >= 25 and any(b["key"] == "first_solve" for b in gamification.user_badges(db, u.id))
    xp = u.xp
    post_submit(c, "add-two", GOOD); db.refresh(u)
    assert u.xp == xp                       # no double XP for the same problem/day
    assert gamification.streak_days(db, u.id)[0] == 1
    assert sum(cell["count"] for col in gamification.heatmap(db, u.id) for cell in col if cell) >= 2
    page = c.get("/dashboard").text
    assert "First Blood" in page and "Global rank" in page


def test_weakness_roadmap_recommendation(db, problem):
    u = make_user(db, "weak")
    c = client_for("weak")
    for _ in range(4):
        post_submit(c, "add-two", BAD)
    st = {t["topic"]: t for t in analytics.topic_stats(db, u.id)}
    assert st["Math"]["status"] == "Weak" and st["Math"]["accuracy"] == 0
    assert any(i["verdict"] == "Wrong Answer" for i in analytics.error_insights(db, u.id))
    rm = analytics.build_roadmap(db, u.id)
    assert rm[0]["topic"] == "Math" and rm[0]["state"] == "current"
    assert any(r["problem"].slug == "add-two" for r in analytics.recommend_problems(db, u.id))
    assert c.get("/learn").status_code == 200 and "Weak" in c.get("/learn").text


def test_hint_tutor_lines(db, problem):
    make_user(db, "tut")
    c = client_for("tut")
    for lvl in (1, 2, 3):
        d = c.post("/api/hint", json={"slug": "add-two", "level": lvl, "source_code": BAD, "language": "python"}).json()
        assert d["hint"] and d["level"] == lvl
    assert c.post("/api/hint", json={"slug": "add-two", "level": 9}).status_code == 422
    d = c.post("/api/tutor", json={"slug": "add-two", "message": "why is my code wrong?", "source_code": BAD}).json()
    assert d["reply"]
    assert len(c.get("/api/tutor/history?slug=add-two").json()["messages"]) == 2
    d = c.post("/ai/explain-lines", json={"language": "python", "source_code": GOOD}).json()
    assert len(d["items"]) == 2 and "input" in d["items"][0]["explanation"].lower()
    assert c.post("/api/tutor", json={"message": ""}).status_code == 422


# ------------------------------------------------------------------- similarity
def test_plagiarism_detection(db, problem):
    make_user(db, "orig"); make_user(db, "copy"); make_user(db, "diff")
    long_orig = ("n=int(input())\narr=list(map(int,input().split()))\ntotal=0\nfor x in arr:\n    if x>0:\n        total+=x\n"
                 "    else:\n        total-=x\nprint(total)\n")
    long_copy = ("# mine\ncount=int(input())\nnums=list(map(int,input().split()))\ns=0\nfor v in nums:\n    if v>0:\n        s+=v\n"
                 "    else:\n        s-=v  # abs\nprint(s)\n")
    other = "import sys\nd=sys.stdin.read().split()\nprint(sum(abs(int(t)) for t in d[1:]))\n"
    for name, src in (("orig", long_orig), ("copy", long_copy), ("diff", other)):
        post_submit(client_for(name), "add-two", src)
    uid = {n: db.query(models.User).filter_by(username=n).one().id for n in ("orig", "copy", "diff")}
    sub = lambda n: db.query(models.Submission).filter_by(user_id=uid[n]).order_by(models.Submission.id.desc()).first()
    db.expire_all()
    assert sub("copy").similarity_score >= 80 and sub("diff").similarity_score < 40
    assert db.query(models.SimilarityReport).filter_by(user_id=uid["copy"], other_user_id=uid["orig"]).count() == 1


# --------------------------------------------------------------------- contests
def test_contest_lifecycle(db, problem):
    admin = make_user(db, "boss", "admin"); make_user(db, "c1"); make_user(db, "c2")
    ca = client_for("boss")
    now = dt.datetime.utcnow()
    local = lambda t: t.strftime("%Y-%m-%dT%H:%M")
    r = ca.post("/admin/contests/create", data={"title": "Test Cup", "description": "d", "start_time": local(now - dt.timedelta(minutes=5)),
                "end_time": local(now + dt.timedelta(hours=1)), "tz_offset": 0, "penalty_minutes": 10, "problem_ids": str(problem.id)})
    assert r.status_code == 303
    c = db.query(models.Contest).filter_by(slug="test-cup").one()
    assert csvc.status(c) == "running" and len(c.problems) == 1
    s1, s2 = client_for("c1"), client_for("c2")
    assert s1.get("/contests/test-cup").status_code == 200
    s1.post("/contests/test-cup/join")
    post_submit(s1, "add-two", BAD, contest="test-cup")
    post_submit(s1, "add-two", GOOD, contest="test-cup")
    post_submit(s2, "add-two", BAD, contest="test-cup")
    db.expire_all()
    lb = csvc.leaderboard(db, c)
    assert [r["user"].username for r in lb][:2] == ["c1", "c2"] and lb[0]["points"] == 100 and lb[0]["solved"] == 1
    assert lb[0]["penalty"] >= 10                       # one wrong attempt before AC
    d = s2.get("/api/contests/test-cup/leaderboard").json()
    assert d["status"] == "running" and d["rows"][0]["username"] == "c1" and d["seconds_left"] > 0
    # outside-contest problem rejected, ended contest rejected
    assert post_submit(s1, "add-two", GOOD, contest="nope").status_code == 403
    c.end_time = now - dt.timedelta(minutes=1); db.commit()
    assert post_submit(s1, "add-two", GOOD, contest="test-cup").status_code == 403
    assert s1.get("/contests").status_code == 200 and "Test Cup" in s1.get("/contests").text
    hist = csvc.user_history(db, db.query(models.User).filter_by(username="c1").one())
    assert hist and hist[0]["rank"] == 1


def test_upcoming_contest_hides_problems(db, problem):
    make_user(db, "boss"); make_user(db, "early")
    now = dt.datetime.utcnow()
    c = models.Contest(title="Future", slug="future", start_time=now + dt.timedelta(hours=2), end_time=now + dt.timedelta(hours=3))
    db.add(c); db.commit()
    db.add(models.ContestProblem(contest_id=c.id, problem_id=problem.id)); db.commit()
    s = client_for("early")
    assert "Problems are revealed" in s.get("/contests/future").text
    assert s.get("/problems/add-two?contest=future").status_code == 303


# --------------------------------------------------------------- faculty / admin
def test_faculty_analytics_and_pdfs(db, problem):
    make_user(db, "prof", "faculty")
    f = client_for("prof")
    assert f.get("/faculty").status_code == 200
    uid = db.query(models.User).filter_by(username="weak").one().id
    assert f.get(f"/faculty/students/{uid}").status_code == 200
    r = f.get("/faculty/reports/class.pdf"); assert r.status_code == 200 and r.content[:4] == b"%PDF"
    r = f.get(f"/faculty/reports/student/{uid}.pdf"); assert r.status_code == 200 and r.content[:4] == b"%PDF"
    assert f.get("/faculty/plagiarism").status_code == 200
    rep = db.query(models.SimilarityReport).first()
    assert f.get(f"/faculty/plagiarism/{rep.id}").status_code == 200
    assert f.get("/admin").status_code == 200
    assert f.post("/admin/users/1/role", data={"role": "admin"}).status_code == 303   # redirect to login: not admin
    ov = analytics.class_overview(db)
    assert ov["students"] >= 1 and ov["topics"]


def test_admin_problem_and_testcase_management(db):
    make_user(db, "boss", "admin")
    a = client_for("boss")
    assert a.get("/admin").status_code == 200 and a.get("/extensions").status_code == 200
    r = a.post("/admin/problems/create", data={"title": "New One", "description": "d", "difficulty": "Hard", "topic": "Graphs", "points": 200})
    assert r.status_code == 303
    p = db.query(models.Problem).filter_by(slug="new-one").one()
    a.post(f"/admin/problems/{p.id}/add-testcase", data={"input_data": "1", "expected_output": "1", "weight": 3})
    assert a.get(f"/admin/problems/{p.id}/tests").status_code == 200
    db.expire_all(); tc = p.test_cases[0]; assert tc.weight == 3 and not tc.is_sample
    a.post(f"/admin/testcases/{tc.id}/update", data={"input_data": "2", "expected_output": "2", "is_sample": "true", "weight": 1})
    db.expire_all(); assert db.get(models.TestCase, tc.id).is_sample is True
    assert a.post("/admin/problems/create", data={"title": "x", "description": "d", "difficulty": "Nope"}).status_code == 422
    a.post(f"/admin/problems/{p.id}/update", data={"title": "New One", "description": "d", "difficulty": "Hard", "topic": "Graphs", "points": 200})
    db.expire_all(); assert db.get(models.Problem, p.id).is_published is False     # unchecked box => hidden
    assert "new-one" not in a.get("/problems").text                                     # unpublished hidden from students list
    a.post(f"/admin/problems/{p.id}/delete")
    db.expire_all(); assert db.query(models.Problem).filter_by(slug="new-one").first() is None


def test_error_pages_and_ui_pages(db):
    make_user(db, "ui")
    c = client_for("ui")
    r = c.get("/problems/does-not-exist"); assert r.status_code == 303
    r = c.get("/u/ghost"); assert r.status_code == 404 and "Page not found" in r.text
    for u in ("/dashboard", "/leaderboard", "/profile", "/submissions", "/problems", "/learn", "/contests", "/student", "/u/ui"):
        resp = c.get(u, follow_redirects=True); assert resp.status_code == 200, u
        assert "themeToggle" in resp.text
    assert c.get("/problems/add-two").status_code == 200
