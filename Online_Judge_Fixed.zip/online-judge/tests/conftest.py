import os, sys, tempfile
_tmp = tempfile.mkdtemp()
os.environ["JUDGE_DATABASE_URL"] = f"sqlite:///{_tmp}/test.db"
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.database import SessionLocal
from app import models
from app.auth import hash_password
from app.security import reset_rate_limits


@pytest.fixture(autouse=True)
def _reset():
    reset_rate_limits()
    yield


@pytest.fixture(scope="session")
def db():
    s = SessionLocal()
    yield s
    s.close()


def make_user(db, name, role="student", pw="Passw0rd!x"):
    u = db.query(models.User).filter_by(username=name).first()
    if not u:
        u = models.User(username=name, email=f"{name}@t.io", hashed_password=hash_password(pw),
                        is_admin=(role == "admin"), role=role)
        db.add(u); db.commit()
    return u


def client_for(name, pw="Passw0rd!x"):
    c = TestClient(app, follow_redirects=False)
    r = c.post("/login", data={"email": f"{name}@t.io", "password": pw})
    assert r.status_code == 303, r.text
    return c


@pytest.fixture(scope="session")
def problem(db):
    p = models.Problem(title="Add Two", slug="add-two", description="Add two ints", difficulty="Easy", topic="Math",
                       points=100, starter_code="")
    db.add(p); db.commit()
    for i, o, pub in [("1 2", "3", True), ("5 7", "12", True), ("100 200", "300", False), ("-4 4", "0", False)]:
        db.add(models.TestCase(problem_id=p.id, input_data=i, expected_output=o, is_sample=pub))
    db.commit()
    return p
