import os
import json
from markupsafe import Markup
from fastapi.templating import Jinja2Templates

TEMPLATES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates")
templates = Jinja2Templates(directory=TEMPLATES_DIR)


def _tojson_filter(value):
    """Safely dump a Python value as a JSON literal for embedding in <script> blocks."""
    return Markup(json.dumps(value).replace("</", "<\\/"))


# Ensure `|tojson` works regardless of the installed Starlette/Jinja2 version's defaults.
templates.env.filters["tojson"] = _tojson_filter
