"""
Secure multi-language code executor (Python, C, C++, Java) using a hardened local sandbox:
scrubbed environment (no API keys / secrets leak to user code), rlimits (CPU, address space,
file size, open files, processes, core), separate session + process-group kill, network
namespace via `unshare -n` when the kernel allows it, stdout/stderr streamed to size-capped
files, and a static scan that rejects obviously malicious programs.
"""
import os
import re
import sys
import uuid
import shutil
import signal
import subprocess
import platform
import threading
import time
from dataclasses import dataclass

from app.config import (
    TEMP_RUN_DIR, EXECUTION_TIMEOUT_SECONDS, MEMORY_LIMIT_MB, MAX_OUTPUT_CHARS,
    MAX_SOURCE_BYTES, MAX_STDIN_BYTES, MAX_PROCESSES,
)

IS_LINUX = platform.system() == "Linux"
if IS_LINUX:
    import resource

MAX_OUTPUT_FILE_BYTES = 8 * 1024 * 1024
COMPILE_TIMEOUT = 20


@dataclass
class RunResult:
    # "OK" | "COMPILE_ERROR" | "RUNTIME_ERROR" | "TIMEOUT" | "MEMORY_LIMIT" | "SECURITY_VIOLATION" | "INTERNAL_ERROR"
    status: str
    stdout: str = ""
    stderr: str = ""
    runtime_ms: float = 0.0
    memory_kb: int = 0


# --------------------------------------------------------------- static scan --
_DENY = {
    "python": [
        (r"\bimport\s+(subprocess|socket|ctypes|multiprocessing|pty|signal|resource|shutil|requests|urllib|http|ftplib|smtplib|telnetlib|webbrowser)\b", "restricted module"),
        (r"\bfrom\s+(subprocess|socket|ctypes|multiprocessing|pty|shutil|requests|urllib|http)\b", "restricted module"),
        (r"\bos\s*\.\s*(system|popen|fork|forkpty|exec\w*|spawn\w*|kill|killpg|setuid|chroot|remove|unlink|rmdir|removedirs|rename|environ|getenv)\b", "restricted os call"),
        (r"__import__\s*\(", "dynamic import"),
        (r"\b(eval|exec|compile)\s*\(\s*(input|open|__import__)", "dynamic execution of external data"),
    ],
    "c": [
        (r"\b(system|popen|fork|vfork|execv\w*|execl\w*|execvp\w*|socket|connect|bind|listen|ptrace|kill|setuid|chroot)\s*\(", "restricted call"),
        (r"#\s*include\s*[<\"]\s*(/|\.\./|sys/socket|netinet|arpa|sys/ptrace|sys/mount|unistd\.h\s*>\s*\n.*fork)", "restricted include"),
        (r"\b__asm__|\basm\s*(volatile)?\s*\(", "inline assembly"),
        (r"#\s*(embed|include_next)\b", "restricted directive"),
    ],
    "java": [
        (r"\b(Runtime\s*\.\s*getRuntime|ProcessBuilder|java\s*\.\s*net|javax\s*\.\s*net|java\s*\.\s*lang\s*\.\s*reflect|java\s*\.\s*lang\s*\.\s*invoke|sun\s*\.\s*misc|System\s*\.\s*(getenv|setSecurityManager|load|loadLibrary)|java\s*\.\s*nio\s*\.\s*file\s*\.\s*Files|java\s*\.\s*io\s*\.\s*File(Writer|OutputStream)|ClassLoader)\b", "restricted API"),
    ],
}
_DENY["cpp"] = _DENY["c"]


def security_scan(language: str, source: str):
    """Returns a reason string if the source is rejected, else None."""
    lang = "cpp" if language in ("c++", "cpp") else language
    for pat, why in _DENY.get(lang, []):
        m = re.search(pat, source, re.MULTILINE)
        if m:
            return f"Blocked by security policy ({why}): '{m.group(0).strip()[:40]}'. This is not allowed in judged code."
    return None


# ------------------------------------------------------------------ helpers --
def _truncate(text: str) -> str:
    if text and len(text) > MAX_OUTPUT_CHARS:
        return text[:MAX_OUTPUT_CHARS] + "\n...[output truncated]"
    return text or ""


def _tool_available(name: str) -> bool:
    return shutil.which(name) is not None


_unshare_ok = None


def _netns_prefix():
    """['unshare','-rn'] when the kernel lets unprivileged users create a net namespace."""
    global _unshare_ok
    if _unshare_ok is None:
        _unshare_ok = False
        if IS_LINUX and _tool_available("unshare"):
            try:
                _unshare_ok = subprocess.run(["unshare", "-rn", "true"], capture_output=True, timeout=5).returncode == 0
            except Exception:
                _unshare_ok = False
    return ["unshare", "-rn"] if _unshare_ok else []


def sandbox_info() -> dict:
    return {"mode": "local", "network_isolation": bool(_netns_prefix()),
            "memory_limit_mb": MEMORY_LIMIT_MB, "timeout_s": EXECUTION_TIMEOUT_SECONDS}


def _safe_env():
    # Deliberately NOT inheriting os.environ: it holds SECRET_KEY / ANTHROPIC_API_KEY.
    if not IS_LINUX:
        # Windows/macOS: keep PATH (python, gcc, javac live there) but drop every secret.
        keep = ("PATH", "SYSTEMROOT", "SystemRoot", "TEMP", "TMP", "PATHEXT", "COMSPEC", "WINDIR", "JAVA_HOME")
        env = {k: v for k, v in os.environ.items() if k in keep}
        env["PYTHONIOENCODING"] = "utf-8"
        return env
    return {"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8", "HOME": "/tmp",
            "X": "1"}


def _make_limiter(mem_limit: bool, cpu_seconds: int):
    def _limit():
        os.setsid()
        if not IS_LINUX:
            return
        try:
            if mem_limit:
                b = MEMORY_LIMIT_MB * 1024 * 1024
                resource.setrlimit(resource.RLIMIT_AS, (b, b))
            resource.setrlimit(resource.RLIMIT_CPU, (cpu_seconds, cpu_seconds + 1))
            resource.setrlimit(resource.RLIMIT_FSIZE, (MAX_OUTPUT_FILE_BYTES, MAX_OUTPUT_FILE_BYTES))
            resource.setrlimit(resource.RLIMIT_NOFILE, (64, 64))
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
            resource.setrlimit(resource.RLIMIT_NPROC, (MAX_PROCESSES * 4, MAX_PROCESSES * 4))
        except Exception:
            pass
    return _limit


def _read_capped(path: str) -> str:
    try:
        with open(path, "rb") as f:
            data = f.read(MAX_OUTPUT_CHARS * 4 + 1)
        return _truncate(data.decode("utf-8", errors="replace"))
    except Exception:
        return ""


def _local_exec(cmd, cwd, stdin_data, timeout, mem_limit=True, net_isolate=True):
    """Run cmd; returns (returncode|None on timeout, stdout, stderr, elapsed_ms)."""
    out_p, err_p = os.path.join(cwd, ".stdout"), os.path.join(cwd, ".stderr")
    full = (_netns_prefix() if net_isolate else []) + list(cmd)
    start = time.perf_counter()
    with open(out_p, "wb") as fo, open(err_p, "wb") as fe:
        proc = subprocess.Popen(
            full, cwd=cwd, stdin=subprocess.PIPE, stdout=fo, stderr=fe, env=_safe_env(),
            preexec_fn=_make_limiter(mem_limit, int(timeout) + 2) if IS_LINUX else None,
        )
        timed_out = False
        try:
            proc.communicate(input=(stdin_data or "").encode("utf-8", errors="replace"), timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            _kill_group(proc)
            try:
                proc.communicate(timeout=2)
            except Exception:
                pass
        except BrokenPipeError:
            proc.wait()
    elapsed = (time.perf_counter() - start) * 1000
    rc = None if timed_out else proc.returncode
    return rc, _read_capped(out_p), _read_capped(err_p), elapsed


def _kill_group(proc):
    try:
        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def _classify(rc, out, err, ms, timeout):
    if rc is None:
        return RunResult("TIMEOUT", _truncate(out), "Time limit exceeded", ms)
    low = (err or "").lower()
    if rc in (-9, 137) and "time" not in low or "memoryerror" in low or "bad_alloc" in low \
            or "outofmemoryerror" in low or "cannot allocate memory" in low:
        return RunResult("MEMORY_LIMIT", _truncate(out), "Memory limit exceeded", ms)
    if rc == -24 or rc == 152:   # SIGXCPU (cpu rlimit)
        return RunResult("TIMEOUT", _truncate(out), "Time limit exceeded", ms)
    if rc != 0:
        return RunResult("RUNTIME_ERROR", _truncate(out), _truncate(err) or f"Process exited with code {rc}", ms)
    return RunResult("OK", _truncate(out), _truncate(err), ms)


# --------------------------------------------------------------- public API --
def run_code(language: str, source_code: str, stdin_data: str = "", timeout: float = None) -> RunResult:
    timeout = timeout or EXECUTION_TIMEOUT_SECONDS
    language = (language or "").lower()
    if language == "c++":
        language = "cpp"
    if language not in ("python", "c", "cpp", "java"):
        return RunResult("INTERNAL_ERROR", stderr=f"Unsupported language: {language}")
    if len(source_code.encode("utf-8", errors="ignore")) > MAX_SOURCE_BYTES:
        return RunResult("COMPILE_ERROR", stderr=f"Source code too large (max {MAX_SOURCE_BYTES // 1024} KB).")
    if len((stdin_data or "").encode("utf-8", errors="ignore")) > MAX_STDIN_BYTES:
        return RunResult("RUNTIME_ERROR", stderr="Input too large.")
    reason = security_scan(language, source_code)
    if reason:
        return RunResult("SECURITY_VIOLATION", stderr=reason)

    workdir = os.path.join(TEMP_RUN_DIR, uuid.uuid4().hex[:12])
    os.makedirs(workdir, exist_ok=True)
    os.chmod(workdir, 0o777)
    try:
        return _run_local(language, source_code, stdin_data, workdir, timeout)
    except Exception as exc:  # never leak a traceback / crash the request
        return RunResult("INTERNAL_ERROR", stderr=f"Execution engine error: {type(exc).__name__}")
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


# --------------------------------------------------------------------- local --
def _c_link_flags(lang_key: str):
    try:
        from app.database import SessionLocal
        from app.services import package_manager
        db = SessionLocal()
        try:
            return package_manager.c_family_link_flags(db, lang_key)
        finally:
            db.close()
    except Exception:
        return []


def _java_classpath() -> str:
    try:
        from app.services import package_manager
        return package_manager.java_classpath_arg()
    except Exception:
        return ""


def _tool_missing_message(tool_label, apt_packages, windows_hint, mac_hint):
    system = platform.system()
    if system == "Linux":
        return f"{tool_label} is not installed on this server. Install it with: sudo apt-get install -y {apt_packages}"
    if system == "Windows":
        return f"{tool_label} is not installed on this server. {windows_hint}"
    if system == "Darwin":
        return f"{tool_label} is not installed on this server. {mac_hint}"
    return f"{tool_label} is not installed on this server."


def _compile_local(cmd, workdir):
    rc, out, err, ms = _local_exec(cmd, workdir, "", COMPILE_TIMEOUT, mem_limit=False)
    if rc is None:
        return RunResult("COMPILE_ERROR", stderr="Compilation timed out.")
    if rc != 0:
        return RunResult("COMPILE_ERROR", stderr=_truncate(err or out))
    return None


def _run_local(language, source_code, stdin_data, workdir, timeout):
    if language == "python":
        path = os.path.join(workdir, "main.py")
        open(path, "w").write(source_code)
        rc, out, err, ms = _local_exec([sys.executable, "-I", "-B", "main.py"], workdir, stdin_data, timeout)
        return _classify(rc, out, err, ms, timeout)

    if language in ("c", "cpp"):
        tool = "gcc" if language == "c" else "g++"
        if not _tool_available(tool):
            return RunResult("INTERNAL_ERROR", stderr=_tool_missing_message(
                tool, tool,
                "Install MinGW-w64 (https://winlibs.com) and put it on PATH.",
                "Run `xcode-select --install`."))
        src = "main.c" if language == "c" else "main.cpp"
        open(os.path.join(workdir, src), "w").write(source_code)
        cmd = [tool, src, "-O2", "-o", "main.out"] + (["-std=c++17"] if language == "cpp" else []) + ["-lm"]
        cmd += _c_link_flags(language)
        failed = _compile_local(cmd, workdir)
        if failed:
            return failed
        rc, out, err, ms = _local_exec([os.path.join(workdir, "main.out")], workdir, stdin_data, timeout)
        return _classify(rc, out, err, ms, timeout)

    # java
    if not (_tool_available("javac") and _tool_available("java")):
        return RunResult("INTERNAL_ERROR", stderr=_tool_missing_message(
            "JDK (javac/java)", "default-jdk-headless",
            "Install Temurin JDK from https://adoptium.net.", "Run `brew install openjdk`."))
    open(os.path.join(workdir, "Main.java"), "w").write(_force_java_classname(source_code, "Main"))
    cp = _java_classpath()
    javac = ["javac", "-J-Xmx256m"] + (["-cp", cp] if cp else []) + ["Main.java"]
    failed = _compile_local(javac, workdir)
    if failed:
        return failed
    # JVM reserves huge *virtual* space, so RLIMIT_AS would kill it at boot; bound the heap instead.
    java = ["java", f"-Xmx{MEMORY_LIMIT_MB}m", "-Xss16m", "-XX:MaxMetaspaceSize=128m",
            "-XX:ReservedCodeCacheSize=64m", "-XX:+UseSerialGC"]
    java += (["-cp", f".:{cp}"] if cp else []) + ["Main"]
    rc, out, err, ms = _local_exec(java, workdir, stdin_data, timeout, mem_limit=False)
    return _classify(rc, out, err, ms, timeout)


def _force_java_classname(source_code: str, new_name: str) -> str:
    m = re.search(r"public\s+class\s+(\w+)", source_code)
    if not m:
        return source_code
    old = m.group(1)
    return re.sub(rf"\b{old}\b", new_name, source_code)
