"""
Import code from a PDF or an image (photo/screenshot of code) into the
Student Workspace editor.

Quality note: OCR of code is genuinely hard -- indentation, brackets, and
symbols like `{`, `;`, `_` are exactly what traditional OCR engines are worst
at, so results from the pytesseract fallback should be treated as a rough
draft the student fixes up, not a guaranteed-correct transcription. When
ANTHROPIC_API_KEY is configured, images go through Claude's vision instead,
which is substantially more reliable for this specific job (transcribing
code-like text) than classic OCR.
"""
import base64
import io
import os
import shutil
import subprocess
import tempfile

from pypdf import PdfReader
from PIL import Image

from app.config import ANTHROPIC_API_KEY
from app.services.ai_review import _call_claude_vision

MAX_PDF_OCR_PAGES = 5          # cap how many pages we'll render+OCR for a scanned PDF
MAX_IMAGE_DIMENSION = 1568     # Anthropic's documented sweet spot for image quality/cost


class ImportResult:
    def __init__(self, code: str, method: str, warning: str = ""):
        self.code = code
        self.method = method   # "pdf-text" | "pdf-ocr" | "vision" | "tesseract"
        self.warning = warning


def _downscale_if_needed(img: Image.Image) -> Image.Image:
    if max(img.size) <= MAX_IMAGE_DIMENSION:
        return img
    ratio = MAX_IMAGE_DIMENSION / max(img.size)
    return img.resize((int(img.width * ratio), int(img.height * ratio)))


def _image_to_base64_png(img: Image.Image) -> str:
    buf = io.BytesIO()
    img.convert("RGB").save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode()


def _ocr_image_bytes(image_bytes: bytes) -> str:
    import pytesseract
    img = Image.open(io.BytesIO(image_bytes))
    return pytesseract.image_to_string(img)


CODE_TRANSCRIBE_PROMPT = (
    "Transcribe the code shown in this image EXACTLY as written -- same "
    "indentation, same symbols, same line breaks. Output ONLY the code itself, "
    "no explanation, no markdown code fences, no commentary. If there is text "
    "in the image that isn't code (e.g. a caption), ignore it."
)


def extract_code_from_image(image_bytes: bytes, mime_type: str) -> ImportResult:
    if ANTHROPIC_API_KEY:
        try:
            img = _downscale_if_needed(Image.open(io.BytesIO(image_bytes)))
            b64 = _image_to_base64_png(img)
            text = _call_claude_vision(b64, "image/png", CODE_TRANSCRIBE_PROMPT, max_tokens=2000)
            return ImportResult(code=text.strip(), method="vision")
        except Exception as e:
            # Fall through to OCR rather than failing outright -- a rough
            # transcription is still more useful than none.
            try:
                text = _ocr_image_bytes(image_bytes)
                return ImportResult(
                    code=text.strip(), method="tesseract",
                    warning=f"AI vision unavailable ({e}); used basic OCR instead, so double-check indentation and symbols.",
                )
            except Exception as e2:
                return ImportResult(code="", method="none", warning=f"Could not read the image: {e2}")
    else:
        try:
            text = _ocr_image_bytes(image_bytes)
            return ImportResult(
                code=text.strip(), method="tesseract",
                warning="Used basic OCR (no ANTHROPIC_API_KEY configured) -- double-check indentation, brackets, and symbols carefully.",
            )
        except Exception as e:
            return ImportResult(code="", method="none", warning=f"Could not read the image: {e}")


def _render_pdf_pages_to_png(pdf_path: str, out_dir: str, max_pages: int) -> list:
    """Render up to max_pages pages of a PDF to PNG using poppler's pdftoppm,
    which is a plain system binary (no extra Python package needed) -- this is
    the scanned-PDF fallback path, used only when text extraction comes back
    empty."""
    if shutil.which("pdftoppm") is None:
        return []
    prefix = os.path.join(out_dir, "page")
    try:
        subprocess.run(
            ["pdftoppm", "-png", "-r", "150", "-l", str(max_pages), pdf_path, prefix],
            capture_output=True, text=True, timeout=60,
        )
    except Exception:
        return []
    return sorted(
        os.path.join(out_dir, f) for f in os.listdir(out_dir) if f.startswith("page") and f.endswith(".png")
    )


def extract_code_from_pdf(pdf_bytes: bytes) -> ImportResult:
    # First try real text extraction -- works for any PDF that has an actual
    # text layer (code exported to PDF, "print to PDF" from an editor, etc.)
    # and is exact, unlike OCR.
    try:
        reader = PdfReader(io.BytesIO(pdf_bytes))
        pages_text = [page.extract_text() or "" for page in reader.pages]
        text = "\n".join(pages_text).strip()
    except Exception as e:
        return ImportResult(code="", method="none", warning=f"Could not open the PDF: {e}")

    if len(text) >= 20:
        return ImportResult(code=text, method="pdf-text")

    # Little/no extractable text usually means a scanned PDF (a PDF made of
    # page images, no text layer) -- render pages to images and OCR/vision
    # those instead, same as a direct image upload.
    with tempfile.TemporaryDirectory() as tmp:
        pdf_path = os.path.join(tmp, "in.pdf")
        with open(pdf_path, "wb") as f:
            f.write(pdf_bytes)
        page_images = _render_pdf_pages_to_png(pdf_path, tmp, MAX_PDF_OCR_PAGES)
        if not page_images:
            return ImportResult(
                code="", method="none",
                warning="This PDF has no extractable text and page rendering isn't available on this server "
                        "(install poppler-utils for `pdftoppm`) -- try a screenshot/photo via Import Image instead.",
            )

        parts = []
        used_vision = False
        for page_path in page_images:
            with open(page_path, "rb") as f:
                page_bytes = f.read()
            result = extract_code_from_image(page_bytes, "image/png")
            if result.code:
                parts.append(result.code)
            used_vision = used_vision or result.method == "vision"

        combined = "\n\n".join(parts).strip()
        warning = "Scanned PDF with no text layer -- OCR'd each page instead, so double-check the result carefully."
        if len(page_images) >= MAX_PDF_OCR_PAGES:
            warning += f" Only the first {MAX_PDF_OCR_PAGES} pages were processed."
        return ImportResult(code=combined, method="pdf-ocr" if not used_vision else "pdf-vision", warning=warning)
