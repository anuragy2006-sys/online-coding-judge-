"""
Code plagiarism / similarity detection.

Method (MOSS-style winnowing):
  1. Tokenise the source and normalise it: comments dropped, every identifier ->
     ID, numbers -> NUM, strings -> STR. Renaming variables, changing comments or
     whitespace therefore does NOT hide a copy.
  2. Hash every k-gram of tokens and keep the minimum hash in each sliding window
     (winnowing) -> a compact fingerprint set.
  3. similarity = Dice coefficient of the two fingerprint sets, in percent.
Fingerprints that also occur in the problem's starter code are ignored.
"""
import io
import re
import keyword
import tokenize
import hashlib
from sqlalchemy.orm import Session

from app import models
from app.config import SIMILARITY_FLAG_THRESHOLD

K = 5
WINDOW = 4

_C_KEYWORDS = set("""auto break case char const continue default do double else enum extern float for goto if inline int
long register restrict return short signed sizeof static struct switch typedef union unsigned void volatile while
class public private protected new delete this try catch throw namespace using template typename virtual bool true false
nullptr boolean final import package interface extends implements abstract synchronized throws instanceof super null
string vector map set cout cin endl printf scanf System out println""".split())

_C_TOKEN = re.compile(r"""//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|[A-Za-z_]\w*|\d+\.?\d*|==|!=|<=|>=|&&|\|\||\+\+|--|<<|>>|[^\s\w]""", re.S)


def tokenize_source(language: str, source: str):
    toks = []
    if language == "python":
        try:
            for t in tokenize.generate_tokens(io.StringIO(source).readline):
                if t.type == tokenize.NAME:
                    toks.append(t.string if keyword.iskeyword(t.string) else "ID")
                elif t.type == tokenize.NUMBER:
                    toks.append("NUM")
                elif t.type == tokenize.STRING:
                    toks.append("STR")
                elif t.type == tokenize.OP:
                    toks.append(t.string)
            return toks
        except (tokenize.TokenError, IndentationError, SyntaxError):
            pass  # fall through to the generic tokenizer
    for m in _C_TOKEN.finditer(source):
        s = m.group(0)
        if s.startswith("//") or s.startswith("/*"):
            continue
        if s[0] in "\"'":
            toks.append("STR")
        elif s[0].isdigit():
            toks.append("NUM")
        elif s[0].isalpha() or s[0] == "_":
            toks.append(s if s in _C_KEYWORDS or language == "python" and keyword.iskeyword(s) else "ID")
        else:
            toks.append(s)
    return toks


def fingerprints(tokens, k=K, w=WINDOW):
    if len(tokens) < k:
        return set()
    hashes = [int(hashlib.md5(" ".join(tokens[i:i + k]).encode()).hexdigest()[:12], 16)
              for i in range(len(tokens) - k + 1)]
    if len(hashes) <= w:
        return {min(hashes)}
    return {min(hashes[i:i + w]) for i in range(len(hashes) - w + 1)}


def similarity_percent(a: set, b: set) -> float:
    if not a or not b:
        return 0.0
    return round(200.0 * len(a & b) / (len(a) + len(b)), 1)


def _norm_lang(l):
    return "cpp" if l in ("c++", "cpp") else l


def check_submission(db: Session, submission: models.Submission, problem: models.Problem):
    """Compares against the latest submission of every OTHER user on the same problem+language.
    Stores SimilarityReport rows for pairs over the flag threshold. Returns max similarity."""
    lang = _norm_lang(submission.language)
    mine = fingerprints(tokenize_source(lang, submission.source_code))
    if len(mine) < 3:          # too little code to judge meaningfully
        return 0.0
    base = fingerprints(tokenize_source(lang, problem.starter_code or "")) if problem.starter_code else set()
    mine -= base
    if not mine:
        return 0.0

    others = (db.query(models.Submission)
              .filter(models.Submission.problem_id == submission.problem_id,
                      models.Submission.user_id != submission.user_id,
                      models.Submission.id != submission.id)
              .order_by(models.Submission.id.desc()).all())
    seen, best = set(), 0.0
    for o in others:
        if o.user_id in seen or _norm_lang(o.language) != lang:
            continue
        seen.add(o.user_id)
        theirs = fingerprints(tokenize_source(lang, o.source_code)) - base
        sim = similarity_percent(mine, theirs)
        best = max(best, sim)
        if sim >= SIMILARITY_FLAG_THRESHOLD:
            db.add(models.SimilarityReport(
                submission_id=submission.id, other_submission_id=o.id, problem_id=problem.id,
                user_id=submission.user_id, other_user_id=o.user_id, similarity=sim))
    submission.similarity_score = best
    db.commit()
    return best
