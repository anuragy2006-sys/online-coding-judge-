"""PDF report generation (ReportLab)."""
import io
import datetime as dt
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle

ACCENT = colors.HexColor("#4f46e5")


def _styles():
    ss = getSampleStyleSheet()
    ss.add(ParagraphStyle("H1x", parent=ss["Title"], textColor=ACCENT, fontSize=20, spaceAfter=4))
    ss.add(ParagraphStyle("Mut", parent=ss["Normal"], textColor=colors.grey, fontSize=9))
    ss.add(ParagraphStyle("H2x", parent=ss["Heading2"], textColor=colors.HexColor("#111827"), spaceBefore=12))
    return ss


def _table(data, widths=None):
    t = Table(data, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), ACCENT), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5), ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f3f4f6")]),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#d1d5db")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    return t


def _doc(buf, title):
    return SimpleDocTemplate(buf, pagesize=A4, leftMargin=16 * mm, rightMargin=16 * mm, topMargin=16 * mm,
                             bottomMargin=16 * mm, title=title, author="CodeJudge AI")


def class_report_pdf(overview: dict, generated_by: str) -> bytes:
    ss, buf = _styles(), io.BytesIO()
    el = [Paragraph("CodeJudge AI - Class Performance Report", ss["H1x"]),
          Paragraph(f"Generated {dt.datetime.utcnow():%Y-%m-%d %H:%M} UTC by {generated_by}", ss["Mut"]), Spacer(1, 8)]
    el.append(_table([["Students", "Submissions", "Active (7d)", "Avg accuracy"],
                      [overview["students"], overview["submissions"], overview["active_week"], f'{overview["avg_accuracy"]}%']]))
    el.append(Paragraph("Topic-wise performance (weakest first)", ss["H2x"]))
    rows = [["Topic", "Attempts", "Students", "Accuracy", "Solve rate"]] + [
        [t["topic"], t["attempts"], t["students"], f'{t["accuracy"]}%', f'{t["solve_rate"]}%'] for t in overview["topics"]]
    el.append(_table(rows if len(rows) > 1 else rows + [["No data yet", "", "", "", ""]]))
    el.append(Paragraph("Student leaderboard", ss["H2x"]))
    rows = [["Student", "Solved", "Submissions", "Accuracy", "XP", "Last active"]] + [
        [r["user"].username, r["solved"], r["submissions"], f'{r["accuracy"]}%', r["xp"],
         r["last"].strftime("%Y-%m-%d") if r["last"] else "never"] for r in overview["rows"]]
    el.append(_table(rows))
    if overview["at_risk"]:
        el.append(Paragraph("Students needing attention", ss["H2x"]))
        el.append(_table([["Student", "Reason", "Accuracy", "Submissions"]] + [
            [r["user"].username, r["reason"], f'{r["accuracy"]}%', r["submissions"]] for r in overview["at_risk"]]))
    _doc(buf, "Class report").build(el)
    return buf.getvalue()


def student_report_pdf(student, stats: dict, generated_by: str) -> bytes:
    ss, buf = _styles(), io.BytesIO()
    el = [Paragraph(f"Student Report - {student.username}", ss["H1x"]),
          Paragraph(f"{student.email} | Generated {dt.datetime.utcnow():%Y-%m-%d %H:%M} UTC by {generated_by}", ss["Mut"]),
          Spacer(1, 8),
          _table([["Solved", "Submissions", "Accuracy", "XP / Level", "Streak", "Rank"],
                  [stats["solved"], stats["submissions"], f'{stats["accuracy"]}%', f'{student.xp or 0} / L{stats["level"]}',
                   f'{stats["streak"]} d', f'#{stats["rank"]}']])]
    el.append(Paragraph("Topic-wise weakness report", ss["H2x"]))
    rows = [["Topic", "Solved/Total", "Attempts", "Accuracy", "Weakness", "Status"]] + [
        [t["topic"], f'{t["solved"]}/{t["total"]}', t["attempts"],
         f'{t["accuracy"]}%' if t["accuracy"] is not None else "-",
         t["weakness"] if t["weakness"] is not None else "-", t["status"]] for t in stats["topics"]]
    el.append(_table(rows))
    if stats["insights"]:
        el.append(Paragraph("Common mistake patterns", ss["H2x"]))
        el.append(_table([["Verdict", "Count", "Area", "Advice"]] + [
            [i["verdict"], i["count"], i["area"], Paragraph(i["advice"], ss["Normal"])] for i in stats["insights"]],
            [32 * mm, 14 * mm, 32 * mm, 98 * mm]))
    el.append(Paragraph("Recent submissions", ss["H2x"]))
    el.append(_table([["When (UTC)", "Problem", "Lang", "Verdict", "Score"]] + [
        [s.created_at.strftime("%Y-%m-%d %H:%M"), s.problem.title[:40], s.language, s.verdict, f"{s.score:g}"]
        for s in stats["recent"]] or [["-"] * 5]))
    _doc(buf, "Student report").build(el)
    return buf.getvalue()
