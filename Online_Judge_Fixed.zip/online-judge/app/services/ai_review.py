"""
AI Code Doctor.

If ANTHROPIC_API_KEY is set (see app/config.py), calls the real Anthropic
API for high quality reviews / explanations / conversions. If not set,
falls back to a built-in heuristic engine so the feature still works
out of the box with zero API keys.
"""
import re
import json
import httpx

from app.config import ANTHROPIC_API_KEY, ANTHROPIC_MODEL

ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"


def _call_claude(prompt: str, max_tokens: int = 700) -> str:
    headers = {
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }
    body = {
        "model": ANTHROPIC_MODEL,
        "max_tokens": max_tokens,
        "messages": [{"role": "user", "content": prompt}],
    }
    with httpx.Client(timeout=30) as client:
        resp = client.post(ANTHROPIC_URL, headers=headers, json=body)
        resp.raise_for_status()
        data = resp.json()
        parts = [b["text"] for b in data.get("content", []) if b.get("type") == "text"]
        return "\n".join(parts).strip()


def _call_claude_vision(image_b64: str, media_type: str, prompt: str, max_tokens: int = 1500) -> str:
    """Same as _call_claude but with an image attached -- used by
    file_import.py to transcribe code from a photo/screenshot/scanned PDF
    page. A longer timeout than the text-only call because vision requests
    over larger images take noticeably longer to process."""
    headers = {
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }
    body = {
        "model": ANTHROPIC_MODEL,
        "max_tokens": max_tokens,
        "messages": [{
            "role": "user",
            "content": [
                {"type": "image", "source": {"type": "base64", "media_type": media_type, "data": image_b64}},
                {"type": "text", "text": prompt},
            ],
        }],
    }
    with httpx.Client(timeout=60) as client:
        resp = client.post(ANTHROPIC_URL, headers=headers, json=body)
        resp.raise_for_status()
        data = resp.json()
        parts = [b["text"] for b in data.get("content", []) if b.get("type") == "text"]
        return "\n".join(parts).strip()


def _use_real_ai() -> bool:
    return bool(ANTHROPIC_API_KEY)


# ---------------------------------------------------------------- REVIEW ---

def review_code(language: str, source_code: str, verdict: str = "") -> str:
    if _use_real_ai():
        prompt = (
            f"You are a code review assistant for an online judge. "
            f"Review this {language} submission (verdict: {verdict or 'n/a'}). "
            f"Point out complexity (Big-O), bugs, and 2-3 concrete optimization "
            f"suggestions. Be concise, use short bullet points.\n\n```{language}\n{source_code}\n```"
        )
        try:
            return _call_claude(prompt)
        except Exception as e:
            return f"(AI service unavailable, showing heuristic review)\n\n{_heuristic_review(source_code)}"
    return _heuristic_review(source_code)


def _heuristic_review(source_code: str) -> str:
    findings = []
    loop_count = len(re.findall(r"\bfor\b|\bwhile\b", source_code))
    nested = len(re.findall(r"(for|while)[^\n]*\n(?:[^\n]*\n){0,3}?\s*(for|while)", source_code))

    if nested:
        findings.append("⚠️ Nested loops detected — likely **O(n²)** or worse. "
                         "Consider a HashMap/Set for O(n) lookups if you're checking membership.")
    elif loop_count >= 1:
        findings.append("✅ Looks like a single-pass loop — likely **O(n)**, which is generally good.")

    if re.search(r"\.append\(.*\)\s*\n.*for", source_code):
        findings.append("💡 Building a list inside a loop — a list comprehension may be faster and cleaner.")

    if re.search(r"\bsort\(|\bsorted\(", source_code):
        findings.append("ℹ️ Sorting detected — adds **O(n log n)** to your complexity.")

    if re.search(r"import\s+\*", source_code):
        findings.append("⚠️ Wildcard imports (`import *`) can cause naming collisions — import only what you need.")

    if len(source_code.splitlines()) > 80:
        findings.append("📏 This solution is fairly long — consider splitting logic into helper functions.")

    if not findings:
        findings.append("✅ No obvious red flags found. Code looks reasonably clean at a glance.")

    findings.append(
        "\n*(This is a heuristic review. Set ANTHROPIC_API_KEY in app/config.py "
        "for full AI-powered reviews.)*"
    )
    return "\n\n".join(findings)


# ------------------------------------------------------------ ERROR EXPL ---

def explain_error(language: str, source_code: str, error_message: str) -> str:
    if _use_real_ai():
        prompt = (
            f"Explain this {language} error to a beginner programmer in three short "
            f"sections: **What happened?**, **Why?**, **How to fix it?**. "
            f"Be concise (under 120 words total).\n\n"
            f"Code:\n```{language}\n{source_code}\n```\n\nError:\n{error_message}"
        )
        try:
            return _call_claude(prompt, max_tokens=400)
        except Exception:
            pass
    return _heuristic_error_explanation(error_message)


COMMON_ERRORS = {
    "TypeError": "You're trying to perform an operation between incompatible data types "
                 "(e.g. adding a string and a number). Convert one side using int(), str(), or float().",
    "NameError": "You're using a variable or function that hasn't been defined yet. "
                 "Check for typos or make sure it's defined before use.",
    "IndexError": "You're accessing a list/array position that doesn't exist. "
                  "Check your loop bounds (remember indices start at 0).",
    "KeyError": "You're accessing a dictionary key that doesn't exist. "
               "Use `.get(key, default)` or check `if key in dict` first.",
    "ZeroDivisionError": "You're dividing by zero. Add a check before the division.",
    "SyntaxError": "There's a typo or missing punctuation (colon, bracket, quote) in your code.",
    "IndentationError": "Your code's indentation doesn't match Python's block structure — mixed tabs/spaces or missing indent.",
    "segmentation fault": "Your C/C++ program accessed invalid memory — likely an out-of-bounds array access or a null/dangling pointer.",
    "AttributeError": "You're calling a method/attribute that doesn't exist on that object type. Double check the object's type.",
}


def _heuristic_error_explanation(error_message: str) -> str:
    if not error_message:
        return "No error message available."
    for key, explanation in COMMON_ERRORS.items():
        if key.lower() in error_message.lower():
            return (
                f"**What happened?** A `{key}` occurred.\n\n"
                f"**Why?** {explanation}\n\n"
                f"**Raw error:**\n```\n{error_message.strip()[:500]}\n```"
            )
    return f"**Raw error:**\n```\n{error_message.strip()[:800]}\n```\n\n"\
           "Read the last line of the traceback first — it usually names the exact problem."


# --------------------------------------------------------------- CONVERT ---

# Heuristic "equivalent data structures" table used when no API key is set,
# and also fed to the AI prompt so the real model's answer stays consistent
# with the platform's language.
_STRUCTURE_EQUIVALENTS = {
    "cpp": {"list": "vector", "map": "unordered_map", "set": "unordered_set", "string": "string"},
    "c": {"list": "array + manual size tracking", "map": "hash table (manual) / struct + linear search", "set": "sorted array / manual hash set", "string": "char[]"},
    "python": {"list": "list", "map": "dict", "set": "set", "string": "str"},
    "java": {"list": "ArrayList", "map": "HashMap", "set": "HashSet", "string": "String"},
    "javascript": {"list": "Array", "map": "Map / plain object", "set": "Set", "string": "string"},
}


def _structure_note(source_language: str, target_language: str) -> str:
    src = _STRUCTURE_EQUIVALENTS.get(source_language.lower())
    tgt = _STRUCTURE_EQUIVALENTS.get(target_language.lower())
    if not src or not tgt:
        return ""
    rows = []
    for key, label in [("list", "Dynamic array"), ("map", "Key-value map"), ("set", "Set")]:
        if src.get(key) != tgt.get(key):
            rows.append(f"- {label}: `{src[key]}` → `{tgt[key]}`")
    if not rows:
        return ""
    return "**Equivalent data structures:**\n" + "\n".join(rows)


def convert_code(source_language: str, target_language: str, source_code: str) -> dict:
    """
    Returns a dict: {converted_code, explanation}
    `converted_code` is shown side-by-side with the original in the UI.
    """
    structure_note = _structure_note(source_language, target_language)

    if _use_real_ai():
        prompt = (
            f"Convert this {source_language} code to idiomatic {target_language}.\n"
            f"Respond in exactly two parts:\n"
            f"1. A fenced code block with ONLY the converted {target_language} code.\n"
            f"2. After the code block, 2-4 short bullet points under a heading "
            f"'Key differences:' explaining language-specific differences that mattered "
            f"in this conversion (data structures used, memory model, idioms). "
            f"Keep the whole explanation under 100 words.\n\n"
            f"```{source_language}\n{source_code}\n```"
        )
        try:
            result = _call_claude(prompt, max_tokens=900)
            match = re.search(r"```(?:\w+)?\n(.*?)```", result, re.DOTALL)
            code = match.group(1).strip() if match else result
            explanation = result[match.end():].strip() if match else ""
            if not explanation and structure_note:
                explanation = structure_note
            return {"converted_code": code, "explanation": explanation}
        except Exception:
            pass

    fallback_code = (
        f"# Automatic {source_language} → {target_language} conversion needs an AI API key.\n"
        f"# Set ANTHROPIC_API_KEY in app/config.py to enable real code translation.\n\n"
        f"# --- original {source_language} code below ---\n" + source_code
    )
    explanation = structure_note or (
        f"*(Set ANTHROPIC_API_KEY in app/config.py for a real {source_language} → "
        f"{target_language} translation with explanation of language-specific differences.)*"
    )
    return {"converted_code": fallback_code, "explanation": explanation}


# -------------------------------------------------------------- EXPLAIN ---

def explain_code(language: str, source_code: str, level: str = "beginner") -> str:
    if _use_real_ai():
        prompt = (
            f"Explain this {language} code for a {level} audience. "
            f"Go through it briefly, section by section, in plain language. "
            f"Keep it under 200 words.\n\n```{language}\n{source_code}\n```"
        )
        try:
            return _call_claude(prompt, max_tokens=500)
        except Exception:
            pass
    lines = [l for l in source_code.splitlines() if l.strip()]
    out = ["**Line-by-line walkthrough (heuristic mode):**\n"]
    for i, line in enumerate(lines[:25], 1):
        out.append(f"`Line {i}` → `{line.strip()[:70]}`")
    if len(lines) > 25:
        out.append(f"... and {len(lines) - 25} more lines.")
    out.append("\n*(Set ANTHROPIC_API_KEY for full natural-language explanations.)*")
    return "\n\n".join(out)


# ------------------------------------------------------------- OPTIMIZE ---

def optimize_code(language: str, source_code: str) -> str:
    if _use_real_ai():
        prompt = (
            f"Analyze this {language} code's time/space complexity, then provide "
            f"an optimized version if possible. Format as:\n"
            f"**Current Complexity:** ...\n**Suggested Complexity:** ...\n"
            f"**Optimized Code:**\n```{language}\n...\n```\n\n"
            f"Code:\n```{language}\n{source_code}\n```"
        )
        try:
            return _call_claude(prompt, max_tokens=800)
        except Exception:
            pass
    nested = len(re.findall(r"(for|while)[^\n]*\n(?:[^\n]*\n){0,3}?\s*(for|while)", source_code))
    current = "O(n²)" if nested else "O(n)"
    suggested = "O(n) using a HashMap/Set" if nested else "Already roughly linear — check for hidden costs (sorting, string concat in loops)."
    return (
        f"**Current Complexity (estimated):** {current}\n\n"
        f"**Suggestion:** {suggested}\n\n"
        f"*(Set ANTHROPIC_API_KEY in app/config.py for an actual optimized code rewrite.)*"
    )


# ------------------------------------------------------------- FIX CODE ---

def fix_code(language: str, source_code: str, error_message: str = "") -> dict:
    """
    Returns a dict: {diagnosis, fixed_code}
    diagnosis = Cause / Location / Why / Suggested Fix, in the "error doctor" format.
    fixed_code = a corrected version of the submission (best-effort).
    """
    if _use_real_ai():
        prompt = (
            f"You are fixing a bug in this {language} submission on a coding judge.\n"
            f"Error/verdict info: {error_message or 'not specified — inspect the code for bugs.'}\n\n"
            f"Respond in exactly two parts:\n"
            f"1. A short diagnosis using this exact format:\n"
            f"**Cause:** ...\n**Problem Location:** (line or region)\n**Why it happened:** ...\n**Suggested Fix:** ...\n"
            f"2. Then a fenced code block with the corrected full {language} code.\n"
            f"Keep the diagnosis under 80 words.\n\n"
            f"```{language}\n{source_code}\n```"
        )
        try:
            result = _call_claude(prompt, max_tokens=900)
            match = re.search(r"```(?:\w+)?\n(.*?)```", result, re.DOTALL)
            fixed = match.group(1).strip() if match else ""
            diagnosis = result[:match.start()].strip() if match else result
            return {"diagnosis": diagnosis, "fixed_code": fixed}
        except Exception:
            pass
    if error_message:
        return {"diagnosis": _heuristic_error_explanation(error_message), "fixed_code": ""}
    return {"diagnosis": _static_check(language, source_code), "fixed_code": ""}


def _static_check(language: str, source_code: str) -> str:
    """No runtime error available: do a quick static check instead of a dead end."""
    if not source_code.strip():
        return "Your editor is empty — write some code first."
    if language.lower() == "python":
        import ast
        try:
            ast.parse(source_code)
        except SyntaxError as e:
            return (f"**Cause:** SyntaxError — {e.msg}\n**Problem Location:** line {e.lineno}\n"
                    f"**Why it happened:** Python can't parse this line"
                    f"{': `' + e.text.strip() + '`' if e.text else ''}.\n"
                    f"**Suggested Fix:** Check for a missing colon, bracket, quote or bad indentation there.")
    return ("**No crash or syntax error found.** If your output is wrong, click **Run samples** "
            "(or submit) and use Fix My Code again — the Doctor will then see the failing "
            "input, expected output and your output. Common causes: off-by-one in loops, "
            "wrong input parsing, not handling edge cases (n = 0/1, negatives, duplicates).")


# ---------------------------------------------------------- TEACH ME ---

def teach_me_code(language: str, source_code: str, problem_title: str = "") -> str:
    """
    6-step teaching walkthrough: problem / main idea / why it works /
    line-by-line / complexity / interview questions.
    """
    if _use_real_ai():
        prompt = (
            f"Teach this {language} solution"
            f"{f' for the problem \"{problem_title}\"' if problem_title else ''} "
            f"to someone learning DSA. Structure your answer with exactly these headings, "
            f"each 1-3 short sentences (except line-by-line, which can be a short list):\n\n"
            f"**1. What problem are we solving?**\n"
            f"**2. What is the main idea?**\n"
            f"**3. Why does this approach work?**\n"
            f"**4. Line-by-line walkthrough**\n"
            f"**5. Complexity**\n"
            f"**6. Interview questions based on this code** (2 questions)\n\n"
            f"```{language}\n{source_code}\n```"
        )
        try:
            return _call_claude(prompt, max_tokens=900)
        except Exception:
            pass
    return _heuristic_teach_me(language, source_code, problem_title)


def _heuristic_teach_me(language: str, source_code: str, problem_title: str) -> str:
    lines = [l for l in source_code.splitlines() if l.strip()]
    nested = len(re.findall(r"(for|while)[^\n]*\n(?:[^\n]*\n){0,3}?\s*(for|while)", source_code))
    loop_count = len(re.findall(r"\bfor\b|\bwhile\b", source_code))
    complexity = "O(n²)" if nested else ("O(n)" if loop_count else "O(1)")

    walkthrough = "\n".join(
        f"- `Line {i}`: `{line.strip()[:65]}`" for i, line in enumerate(lines[:15], 1)
    )
    if len(lines) > 15:
        walkthrough += f"\n- ... and {len(lines) - 15} more lines."

    title_part = f' "{problem_title}"' if problem_title else ""
    return (
        f"**1. What problem are we solving?**\nThis code solves{title_part} "
        f"— read the problem statement for the exact requirement.\n\n"
        f"**2. What is the main idea?**\n"
        f"{'Uses nested iteration to compare/combine elements.' if nested else 'Processes input in a single structured pass, using variables/data structures to track state.'}\n\n"
        f"**3. Why does this approach work?**\nIt directly follows the problem's logic — each step "
        f"narrows down or builds toward the required output.\n\n"
        f"**4. Line-by-line walkthrough**\n{walkthrough}\n\n"
        f"**5. Complexity**\nEstimated time: {complexity}. Space depends on any extra "
        f"lists/maps/sets used.\n\n"
        f"**6. Interview questions based on this code**\n"
        f"- How would this approach change if the input were streamed instead of fully in memory?\n"
        f"- What's the time/space trade-off compared to a different approach for this problem?\n\n"
        f"*(Set ANTHROPIC_API_KEY in app/config.py for a fully tailored walkthrough.)*"
    )


# --------------------------------------------------------- ALTERNATIVES ---

def generate_alternatives(language: str, source_code: str, problem_description: str = "") -> str:
    """
    Returns 2-3 alternative approaches to the same problem, each with a
    name, brief idea, and time/space complexity — plus a comparison table.
    """
    if _use_real_ai():
        prompt = (
            f"A student wrote this {language} solution"
            f"{f' to: {problem_description}' if problem_description else ''}. "
            f"Suggest 2-3 alternative approaches to solve the SAME problem "
            f"(including the one they used, if reasonable). For each: a short name, "
            f"one-sentence idea, time complexity, space complexity. "
            f"Finish with a markdown comparison table (Approach | Time | Space | Difficulty). "
            f"Keep it concise.\n\n```{language}\n{source_code}\n```"
        )
        try:
            return _call_claude(prompt, max_tokens=800)
        except Exception:
            pass
    return _heuristic_alternatives(source_code)


def _heuristic_alternatives(source_code: str) -> str:
    nested = len(re.findall(r"(for|while)[^\n]*\n(?:[^\n]*\n){0,3}?\s*(for|while)", source_code))
    has_sort = bool(re.search(r"\bsort\(|\bsorted\(", source_code))
    has_map = bool(re.search(r"\bdict\(|\{\}|\bunordered_map\b|\bHashMap\b|\bmap\b", source_code))

    approaches = []
    if nested:
        approaches.append(("Brute Force (your current approach)", "Compare/combine every pair directly.", "O(n²)", "O(1)", "Easy"))
    if not has_map:
        approaches.append(("HashMap / Set lookup", "Trade space for time — store seen values for O(1) lookups instead of re-scanning.", "O(n)", "O(n)", "Medium"))
    if not has_sort:
        approaches.append(("Sort + Two Pointer", "Sort the input first, then use two pointers moving inward — often removes the need for extra memory.", "O(n log n)", "O(1)", "Medium"))
    if not approaches:
        approaches.append(("Current approach", "Looks reasonably optimal already based on a quick scan.", "~O(n) - O(n log n)", "varies", "—"))

    lines = ["**Alternative approaches:**\n"]
    for name, idea, t, s, d in approaches:
        lines.append(f"**{name}**\n{idea}\nTime: `{t}` · Space: `{s}`\n")

    table = "\n| Approach | Time | Space | Difficulty |\n|---|---|---|---|\n"
    for name, _, t, s, d in approaches:
        table += f"| {name} | {t} | {s} | {d} |\n"

    return "\n".join(lines) + table + \
        "\n*(Heuristic suggestions based on pattern matching. Set ANTHROPIC_API_KEY " \
        "in app/config.py for problem-aware alternative solutions.)*"


# ----------------------------------------------------------- SUGGESTIONS ---

def suggest_code(language: str, source_code: str) -> str:
    """
    Actionable "you could use X here" suggestions — idioms, standard-library
    functions, and small related code snippets relevant to what's already
    written. Different from review_code: this is forward-looking ("here's
    what to add/use next") rather than a quality critique of what exists.
    """
    if _use_real_ai():
        prompt = (
            f"Look at this {language} code and suggest concrete improvements: "
            f"more idiomatic language features, useful standard-library functions "
            f"the author probably doesn't know about yet, or small related code "
            f"snippets that would help (e.g. a helper function, a built-in they could "
            f"use instead of manual code). For each suggestion give a 1-line reason "
            f"and a short code snippet. Max 4 suggestions, be concise.\n\n"
            f"```{language}\n{source_code}\n```"
        )
        try:
            return _call_claude(prompt, max_tokens=700)
        except Exception:
            pass
    return _heuristic_suggestions(language, source_code)


_IDIOM_RULES = {
    "python": [
        (r"for\s+\w+\s+in\s+range\(len\(", "Use `enumerate()` instead of `range(len(...))` when you need both index and value.",
         "for i, x in enumerate(arr):\n    ..."),
        (r"\+\s*['\"]|['\"]\s*\+", "String concatenation with `+` is slow in loops — consider an f-string or `''.join(...)`.",
         'name = f"{first} {last}"'),
        (r"^\s*\w+\s*=\s*\[\]\s*\n(?:.*\n)*?\s*for .*:\n\s*\w+\.append\(", "This append-in-a-loop pattern can often become a list comprehension.",
         "squares = [x * x for x in nums]"),
        (r"\.keys\(\)\s*:", "You don't need `.keys()` when iterating a dict directly — `for k in d:` already gives keys.",
         "for key in my_dict:\n    ..."),
        (r"collections", None, None),
    ],
    "cpp": [
        (r"for\s*\(\s*int\s+\w+\s*=\s*0.*\.size\(\)", "Consider a range-based for loop instead of manual indexing.",
         "for (auto& x : vec) { ... }"),
        (r"\bnew\b", "Raw `new` — consider a smart pointer (`std::unique_ptr`/`std::shared_ptr`) to avoid manual `delete`.",
         "auto ptr = std::make_unique<Foo>();"),
        (r"push_back", "If you know the final size ahead of time, call `.reserve(n)` before a loop of `push_back` to avoid reallocations.",
         "vec.reserve(n);"),
    ],
    "java": [
        (r"\+\s*\"|\"\s*\+", "String concatenation with `+` inside a loop is inefficient — use `StringBuilder`.",
         "StringBuilder sb = new StringBuilder();\nsb.append(x);"),
        (r"for\s*\(\s*int\s+\w+\s*=\s*0.*\.length", "Consider an enhanced for-loop when you don't need the index.",
         "for (int x : arr) { ... }"),
    ],
    "c": [
        (r"\bmalloc\(", "Remember to check the return value of `malloc` for NULL, and pair it with a matching `free`.",
         "int *p = malloc(n * sizeof(int));\nif (!p) { /* handle error */ }"),
        (r"#define\s+\w+\s+\d", None, None),
    ],
}


def _heuristic_suggestions(language: str, source_code: str) -> str:
    rules = _IDIOM_RULES.get(language.lower(), [])
    found = []
    for pattern, reason, snippet in rules:
        if reason and re.search(pattern, source_code):
            found.append((reason, snippet))

    if not found:
        return (
            "No obvious idiom upgrades spotted by the heuristic scanner — your code "
            "already looks fairly idiomatic for this pattern set.\n\n"
            "*(Set ANTHROPIC_API_KEY in app/config.py for deeper, code-aware suggestions.)*"
        )

    out = ["**Suggestions:**\n"]
    for reason, snippet in found[:4]:
        out.append(f"- {reason}\n  ```{language}\n  {snippet}\n  ```")
    out.append("\n*(Heuristic suggestions. Set ANTHROPIC_API_KEY in app/config.py for fully code-aware suggestions.)*")
    return "\n".join(out)


# ------------------------------------------------------ INTELLIGENCE REPORT

_FUNC_PATTERNS = {
    "python": r"^\s*def\s+\w+\s*\(",
    "cpp": r"\b\w[\w:<>,\s\*&]*\s+\w+\s*\([^;{}]*\)\s*\{",
    "c": r"\b\w[\w\s\*]*\s+\w+\s*\([^;{}]*\)\s*\{",
    "java": r"\b(public|private|protected|static)[\w\s<>\[\],]*\s+\w+\s*\([^;{}]*\)\s*\{",
}

_SECURITY_PATTERNS = {
    "python": [r"\beval\s*\(", r"\bexec\s*\(", r"\bos\.system\s*\(", r"\bpickle\.loads\s*\("],
    "cpp": [r"\bgets\s*\(", r"\bstrcpy\s*\(", r"\bsystem\s*\(", r"\bsprintf\s*\("],
    "c": [r"\bgets\s*\(", r"\bstrcpy\s*\(", r"\bsystem\s*\(", r"\bsprintf\s*\("],
    "java": [r"Runtime\.getRuntime\(\)\.exec", r"\bnew\s+File\s*\(\s*request", r"\.executeQuery\s*\(\s*\""],
}


def generate_intelligence_report(language: str, source_code: str) -> dict:
    """
    Returns a structured dict for a dashboard-style report:
    {
      language, lines, functions, complexity,
      scores: {quality, performance, readability, security, maintainability},  # 0-100
      bugs, warnings, suggestions, security_issues,  # counts
      notes: [short strings]
    }
    """
    if _use_real_ai():
        prompt = (
            f"Analyze this {language} code and respond with ONLY a JSON object "
            f"(no markdown fences, no preamble) with exactly this shape:\n"
            f'{{"lines": <int>, "functions": <int>, "complexity": "<e.g. O(n^2)>", '
            f'"scores": {{"quality": <0-100 int>, "performance": <0-100 int>, '
            f'"readability": <0-100 int>, "security": <0-100 int>, "maintainability": <0-100 int>}}, '
            f'"bugs": <int count of likely bugs>, "warnings": <int count>, '
            f'"suggestions": <int count of improvement ideas>, "security_issues": <int count>, '
            f'"notes": [<up to 4 short strings, each under 15 words, one per notable finding>]}}\n\n'
            f"```{language}\n{source_code}\n```"
        )
        try:
            result = _call_claude(prompt, max_tokens=500)
            cleaned = re.sub(r"^```(?:json)?\n?|```$", "", result.strip())
            data = json.loads(cleaned)
            data["language"] = language
            return data
        except Exception:
            pass
    return _heuristic_intelligence_report(language, source_code)


def _heuristic_intelligence_report(language: str, source_code: str) -> dict:
    lines_list = [l for l in source_code.splitlines() if l.strip()]
    line_count = len(lines_list)

    func_pattern = _FUNC_PATTERNS.get(language.lower())
    functions = len(re.findall(func_pattern, source_code, re.MULTILINE)) if func_pattern else 0

    nested = len(re.findall(r"(for|while)[^\n]*\n(?:[^\n]*\n){0,3}?\s*(for|while)", source_code))
    triple_nested = len(re.findall(r"(for|while).*\n(?:.*\n){0,2}(for|while).*\n(?:.*\n){0,2}(for|while)", source_code))
    complexity = "O(n³)" if triple_nested else ("O(n²)" if nested else ("O(n)" if re.search(r"\bfor\b|\bwhile\b", source_code) else "O(1)"))

    comment_markers = {"python": r"#", "cpp": r"//", "c": r"//", "java": r"//"}
    marker = comment_markers.get(language.lower(), "#")
    commented = sum(1 for l in lines_list if l.strip().startswith(marker))
    comment_ratio = commented / line_count if line_count else 0

    long_lines = sum(1 for l in lines_list if len(l) > 100)
    short_var_names = len(re.findall(r"\b(?:let|var|int|double|float)\s+[a-z]\b\s*=", source_code))

    security_patterns = _SECURITY_PATTERNS.get(language.lower(), [])
    security_hits = sum(1 for p in security_patterns if re.search(p, source_code))

    # --- scores (heuristic, 0-100) ---
    quality = 90
    if nested: quality -= 15
    if long_lines: quality -= min(10, long_lines * 2)
    quality = max(30, quality)

    performance = 85 if not nested else (55 if not triple_nested else 30)

    readability = 90
    readability -= min(20, long_lines * 3)
    readability -= 10 if comment_ratio < 0.03 and line_count > 15 else 0
    readability -= short_var_names * 4
    readability = max(35, min(95, readability))

    security = 100 - security_hits * 25
    security = max(20, security)

    maintainability = round((quality + readability) / 2)

    notes = []
    if nested:
        notes.append(f"Nested loops detected — estimated {complexity} time complexity.")
    if long_lines:
        notes.append(f"{long_lines} line(s) over 100 characters — consider breaking them up.")
    if comment_ratio < 0.03 and line_count > 15:
        notes.append("Very few comments for the code's length.")
    if short_var_names:
        notes.append("Some single-letter variable names — consider more descriptive names.")
    if security_hits:
        notes.append(f"{security_hits} potentially risky call(s) found (e.g. unsanitized exec/system calls).")
    if not notes:
        notes.append("No obvious red flags found by the heuristic scanner.")
    notes.append("Heuristic report — set ANTHROPIC_API_KEY in app/config.py for a fully AI-generated analysis.")

    return {
        "language": language,
        "lines": line_count,
        "functions": functions,
        "complexity": complexity,
        "scores": {
            "quality": quality,
            "performance": performance,
            "readability": readability,
            "security": security,
            "maintainability": maintainability,
        },
        "bugs": 1 if nested and "for" in source_code and "range(len(" in source_code else 0,
        "warnings": long_lines + (1 if comment_ratio < 0.03 and line_count > 15 else 0),
        "suggestions": len(notes) - 1,
        "security_issues": security_hits,
        "notes": notes,
    }


# ---------------------------------------------------------- CORRECTNESS ---
# "How likely is this code to actually be right" -- distinct from the
# Intelligence Report's quality/readability/security/maintainability scores
# above, which grade code style, not whether it does what it's supposed to.
# This is inherently an estimate (there's no fixed expected output to check
# against in the free-form Student Workspace), so both the AI and heuristic
# paths are written to give a calibrated, hedged score rather than false
# confidence -- and a `run_result` is accepted so the score is grounded in
# what the code actually did on one real execution, not just static reading.

def correctness_score(language: str, source_code: str, run_result: dict = None, problem_description: str = "") -> dict:
    """Returns {"score": 0-100 int, "verdict": short label, "reasoning": [...], "risks": [...]}"""
    run_note = ""
    if run_result:
        run_note = (
            f"\n\nIt was just executed once for reference: status={run_result.get('status')}, "
            f"stdout={run_result.get('stdout', '')[:300]!r}, stderr={run_result.get('stderr', '')[:300]!r}."
        )
    intent_note = f"\n\nThe student says they're trying to: {problem_description}" if problem_description else ""

    if _use_real_ai():
        prompt = (
            f"Estimate how likely this {language} code is to be CORRECT -- that it does what it's "
            f"supposed to do and handles reasonable edge cases -- not just whether it runs without "
            f"crashing. Give a calibrated, honest percentage: don't default to a high score to be "
            f"agreeable, and don't claim certainty (avoid exactly 0 or 100 unless truly warranted). "
            f"There is no fixed expected output here, so base this on code reading plus the execution "
            f"evidence given.{intent_note}{run_note}\n\n"
            f'Respond with ONLY a JSON object (no markdown fences, no preamble) with exactly this shape:\n'
            f'{{"score": <0-100 int>, "verdict": "<one short line>", '
            f'"reasoning": [<up to 4 short bullets, each under 18 words, on what supports this score>], '
            f'"risks": [<up to 4 short bullets on edge cases/bugs that could make it wrong, or [] if none notable>]}}\n\n'
            f"```{language}\n{source_code}\n```"
        )
        try:
            result = _call_claude(prompt, max_tokens=500)
            cleaned = re.sub(r"^```(?:json)?\n?|```$", "", result.strip())
            data = json.loads(cleaned)
            data["score"] = max(0, min(100, int(data.get("score", 50))))
            data.setdefault("reasoning", [])
            data.setdefault("risks", [])
            return data
        except Exception:
            pass
    return _heuristic_correctness_score(language, source_code, run_result)


def _heuristic_correctness_score(language: str, source_code: str, run_result: dict = None) -> dict:
    status = (run_result or {}).get("status")
    reasoning, risks = [], []

    if status == "COMPILE_ERROR":
        return {
            "score": 5, "verdict": "Does not compile",
            "reasoning": ["The code failed to compile, so it can't be correct yet."],
            "risks": ["Fix the compile error before anything else can be judged."],
        }
    if status == "TIMEOUT":
        base = 20
        risks.append("Ran past the time limit -- check for an infinite loop or missing base case.")
    elif status == "RUNTIME_ERROR":
        base = 30
        risks.append("Crashed during execution -- check the traceback for the failing line.")
    elif status == "OK":
        base = 65
        reasoning.append("Ran without crashing on the given input.")
    else:
        base = 50
        reasoning.append("Not executed yet, so this is based on reading the code alone.")

    lower = source_code.lower()

    if re.search(r"\bassert\b|\bunittest\b|def\s+test_", source_code):
        base += 5
        reasoning.append("Includes some form of self-testing or assertions.")
    if re.search(r"if\s*\(?\s*len\(|if\s*\(?\s*\w+\s*==\s*0|\.empty\(\)|== null|is None", source_code):
        base += 5
        reasoning.append("Appears to guard against an empty/edge input somewhere.")
    if re.search(r"except\s*:\s*$", source_code, re.MULTILINE) or "except exception" in lower:
        base -= 5
        risks.append("Broad/bare exception handling can silently hide real bugs.")
    if language in ("c", "cpp") and re.search(r"\[\s*\w+\s*\+\s*1\s*\]|\[\s*\w+\s*-\s*1\s*\]", source_code):
        risks.append("Off-by-one-prone indexing (i+1 / i-1) -- double check array bounds.")
    if "todo" in lower or "fixme" in lower:
        base -= 10
        risks.append("Contains TODO/FIXME markers -- looks unfinished.")

    base = max(5, min(90, base))  # a heuristic guess never claims full certainty either way
    verdict = "Likely correct" if base >= 70 else ("Possibly correct, some risk" if base >= 45 else "Likely has issues")
    if not reasoning:
        reasoning.append("Based on a quick static check (no AI key configured, so this is a rough estimate).")
    if not risks:
        risks.append("No obvious red flags found in this quick check -- not a guarantee, though.")
    return {"score": base, "verdict": verdict, "reasoning": reasoning, "risks": risks}
