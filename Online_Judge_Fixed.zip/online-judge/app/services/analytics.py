"""Weakness detection, personalised roadmap, recommendations and faculty analytics.
Everything is computed from real submission rows -- no placeholder data."""
import datetime as dt
from collections import defaultdict, Counter
from sqlalchemy.orm import Session
from sqlalchemy import func

from app import models

DIFF_ORDER = {"Easy": 0, "Medium": 1, "Hard": 2}
VERDICT_ADVICE = {
    "Wrong Answer": ("Logic / edge cases", "Re-read the statement; test empty, single-element, negative and maximum inputs."),
    "Time Limit Exceeded": ("Efficiency", "Look for nested loops that can become a hash map, sort + two pointers, or prefix sums."),
    "Runtime Error": ("Robustness", "Check array bounds, division by zero, null/None access and recursion depth."),
    "Compilation Error": ("Syntax", "Compile locally and read the first error line; most later errors are knock-on effects."),
    "Memory Limit Exceeded": ("Memory", "Avoid storing everything; use iterative approaches and smaller data types."),
}


def _subs(db, user_id):
    return db.query(models.Submission).filter(models.Submission.user_id == user_id,
                                              models.Submission.verdict != "Pending").all()


def topic_stats(db: Session, user_id: int):
    """Per-topic performance for one student, with a 0..100 weakness score (higher = weaker)."""
    problems = db.query(models.Problem).filter(models.Problem.is_published == True).all()  # noqa: E712
    by_topic_problems = defaultdict(list)
    for p in problems:
        by_topic_problems[p.topic].append(p)
    subs = _subs(db, user_id)
    pid_topic = {p.id: p.topic for p in problems}
    attempts, ok_subs, solved = Counter(), Counter(), defaultdict(set)
    wrong_before_solve = Counter()
    first_ac = {}
    for s in sorted(subs, key=lambda s: (s.created_at, s.id)):
        t = pid_topic.get(s.problem_id)
        if t is None:
            continue
        attempts[t] += 1
        if s.verdict == "Accepted":
            ok_subs[t] += 1
            solved[t].add(s.problem_id)
            first_ac.setdefault(s.problem_id, True)
        elif s.problem_id not in first_ac:
            wrong_before_solve[t] += 1
    out = []
    for topic, plist in sorted(by_topic_problems.items()):
        a, ok = attempts[topic], ok_subs[topic]
        n_solved, total = len(solved[topic]), len(plist)
        acc = round(ok / a * 100, 1) if a else None
        if a == 0:
            weak, status = None, "Not started"
        else:
            fail_rate = 1 - ok / a
            unsolved_attempted = len({s.problem_id for s in subs if pid_topic.get(s.problem_id) == topic}) - n_solved
            attempted_problems = max(1, len({s.problem_id for s in subs if pid_topic.get(s.problem_id) == topic}))
            stuck = unsolved_attempted / attempted_problems
            retries = min(1.0, (wrong_before_solve[topic] / max(1, n_solved or 1)) / 5)
            weak = round(100 * (0.5 * fail_rate + 0.35 * stuck + 0.15 * retries))
            confidence = min(1.0, a / 4)          # few attempts => pull towards neutral instead of crying "weak"
            weak = round(weak * confidence + 30 * (1 - confidence))
            status = "Weak" if weak >= 55 else "Developing" if weak >= 30 else "Strong"
        out.append({"topic": topic, "attempts": a, "accepted_subs": ok, "solved": n_solved, "total": total,
                    "accuracy": acc, "weakness": weak, "status": status})
    return out


def verdict_breakdown(db: Session, user_id: int):
    c = Counter(s.verdict for s in _subs(db, user_id))
    return dict(c)


def error_insights(db: Session, user_id: int):
    c = verdict_breakdown(db, user_id)
    fails = [(v, n) for v, n in c.items() if v != "Accepted" and v in VERDICT_ADVICE]
    fails.sort(key=lambda x: -x[1])
    return [{"verdict": v, "count": n, "area": VERDICT_ADVICE[v][0], "advice": VERDICT_ADVICE[v][1]} for v, n in fails]


def _solved_ids(db, user_id):
    return {r[0] for r in db.query(models.Submission.problem_id).filter(
        models.Submission.user_id == user_id, models.Submission.verdict == "Accepted").distinct()}


def _target_difficulty(db, user_id):
    """Adaptive: move up once the student has solved most of their current tier."""
    solved = _solved_ids(db, user_id)
    pubs = db.query(models.Problem).filter(models.Problem.is_published == True).all()  # noqa: E712
    for tier in ("Easy", "Medium"):
        tier_p = [p for p in pubs if p.difficulty == tier]
        if tier_p and sum(1 for p in tier_p if p.id in solved) / len(tier_p) < 0.7:
            return tier
    return "Hard"


def recommend_problems(db: Session, user_id: int, limit: int = 6):
    solved = _solved_ids(db, user_id)
    stats = {t["topic"]: t for t in topic_stats(db, user_id)}
    target = _target_difficulty(db, user_id)
    attempted_unsolved = {r[0] for r in db.query(models.Submission.problem_id).filter(
        models.Submission.user_id == user_id).distinct()} - solved
    cands = []
    for p in db.query(models.Problem).filter(models.Problem.is_published == True).all():  # noqa: E712
        if p.id in solved:
            continue
        st = stats.get(p.topic, {})
        weak = st.get("weakness")
        score, reason = 0, ""
        if weak is not None and weak >= 30:
            score += 50 + weak / 2
            reason = f"Strengthen {p.topic} (weakness {weak}/100)"
        elif st.get("attempts", 0) == 0:
            score += 25
            reason = f"New topic: {p.topic}"
        else:
            score += 10
            reason = f"Keep practising {p.topic}"
        gap = abs(DIFF_ORDER.get(p.difficulty, 0) - DIFF_ORDER[target])
        score += 30 - 15 * gap
        if p.id in attempted_unsolved:
            score += 15
            reason = "Unfinished attempt - " + reason
        cands.append((score, p, reason))
    cands.sort(key=lambda x: (-x[0], x[1].id))
    return [{"problem": p, "reason": r} for _, p, r in cands[:limit]]


def build_roadmap(db: Session, user_id: int):
    """Ordered learning path: weakest attempted topics first, then untouched topics,
    then strong topics for reinforcement. Each topic has Easy -> Medium -> Hard steps whose
    completion is computed from real accepted submissions."""
    solved = _solved_ids(db, user_id)
    problems = db.query(models.Problem).filter(models.Problem.is_published == True).order_by(models.Problem.id).all()  # noqa: E712
    stats = topic_stats(db, user_id)

    def order_key(t):
        if t["status"] == "Weak": return (0, -(t["weakness"] or 0))
        if t["status"] == "Developing": return (1, -(t["weakness"] or 0))
        if t["status"] == "Not started": return (2, t["topic"])
        return (3, t["topic"])

    roadmap, found_current = [], False
    for t in sorted(stats, key=order_key):
        steps = []
        for diff in ("Easy", "Medium", "Hard"):
            plist = [p for p in problems if p.topic == t["topic"] and p.difficulty == diff]
            if not plist:
                continue
            done = sum(1 for p in plist if p.id in solved)
            steps.append({"difficulty": diff, "done": done, "total": len(plist),
                          "complete": done == len(plist),
                          "next": next((p for p in plist if p.id not in solved), None)})
        if not steps:
            continue
        complete = all(s["complete"] for s in steps)
        why = {"Weak": "Your results here need attention first.",
               "Developing": "You're making progress - consolidate it.",
               "Not started": "Not attempted yet - build a foundation.",
               "Strong": "Strong area - keep it sharp with harder problems."}[t["status"]]
        state = "done" if complete else ("current" if not found_current else "upcoming")
        if state == "current":
            found_current = True
        roadmap.append({"topic": t["topic"], "status": t["status"], "weakness": t["weakness"],
                        "state": state, "why": why, "steps": steps})
    return roadmap


# ------------------------------------------------------------- faculty side --
def class_overview(db: Session, days: int = 30):
    now = dt.datetime.utcnow()
    since = now - dt.timedelta(days=days)
    students = db.query(models.User).filter(models.User.role == "student").all()
    sid = [s.id for s in students]
    subs = db.query(models.Submission).filter(models.Submission.user_id.in_(sid)).all() if sid else []
    problems = {p.id: p for p in db.query(models.Problem).all()}

    per_topic = defaultdict(lambda: {"attempts": 0, "ok": 0, "students": set(), "solvers": set()})
    for s in subs:
        p = problems.get(s.problem_id)
        if not p or s.verdict == "Pending":
            continue
        t = per_topic[p.topic]
        t["attempts"] += 1
        t["students"].add(s.user_id)
        if s.verdict == "Accepted":
            t["ok"] += 1
            t["solvers"].add(s.user_id)
    topics = []
    for name, t in per_topic.items():
        acc = round(t["ok"] / t["attempts"] * 100, 1) if t["attempts"] else 0
        topics.append({"topic": name, "attempts": t["attempts"], "accuracy": acc,
                       "students": len(t["students"]), "solve_rate": round(len(t["solvers"]) / max(1, len(t["students"])) * 100)})
    topics.sort(key=lambda x: x["accuracy"])

    daily = Counter(s.created_at.date().isoformat() for s in subs if s.created_at >= since)
    series = []
    for i in range(days - 1, -1, -1):
        d = (now - dt.timedelta(days=i)).date().isoformat()
        series.append({"date": d, "count": daily.get(d, 0)})

    rows, at_risk = [], []
    by_user = defaultdict(list)
    for s in subs:
        by_user[s.user_id].append(s)
    for u in students:
        us = by_user.get(u.id, [])
        solved = len({s.problem_id for s in us if s.verdict == "Accepted"})
        acc = round(sum(1 for s in us if s.verdict == "Accepted") / len(us) * 100, 1) if us else 0
        last = max((s.created_at for s in us), default=None)
        row = {"user": u, "solved": solved, "submissions": len(us), "accuracy": acc, "xp": u.xp or 0, "last": last}
        rows.append(row)
        inactive = last is None or (now - last).days >= 7
        if inactive or (len(us) >= 5 and acc < 30):
            at_risk.append({**row, "reason": "No submissions in 7+ days" if inactive else "Low accuracy (<30%)"})
    rows.sort(key=lambda r: (-r["solved"], -r["accuracy"]))
    verdicts = Counter(s.verdict for s in subs if s.verdict != "Pending")
    return {"students": len(students), "submissions": len(subs), "topics": topics, "series": series,
            "rows": rows, "at_risk": at_risk, "verdicts": dict(verdicts),
            "active_week": len({s.user_id for s in subs if s.created_at >= now - dt.timedelta(days=7)}),
            "avg_accuracy": round(sum(r["accuracy"] for r in rows) / len(rows), 1) if rows else 0}
