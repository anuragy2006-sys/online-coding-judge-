"""XP, levels, badges, streaks and the activity heatmap -- all derived from real DB rows."""
import datetime as dt
from collections import Counter
from sqlalchemy.orm import Session
from sqlalchemy import func

from app import models

XP_FIRST_AC = {"Easy": 20, "Medium": 40, "Hard": 80}
XP_DAILY_ACTIVITY = 5
XP_STREAK_WEEK = 50
XP_CONTEST_JOIN = 30

BADGES = {
    "first_solve":   ("First Blood", "Solved your first problem", "🩸"),
    "solver_5":      ("High Five", "Solved 5 problems", "🖐️"),
    "solver_10":     ("Problem Crusher", "Solved 10 problems", "💪"),
    "solver_25":     ("Quarter Century", "Solved 25 problems", "🏅"),
    "hard_hitter":   ("Hard Hitter", "Solved a Hard problem", "🔥"),
    "polyglot":      ("Polyglot", "Solved problems in 3 different languages", "🌐"),
    "streak_3":      ("On a Roll", "3-day coding streak", "📈"),
    "streak_7":      ("Week Warrior", "7-day coding streak", "⚡"),
    "streak_30":     ("Unstoppable", "30-day coding streak", "🚀"),
    "contest_rookie":("Contestant", "Took part in a contest", "🏁"),
    "podium":        ("Podium Finish", "Top 3 in a finished contest", "🏆"),
    "perfectionist": ("Perfectionist", "Accepted on the very first attempt (5 times)", "🎯"),
}


def utcnow():
    return dt.datetime.utcnow()


def award_xp(db: Session, user: models.User, amount: int, reason: str, ref: str = "") -> bool:
    """Idempotent when ref is given: the same (reason, ref) is never awarded twice."""
    if ref:
        dup = db.query(models.XPEvent).filter_by(user_id=user.id, reason=reason, ref=ref).first()
        if dup:
            return False
    db.add(models.XPEvent(user_id=user.id, amount=amount, reason=reason, ref=ref))
    user.xp = (user.xp or 0) + amount
    return True


def streak_days(db: Session, user_id: int):
    """(current_streak, longest_streak). Current streak stays alive if the last
    active day was today OR yesterday (you still have today to continue it)."""
    rows = db.query(func.date(models.Submission.created_at)).filter(
        models.Submission.user_id == user_id).distinct().all()
    days = sorted({dt.date.fromisoformat(str(r[0])) for r in rows if r[0]})
    if not days:
        return 0, 0
    longest, run = 1, 1
    for a, b in zip(days, days[1:]):
        run = run + 1 if (b - a).days == 1 else 1
        longest = max(longest, run)
    today = utcnow().date()
    cur = 0
    if days[-1] >= today - dt.timedelta(days=1):
        cur, d = 1, days[-1]
        for prev in reversed(days[:-1]):
            if (d - prev).days == 1:
                cur += 1
                d = prev
            else:
                break
    return cur, longest


def heatmap(db: Session, user_id: int, weeks: int = 26):
    """Per-day submission counts for the last `weeks` weeks, laid out as week columns."""
    today = utcnow().date()
    start = today - dt.timedelta(days=weeks * 7 - 1)
    start -= dt.timedelta(days=(start.weekday() + 1) % 7)       # align to Sunday
    rows = db.query(func.date(models.Submission.created_at), func.count()).filter(
        models.Submission.user_id == user_id,
        models.Submission.created_at >= dt.datetime.combine(start, dt.time.min),
    ).group_by(func.date(models.Submission.created_at)).all()
    counts = {dt.date.fromisoformat(str(d)): c for d, c in rows}
    cols, d = [], start
    while d <= today:
        col = []
        for _ in range(7):
            col.append(None if d > today else {"date": d.isoformat(), "count": counts.get(d, 0)})
            d += dt.timedelta(days=1)
        cols.append(col)
    return cols


def solved_problem_rows(db: Session, user_id: int):
    return (db.query(models.Problem, func.min(models.Submission.created_at))
            .join(models.Submission, models.Submission.problem_id == models.Problem.id)
            .filter(models.Submission.user_id == user_id, models.Submission.verdict == "Accepted")
            .group_by(models.Problem.id).all())


def _has_badge(db, user_id, key):
    return db.query(models.UserBadge).filter_by(user_id=user_id, badge_key=key).first() is not None


def _grant(db, user, key, new):
    if not _has_badge(db, user.id, key):
        db.add(models.UserBadge(user_id=user.id, badge_key=key))
        new.append(key)


def evaluate_badges(db: Session, user: models.User):
    """Awards every badge the user has now earned. Returns list of newly-awarded keys."""
    new = []
    solved = solved_problem_rows(db, user.id)
    n = len(solved)
    if n >= 1: _grant(db, user, "first_solve", new)
    if n >= 5: _grant(db, user, "solver_5", new)
    if n >= 10: _grant(db, user, "solver_10", new)
    if n >= 25: _grant(db, user, "solver_25", new)
    if any(p.difficulty == "Hard" for p, _ in solved): _grant(db, user, "hard_hitter", new)
    langs = {r[0] for r in db.query(models.Submission.language).filter(
        models.Submission.user_id == user.id, models.Submission.verdict == "Accepted").distinct()}
    if len({"cpp" if l == "c++" else l for l in langs}) >= 3: _grant(db, user, "polyglot", new)
    cur, longest = streak_days(db, user.id)
    best = max(cur, longest)
    if best >= 3: _grant(db, user, "streak_3", new)
    if best >= 7: _grant(db, user, "streak_7", new)
    if best >= 30: _grant(db, user, "streak_30", new)
    if db.query(models.ContestParticipant).filter_by(user_id=user.id).first(): _grant(db, user, "contest_rookie", new)
    # first-attempt accepts
    first_try = 0
    for p, _ in solved:
        first = db.query(models.Submission).filter_by(user_id=user.id, problem_id=p.id).order_by(
            models.Submission.created_at, models.Submission.id).first()
        if first and first.verdict == "Accepted":
            first_try += 1
    if first_try >= 5: _grant(db, user, "perfectionist", new)
    return new


def on_submission(db: Session, user: models.User, submission: models.Submission, problem: models.Problem):
    """Call after a graded submission is saved. Returns {'xp': gained, 'badges': [keys]}."""
    gained = 0
    day = utcnow().date().isoformat()
    if award_xp(db, user, XP_DAILY_ACTIVITY, "Daily activity", ref=day):
        gained += XP_DAILY_ACTIVITY
    if submission.verdict == "Accepted":
        amt = XP_FIRST_AC.get(problem.difficulty, 20)
        if award_xp(db, user, amt, f"Solved: {problem.title}", ref=f"ac:{problem.id}"):
            gained += amt
    cur, _ = streak_days(db, user.id)
    if cur and cur % 7 == 0 and award_xp(db, user, XP_STREAK_WEEK, f"{cur}-day streak", ref=f"streak:{cur}:{day}"):
        gained += XP_STREAK_WEEK
    if submission.contest_id and award_xp(db, user, XP_CONTEST_JOIN, "Contest participation",
                                          ref=f"contest:{submission.contest_id}"):
        gained += XP_CONTEST_JOIN
    user.last_active_at = utcnow()
    db.flush()
    new_badges = evaluate_badges(db, user)
    db.commit()
    return {"xp": gained, "badges": new_badges}


def user_badges(db: Session, user_id: int):
    rows = db.query(models.UserBadge).filter_by(user_id=user_id).order_by(models.UserBadge.awarded_at).all()
    return [{"key": r.badge_key, "name": BADGES[r.badge_key][0], "desc": BADGES[r.badge_key][1],
             "icon": BADGES[r.badge_key][2], "at": r.awarded_at} for r in rows if r.badge_key in BADGES]


def level_progress(xp: int):
    lvl, need, rem = 1, 100, xp or 0
    while rem >= need:
        rem -= need
        lvl += 1
        need += 50
    return {"level": lvl, "into": rem, "need": need, "pct": round(rem / need * 100)}


def global_ranking(db: Session):
    """Rank = XP desc, then solved desc, then earliest registration. Only students/faculty with activity shown first."""
    users = db.query(models.User).all()
    solved = dict(db.query(models.Submission.user_id, func.count(func.distinct(models.Submission.problem_id)))
                  .filter(models.Submission.verdict == "Accepted").group_by(models.Submission.user_id).all())
    rows = [{"user": u, "xp": u.xp or 0, "solved": solved.get(u.id, 0)} for u in users]
    rows.sort(key=lambda r: (-r["xp"], -r["solved"], r["user"].id))
    for i, r in enumerate(rows, 1):
        r["rank"] = i
    return rows
