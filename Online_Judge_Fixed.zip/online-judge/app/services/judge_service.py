"""Runs a submission against a problem's public + hidden test cases and scores it."""
from app.services.executor import run_code
from app import models

STATUS_TO_VERDICT = {
    "COMPILE_ERROR": "Compilation Error",
    "INTERNAL_ERROR": "Judge Error",
    "TIMEOUT": "Time Limit Exceeded",
    "RUNTIME_ERROR": "Runtime Error",
    "MEMORY_LIMIT": "Memory Limit Exceeded",
    "SECURITY_VIOLATION": "Security Violation",
}


def _normalize(text: str) -> str:
    """Compare outputs ignoring trailing whitespace on each line and trailing blank lines."""
    lines = (text or "").strip().splitlines()
    return "\n".join(line.rstrip() for line in lines)


def judge_submission(language: str, source_code: str, problem: "models.Problem", only_public: bool = False):
    """
    Returns dict: verdict, passed_cases, total_cases, runtime_ms, max_memory_kb,
    error_message, score (0..problem.points, weighted partial credit) and
    case_results (per-case status; input/expected/output ONLY for public cases).
    Hidden test data is never returned to the student.
    """
    cases = [tc for tc in problem.test_cases if (tc.is_sample or not only_public)]
    cases.sort(key=lambda c: (not c.is_sample, c.id))     # public first
    points = problem.points or 100
    base = {"verdict": "Accepted", "passed_cases": 0, "total_cases": len(cases), "runtime_ms": 0,
            "max_memory_kb": 0, "error_message": "", "score": 0.0, "case_results": []}

    if not cases:
        base.update(verdict="No Test Cases", error_message="This problem has no test cases configured yet.")
        return base

    timeout = problem.time_limit_seconds or 2.0
    total_w = sum((c.weight or 1) for c in cases)
    passed_w = 0
    verdict = None
    max_rt, max_mem = 0.0, 0

    for idx, tc in enumerate(cases, start=1):
        res = run_code(language, source_code, tc.input_data, timeout=timeout)
        max_rt = max(max_rt, res.runtime_ms)
        max_mem = max(max_mem, res.memory_kb or 0)
        public = bool(tc.is_sample)
        entry = {"index": idx, "public": public, "status": "Passed", "runtime_ms": round(res.runtime_ms, 1)}

        if res.status in ("COMPILE_ERROR", "INTERNAL_ERROR", "SECURITY_VIOLATION"):
            base.update(verdict=STATUS_TO_VERDICT[res.status], passed_cases=0, error_message=res.stderr, score=0.0,
                        runtime_ms=0)
            base["case_results"] = []
            return base

        if res.status == "OK" and _normalize(res.stdout) == _normalize(tc.expected_output):
            passed_w += (tc.weight or 1)
            base["passed_cases"] += 1
        else:
            if res.status == "OK":
                this_verdict, entry["status"] = "Wrong Answer", "Wrong Answer"
            else:
                this_verdict = STATUS_TO_VERDICT.get(res.status, "Runtime Error")
                entry["status"] = this_verdict
            if public:
                entry.update(input=tc.input_data, expected=tc.expected_output,
                             output=res.stdout[:2000], stderr=(res.stderr or "")[:1000])
            if verdict is None:
                verdict = this_verdict
                where = f"public test case #{idx}" if public else f"hidden test case #{idx}"
                base["error_message"] = f"{this_verdict} on {where}."
                if public:
                    base["error_message"] += (
                        f"\nInput:\n{tc.input_data}\n\nExpected:\n{tc.expected_output}\n\nGot:\n{res.stdout[:2000]}"
                        + (f"\n\nError:\n{res.stderr[:1000]}" if res.stderr and res.status != "OK" else ""))
                elif res.status not in ("OK", "TIMEOUT") and res.stderr:
                    base["error_message"] += f"\n{res.stderr[:600]}"    # error text, not test data
        base["case_results"].append(entry)

    base["verdict"] = verdict or "Accepted"
    base["runtime_ms"] = round(max_rt, 2)
    base["max_memory_kb"] = max_mem
    base["score"] = round(points * passed_w / total_w, 2) if total_w else 0.0
    return base
