"""Contest lifecycle, scoring (points + time penalty) and leaderboard."""
import datetime as dt
from sqlalchemy.orm import Session
from app import models


def now():
    return dt.datetime.utcnow()


def status(c: models.Contest, at=None) -> str:
    at = at or now()
    if at < c.start_time: return "upcoming"
    if at >= c.end_time: return "ended"
    return "running"


def seconds_left(c: models.Contest, at=None) -> int:
    at = at or now()
    target = c.start_time if at < c.start_time else c.end_time
    return max(0, int((target - at).total_seconds()))


def join(db: Session, contest: models.Contest, user: models.User):
    p = db.query(models.ContestParticipant).filter_by(contest_id=contest.id, user_id=user.id).first()
    if not p:
        db.add(models.ContestParticipant(contest_id=contest.id, user_id=user.id))
        db.commit()
    return True


def is_contest_problem(contest, problem_id):
    return any(cp.problem_id == problem_id for cp in contest.problems)


def leaderboard(db: Session, contest: models.Contest):
    """Rank by total points (desc), then total penalty minutes (asc). Only submissions
    made inside [start, end) and tagged with this contest count."""
    cps = {cp.problem_id: cp for cp in contest.problems}
    subs = (db.query(models.Submission)
            .filter(models.Submission.contest_id == contest.id,
                    models.Submission.created_at >= contest.start_time,
                    models.Submission.created_at < contest.end_time)
            .order_by(models.Submission.created_at, models.Submission.id).all())
    table = {}
    for s in subs:
        cp = cps.get(s.problem_id)
        if not cp:
            continue
        row = table.setdefault(s.user_id, {"user": s.user, "per": {}, "points": 0.0, "penalty": 0, "solved": 0})
        cell = row["per"].setdefault(s.problem_id, {"best": 0.0, "wrong": 0, "ac_min": None, "tries": 0})
        cell["tries"] += 1
        pts = (s.score / (s.problem.points or 100)) * cp.points
        if pts > cell["best"]:
            cell["best"] = round(pts, 2)
        if s.verdict == "Accepted":
            if cell["ac_min"] is None:
                cell["ac_min"] = int((s.created_at - contest.start_time).total_seconds() // 60)
        elif cell["ac_min"] is None:
            cell["wrong"] += 1
    for row in table.values():
        for cell in row["per"].values():
            row["points"] += cell["best"]
            if cell["ac_min"] is not None:
                row["solved"] += 1
                row["penalty"] += cell["ac_min"] + cell["wrong"] * (contest.penalty_minutes or 0)
        row["points"] = round(row["points"], 2)
    rows = sorted(table.values(), key=lambda r: (-r["points"], r["penalty"], r["user"].id))
    # joined-but-no-submission participants are listed last
    present = set(table)
    for p in contest.participants:
        if p.user_id not in present:
            rows.append({"user": p.user, "per": {}, "points": 0.0, "penalty": 0, "solved": 0})
    for i, r in enumerate(rows, 1):
        r["rank"] = i
    return rows


def user_history(db: Session, user: models.User):
    out = []
    for p in db.query(models.ContestParticipant).filter_by(user_id=user.id).all():
        c = p.contest
        if status(c) != "ended":
            continue
        lb = leaderboard(db, c)
        mine = next((r for r in lb if r["user"].id == user.id), None)
        out.append({"contest": c, "rank": mine["rank"] if mine else None, "participants": len(lb),
                    "points": mine["points"] if mine else 0, "solved": mine["solved"] if mine else 0})
    out.sort(key=lambda x: x["contest"].end_time, reverse=True)
    return out
