"""
Extensions / package manager.

Lets any logged-in user install a library/module/package for one of the four
supported languages, and auto-detects which modules a piece of code imports
so the editor can show "installed" / "missing" status at a glance.

SECURITY NOTE (read this before deploying with real, untrusted students):
installing a package means running `pip install`, `apt-get install`, or
downloading + linking a `.jar` on the server, and this project's executor
already runs submitted code directly on the host (see executor.py's own
docstring) rather than in a real per-submission sandbox. Letting *any*
authenticated user trigger those installs is fine for a solo/dev setup, but
on a shared server it's effectively giving every user a slice of root-level
package-manager access -- a malicious package name/version, or a poisoned
package's install script, runs with the same privileges as the judge itself.
If this ever serves untrusted students, gate installs behind `require_admin`
(see app/auth.py) and curate an allow-list instead of installing anything.

Per-language mechanics:
  python -> `pip install <name>[==version]`, available immediately since the
            executor runs code with the same interpreter (sys.executable).
  c/cpp  -> `apt-get install -y <name>` (a `-dev` package for headers/libs).
            Optional `link_flags` (e.g. "-lcurl") are stored and appended to
            every future gcc/g++ compile command for that language.
  java   -> no per-run package manager exists for a single-file javac/java
            setup, so we resolve "<group>:<artifact>:<version>" against Maven
            Central, download the jar into JAVA_LIB_DIR, and add every jar in
            that directory to the classpath for every future compile/run.
"""
import os
import platform
import re
import shlex
import subprocess
import sys
import sysconfig

import httpx
from sqlalchemy.orm import Session

from app import models
from app.config import JAVA_LIB_DIR, PACKAGE_INSTALL_TIMEOUT_SECONDS

MAVEN_CENTRAL_BASE = "https://repo1.maven.org/maven2"
MAVEN_SEARCH_URL = "https://search.maven.org/solrsearch/select"
PYPI_JSON_URL = "https://pypi.org/pypi/{name}/json"
PYPI_SIMPLE_INDEX_URL = "https://pypi.org/simple/"

# Lazily-populated, process-lifetime cache of every PyPI package name (~875k
# entries, ~45MB fetched once) so name suggestions are instant after the
# first search instead of re-downloading the index on every keystroke.
_pypi_index_cache = None

# --------------------------------------------------------------------------
# Name validation. Everything below shells out to a real package manager, so
# these regexes are a hard allow-list, not a formatting nicety -- they are
# what stands between "install a library" and "install; rm -rf /".
# --------------------------------------------------------------------------
_PIP_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,213}$")
_APT_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9.+-]{0,127}$")
_MAVEN_COORD_RE = re.compile(
    r"^[A-Za-z0-9_.-]+:[A-Za-z0-9_.-]+:[A-Za-z0-9_.-]+$"  # group:artifact:version
)
_LINK_FLAG_RE = re.compile(r"^-l[A-Za-z0-9_-]+$")  # only "-lsomething", nothing else


class InstallResult:
    def __init__(self, ok: bool, message: str):
        self.ok = ok
        self.message = message


# --------------------------------------------------------------------------
# Standard-library detection, so we don't flag `os`, `<stdio.h>`, or
# `java.util.*` as "missing" -- only third-party modules matter here.
# --------------------------------------------------------------------------

def _python_stdlib_names() -> set:
    names = set(getattr(sys, "stdlib_module_names", ()))
    if names:
        return {n for n in names if not n.startswith("_")}
    # Fallback for very old Pythons without sys.stdlib_module_names.
    stdlib_dir = sysconfig.get_paths()["stdlib"]
    try:
        return {
            f.split(".")[0] for f in os.listdir(stdlib_dir)
            if not f.startswith("_")
        }
    except OSError:
        return set()


_C_STDLIB_HEADERS = {
    "stdio.h", "stdlib.h", "string.h", "math.h", "time.h", "ctype.h",
    "limits.h", "float.h", "assert.h", "errno.h", "stddef.h", "stdbool.h",
    "stdint.h", "signal.h", "setjmp.h", "locale.h", "stdarg.h", "wchar.h",
    "wctype.h", "iso646.h", "complex.h", "tgmath.h", "fenv.h", "inttypes.h",
    "uchar.h",
}

_CPP_STDLIB_HEADERS = _C_STDLIB_HEADERS | {
    "iostream", "vector", "string", "algorithm", "map", "set", "unordered_map",
    "unordered_set", "queue", "stack", "cmath", "cstdio", "cstdlib", "cstring",
    "utility", "functional", "numeric", "bitset", "memory", "sstream", "fstream",
    "iomanip", "tuple", "array", "list", "deque", "climits", "cfloat", "ctime",
    "chrono", "thread", "mutex", "random", "regex", "initializer_list",
    "type_traits", "iterator", "exception", "stdexcept", "typeinfo", "limits",
    "atomic", "condition_variable", "future", "optional", "variant", "any",
    "filesystem", "cassert", "cctype", "cwchar", "valarray", "forward_list",
    "multimap", "multiset", "ratio", "complex",
}

PYTHON_STDLIB = _python_stdlib_names()


def _java_is_stdlib(module: str) -> bool:
    return module.startswith("java.") or module.startswith("javax.")


def _c_family_is_stdlib(header: str, cpp: bool) -> bool:
    header = header.strip().strip('"<>')
    pool = _CPP_STDLIB_HEADERS if cpp else _C_STDLIB_HEADERS
    return header in pool


# --------------------------------------------------------------------------
# Import/include detection
# --------------------------------------------------------------------------

_PY_IMPORT_RE = re.compile(r"^\s*import\s+([A-Za-z0-9_.]+)", re.MULTILINE)
_PY_FROM_RE = re.compile(r"^\s*from\s+([A-Za-z0-9_.]+)\s+import", re.MULTILINE)
_C_INCLUDE_RE = re.compile(r'^\s*#\s*include\s*[<"]([^>"]+)[>"]', re.MULTILINE)
_JAVA_IMPORT_RE = re.compile(r"^\s*import\s+(?:static\s+)?([A-Za-z0-9_.]+(?:\.\*)?)\s*;", re.MULTILINE)


def detect_modules(language: str, source_code: str):
    """Return a sorted list of top-level module/header/package names referenced
    in the given source code (best-effort static scan, not a real parser)."""
    language = language.lower()
    found = set()
    if language == "python":
        for m in _PY_IMPORT_RE.finditer(source_code):
            found.add(m.group(1).split(".")[0])
        for m in _PY_FROM_RE.finditer(source_code):
            found.add(m.group(1).split(".")[0])
    elif language == "c":
        for m in _C_INCLUDE_RE.finditer(source_code):
            found.add(m.group(1))
    elif language in ("cpp", "c++"):
        for m in _C_INCLUDE_RE.finditer(source_code):
            found.add(m.group(1))
    elif language == "java":
        for m in _JAVA_IMPORT_RE.finditer(source_code):
            pkg = m.group(1)
            # Keep it at "group.artifact-ish" granularity: java.util.List -> java.util
            parts = pkg.split(".")
            found.add(".".join(parts[:-1]) if len(parts) > 1 else pkg)
    return sorted(found)


def _python_import_names_for_distribution(dist_name: str) -> set:
    """What top-level modules does the pip package `dist_name` actually let you
    `import`? This is the fix for the class of bug where a package's PyPI/pip
    name doesn't match what you import (beautifulsoup4 -> bs4, Pillow -> PIL,
    opencv-python -> cv2, PyYAML -> yaml, ...): comparing the pip name string
    against the import string directly makes a correctly-installed, working
    package look "missing". importlib.metadata knows the real mapping because
    it reads the package's own installed metadata -- no hardcoded table needed,
    and it's automatically right for every package, not just well-known ones."""
    try:
        import importlib.metadata as im
    except ImportError:
        return set()
    try:
        dist = im.distribution(dist_name)
    except im.PackageNotFoundError:
        return set()
    names = set()
    try:
        top_level = dist.read_text("top_level.txt")
        if top_level:
            names.update(line.strip() for line in top_level.splitlines() if line.strip())
    except Exception:
        pass
    if not names:
        # Fall back to the reverse index (import_name -> [dist_names]) for
        # packages that don't ship top_level.txt (common with newer build
        # backends like hatchling/flit).
        try:
            for import_name, dists in im.packages_distributions().items():
                if any(d.lower() == dist_name.lower() for d in dists):
                    names.add(import_name)
        except Exception:
            pass
    if not names:
        names.add(dist_name.replace("-", "_"))  # last-resort guess
    return names


def _apt_headers_for_package(pkg_name: str) -> set:
    """What header files does the apt package `pkg_name` actually install? Same
    fix as above but for C/C++: apt package names (libcurl4-openssl-dev) don't
    look anything like the #include path they provide (curl/curl.h), so string
    comparison always says "missing" even when it compiled and ran fine. `dpkg
    -L` is the source of truth -- it lists every file the package actually put
    on disk -- so we filter that down to headers instead of guessing."""
    try:
        proc = subprocess.run(
            ["dpkg", "-L", pkg_name], capture_output=True, text=True, timeout=10
        )
    except Exception:
        return set()
    if proc.returncode != 0:
        return set()
    headers = set()
    for line in proc.stdout.splitlines():
        line = line.strip()
        if "/include/" not in line or not (line.endswith(".h") or line.endswith(".hpp")):
            continue
        rel = line.split("/include/", 1)[1]   # e.g. "x86_64-linux-gnu/curl/curl.h"
        headers.add(rel)
        headers.add(os.path.basename(rel))     # e.g. "curl.h", for a bare #include <curl.h>
        # Debian multiarch installs headers under an extra "<triplet>/" directory
        # (e.g. /usr/include/x86_64-linux-gnu/curl/curl.h) that never appears in
        # the #include path the user actually writes (#include <curl/curl.h>) --
        # strip the first path segment too so that still matches.
        parts = rel.split("/", 1)
        if len(parts) == 2:
            headers.add(parts[1])              # e.g. "curl/curl.h"
    return headers


def check_modules(db: Session, language: str, source_code: str):
    """Detect modules in source_code and classify each as stdlib / installed / missing."""
    language = language.lower()
    modules = detect_modules(language, source_code)
    installed_rows = db.query(models.InstalledPackage).filter(
        models.InstalledPackage.language == language,
        models.InstalledPackage.status == "installed",
    ).all()
    installed_names = {p.name for p in installed_rows}

    results = []
    for mod in modules:
        if language == "python":
            is_std = mod in PYTHON_STDLIB
            is_installed = is_std or any(
                mod in _python_import_names_for_distribution(name)
                for name in installed_names
            )
        elif language in ("c", "cpp", "c++"):
            is_std = _c_family_is_stdlib(mod, cpp=language != "c")
            header = mod.strip().strip('"<>')
            is_installed = is_std or any(
                header in _apt_headers_for_package(name) for name in installed_names
            )
        elif language == "java":
            is_std = _java_is_stdlib(mod)
            is_installed = is_std or any(
                name.startswith(f"{mod}:") or name.split(":")[0] == mod
                for name in installed_names
            )
        else:
            is_std, is_installed = False, False

        status = "stdlib" if is_std else ("installed" if is_installed else "missing")
        results.append({"name": mod, "status": status})
    return results


# --------------------------------------------------------------------------
# Install / uninstall
# --------------------------------------------------------------------------

def list_packages(db: Session, language: str = None):
    q = db.query(models.InstalledPackage)
    if language:
        q = q.filter(models.InstalledPackage.language == language.lower())
    return q.order_by(models.InstalledPackage.created_at.desc()).all()


def install_package(db: Session, language: str, name: str, version: str = "",
                     link_flags: str = "", user=None) -> InstallResult:
    """Blocking. Callers in an async route MUST run this via asyncio.to_thread --
    it shells out to pip/apt/network and can take tens of seconds."""
    language = language.lower()
    name = (name or "").strip()
    version = (version or "").strip()
    link_flags = (link_flags or "").strip()

    if not name:
        return InstallResult(False, "Package name is required.")

    if language == "python":
        return _install_pip(db, name, version, user)
    elif language == "c":
        return _install_apt(db, "c", name, link_flags, user)
    elif language in ("cpp", "c++"):
        return _install_apt(db, "cpp", name, link_flags, user)
    elif language == "java":
        return _install_maven_jar(db, name, user)
    else:
        return InstallResult(False, f"Unsupported language: {language}")


def uninstall_package(db: Session, pkg: "models.InstalledPackage") -> InstallResult:
    """Actually remove the package from the machine -- not just its database
    row. This function's own log gets shown to the user (see extensions_router
    .py), so a real failure here is visible instead of the UI silently saying
    "removed" while the package is still sitting on disk."""
    log = ""
    try:
        if pkg.language == "python":
            if not _PIP_NAME_RE.match(pkg.name):
                return InstallResult(False, "Refusing to uninstall: stored package name failed validation.")
            proc = subprocess.run(
                [sys.executable, "-m", "pip", "uninstall", "-y", "--break-system-packages", pkg.name],
                capture_output=True, text=True, timeout=PACKAGE_INSTALL_TIMEOUT_SECONDS,
            )
            log = (proc.stdout or "") + "\n" + (proc.stderr or "")
            if proc.returncode != 0 and "no such option" in log.lower():
                # Same older-pip fallback as _install_pip: retry without the flag.
                proc = subprocess.run(
                    [sys.executable, "-m", "pip", "uninstall", "-y", pkg.name],
                    capture_output=True, text=True, timeout=PACKAGE_INSTALL_TIMEOUT_SECONDS,
                )
                log = (proc.stdout or "") + "\n" + (proc.stderr or "")
            # "not installed" is not a failure -- it means the goal (package gone
            # from this machine) is already true, so treat it the same as success.
            already_gone = "not installed" in log.lower()
            if proc.returncode != 0 and not already_gone:
                return InstallResult(False, f"pip uninstall failed:\n{log.strip()[-1500:]}")

        elif pkg.language in ("c", "cpp"):
            if not _APT_NAME_RE.match(pkg.name):
                return InstallResult(False, "Refusing to remove: stored package name failed validation.")
            # purge (not just remove) so config files go too, then autoremove any
            # dependency apt pulled in solely for this package -- "remove
            # everywhere" means actually gone, not just unlinked from dpkg's list.
            proc = subprocess.run(
                ["apt-get", "purge", "-y", pkg.name],
                capture_output=True, text=True, timeout=PACKAGE_INSTALL_TIMEOUT_SECONDS,
            )
            log = (proc.stdout or "") + "\n" + (proc.stderr or "")
            if proc.returncode != 0:
                return InstallResult(False, f"apt-get purge failed:\n{log.strip()[-1500:]}")
            try:
                subprocess.run(
                    ["apt-get", "autoremove", "-y"],
                    capture_output=True, text=True, timeout=PACKAGE_INSTALL_TIMEOUT_SECONDS,
                )
            except Exception:
                pass  # best-effort cleanup of orphaned deps; the package itself is already gone

        elif pkg.language == "java" and pkg.jar_filename:
            jar_path = os.path.join(JAVA_LIB_DIR, pkg.jar_filename)
            if os.path.isfile(jar_path):
                if os.path.dirname(os.path.abspath(jar_path)) != os.path.abspath(JAVA_LIB_DIR):
                    return InstallResult(False, "Refusing to remove: jar path escaped the library directory.")
                os.remove(jar_path)
                log = f"Removed {pkg.jar_filename} from the Java classpath directory."

        # The package is actually gone from the machine now -- clean up every
        # DB row for this (language, name), not just the one that was clicked.
        # Installing the same package twice (or re-installing after a name
        # typo) can leave duplicate rows; leaving the others behind would show
        # "installed" for something that's now gone from every place it runs.
        siblings = db.query(models.InstalledPackage).filter(
            models.InstalledPackage.language == pkg.language,
            models.InstalledPackage.name == pkg.name,
        ).all()
        for row in siblings:
            db.delete(row)
        db.commit()
        return InstallResult(True, log.strip()[-1500:] or "Removed.")
    except subprocess.TimeoutExpired:
        return InstallResult(False, "Removal timed out -- the package may be partially removed. Try again.")
    except Exception as e:
        return InstallResult(False, f"Failed to remove: {e}")


def _record(db, language, name, version, link_flags, jar_filename, status, log, user):
    row = models.InstalledPackage(
        language=language, name=name, version=version, link_flags=link_flags,
        jar_filename=jar_filename, status=status, log=log[-4000:],
        installed_by_id=(user.id if user else None),
    )
    db.add(row)
    db.commit()
    return row


def _ensure_pip_available(timeout: int):
    """Return (ok: bool, log: str). Some Python installs (this shows up mostly
    on Windows -- python.org's installer normally bundles pip, but a corrupted
    install, a custom/embeddable build, or certain Windows Store builds can
    end up without it) have no `pip` module at all, so `python -m pip install
    ...` fails immediately with "No module named pip" no matter what you're
    trying to install. `ensurepip` is the stdlib's own fix for exactly this --
    it's been bundled with Python since 3.4 specifically to bootstrap pip when
    it's missing -- so we try that once before giving up."""
    try:
        check = subprocess.run(
            [sys.executable, "-m", "pip", "--version"],
            capture_output=True, text=True, timeout=15,
        )
        if check.returncode == 0:
            return True, ""
    except Exception:
        pass

    try:
        boot = subprocess.run(
            [sys.executable, "-m", "ensurepip", "--upgrade"],
            capture_output=True, text=True, timeout=timeout,
        )
    except Exception as e:
        return False, f"Could not bootstrap pip via ensurepip: {e}"

    log = (boot.stdout or "") + "\n" + (boot.stderr or "")
    return boot.returncode == 0, log


def _run_pip_install(target: str, use_break_system_packages: bool, timeout: int):
    cmd = [sys.executable, "-m", "pip", "install"]
    if use_break_system_packages:
        # Needed on Debian/Ubuntu-style "externally managed" Python installs;
        # harmless elsewhere on pip >= 23.1, but an *older* pip that doesn't
        # recognize the flag at all will reject it with "no such option" --
        # the caller retries without it if that specific failure shows up.
        cmd.append("--break-system-packages")
    cmd.append(target)
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


def _install_pip(db, name, version, user) -> InstallResult:
    if not _PIP_NAME_RE.match(name):
        return InstallResult(False, "Invalid Python package name.")
    if version and not re.match(r"^[A-Za-z0-9_.\-]+$", version):
        return InstallResult(False, "Invalid version string.")

    target = f"{name}=={version}" if version else name

    pip_ok, bootstrap_log = _ensure_pip_available(PACKAGE_INSTALL_TIMEOUT_SECONDS)
    if not pip_ok:
        msg = (
            "This server's Python has no working `pip`, and automatically bootstrapping it "
            "via `python -m ensurepip` also failed. Fix it on the server itself, then retry: "
            "reinstall Python from python.org with 'pip' left checked during setup, or run "
            "`python -m ensurepip --upgrade` manually in a terminal there.\n\n" + bootstrap_log
        )
        _record(db, "python", name, version, "", "", "failed", msg, user)
        return InstallResult(False, msg.strip()[-1500:])

    try:
        proc = _run_pip_install(target, use_break_system_packages=True, timeout=PACKAGE_INSTALL_TIMEOUT_SECONDS)
        if proc.returncode != 0 and "no such option" in (proc.stderr or "").lower():
            # Older pip (pre-23.1) doesn't know this flag at all -- retry without it.
            proc = _run_pip_install(target, use_break_system_packages=False, timeout=PACKAGE_INSTALL_TIMEOUT_SECONDS)
    except subprocess.TimeoutExpired:
        _record(db, "python", name, version, "", "", "failed", "Install timed out.", user)
        return InstallResult(False, "Install timed out.")

    log = (proc.stdout or "") + "\n" + (proc.stderr or "")
    ok = proc.returncode == 0
    _record(db, "python", name, version, "", "", "installed" if ok else "failed", log, user)
    return InstallResult(ok, log.strip()[-1500:] or ("Installed." if ok else "Install failed."))


def _install_apt(db, lang_key, name, link_flags, user) -> InstallResult:
    if platform.system() != "Linux":
        # apt-get simply doesn't exist outside Debian/Ubuntu-family Linux --
        # trying anyway would either crash with FileNotFoundError or, worse,
        # silently do nothing useful. Fail clearly instead of pretending this
        # could work on Windows/macOS.
        msg = (
            "C/C++ package installs use apt-get, which is only available on Debian/Ubuntu Linux. "
            "This server is running " + platform.system() + " -- install the library manually there "
            "(e.g. MSYS2/vcpkg on Windows, Homebrew on macOS)."
        )
        _record(db, lang_key, name, "", link_flags, "", "failed", msg, user)
        return InstallResult(False, msg)

    if not _APT_NAME_RE.match(name):
        return InstallResult(False, "Invalid apt package name (lowercase letters, digits, . + - only).")
    flags = link_flags.split() if link_flags else []
    for f in flags:
        if not _LINK_FLAG_RE.match(f):
            return InstallResult(False, f"Invalid link flag '{f}' -- only '-lNAME' flags are allowed.")

    try:
        subprocess.run(["apt-get", "update"], capture_output=True, text=True, timeout=PACKAGE_INSTALL_TIMEOUT_SECONDS)
        proc = subprocess.run(
            ["apt-get", "install", "-y", name],
            capture_output=True, text=True, timeout=PACKAGE_INSTALL_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired:
        _record(db, lang_key, name, "", link_flags, "", "failed", "Install timed out.", user)
        return InstallResult(False, "Install timed out.")
    except OSError as e:
        msg = f"Could not run apt-get on this server: {e}"
        _record(db, lang_key, name, "", link_flags, "", "failed", msg, user)
        return InstallResult(False, msg)

    log = (proc.stdout or "") + "\n" + (proc.stderr or "")
    ok = proc.returncode == 0
    _record(db, lang_key, name, "", " ".join(flags), "", "installed" if ok else "failed", log, user)
    return InstallResult(ok, log.strip()[-1500:] or ("Installed." if ok else "Install failed."))


def _install_maven_jar(db, coordinate, user) -> InstallResult:
    coordinate = coordinate.strip()
    if not _MAVEN_COORD_RE.match(coordinate):
        return InstallResult(False, "Java packages must be given as 'group:artifact:version', e.g. com.google.code.gson:gson:2.11.0")

    group, artifact, version = coordinate.split(":")
    group_path = group.replace(".", "/")
    jar_url = f"{MAVEN_CENTRAL_BASE}/{group_path}/{artifact}/{version}/{artifact}-{version}.jar"
    jar_filename = f"{artifact}-{version}.jar"
    dest_path = os.path.join(JAVA_LIB_DIR, jar_filename)

    try:
        with httpx.Client(timeout=PACKAGE_INSTALL_TIMEOUT_SECONDS, follow_redirects=True) as client:
            resp = client.get(jar_url)
        if resp.status_code != 200:
            msg = f"Could not fetch {jar_url} (HTTP {resp.status_code}). Check the coordinate is correct on Maven Central."
            _record(db, "java", coordinate, version, "", "", "failed", msg, user)
            return InstallResult(False, msg)
        with open(dest_path, "wb") as f:
            f.write(resp.content)
    except httpx.HTTPError as e:
        msg = f"Network error fetching jar from Maven Central: {e}"
        _record(db, "java", coordinate, version, "", "", "failed", msg, user)
        return InstallResult(False, msg)

    _record(db, "java", coordinate, version, "", jar_filename, "installed",
            f"Downloaded {jar_filename} from Maven Central.", user)
    return InstallResult(True, f"Downloaded {jar_filename} and added it to the classpath.")


def java_classpath_arg() -> str:
    """All cached jars, colon-joined, for -cp on javac/java. Empty string if none."""
    if not os.path.isdir(JAVA_LIB_DIR):
        return ""
    jars = sorted(f for f in os.listdir(JAVA_LIB_DIR) if f.endswith(".jar"))
    return ":".join(os.path.join(JAVA_LIB_DIR, j) for j in jars)


def c_family_link_flags(db: Session, lang_key: str):
    """All stored link flags for installed c/cpp packages, as a flat arg list."""
    rows = db.query(models.InstalledPackage).filter(
        models.InstalledPackage.language == lang_key,
        models.InstalledPackage.status == "installed",
        models.InstalledPackage.link_flags != "",
    ).all()
    flags = []
    for r in rows:
        flags.extend(shlex.split(r.link_flags))
    return flags


# --------------------------------------------------------------------------
# Autocomplete / "latest version" lookup for the install form. Callers in an
# async route MUST run these via asyncio.to_thread -- they're blocking network
# calls (or a subprocess call for apt), same reasoning as install_package.
# --------------------------------------------------------------------------

def _pypi_simple_index() -> list:
    global _pypi_index_cache
    if _pypi_index_cache is not None:
        return _pypi_index_cache
    try:
        resp = httpx.get(PYPI_SIMPLE_INDEX_URL, timeout=25, follow_redirects=True)
        resp.raise_for_status()
        names = re.findall(r"<a[^>]*>([^<]+)</a>", resp.text)
        _pypi_index_cache = sorted(set(names))
    except httpx.HTTPError:
        _pypi_index_cache = []  # don't cache a failure permanently as "no packages"
        return []
    return _pypi_index_cache


def search_python_packages(query: str, limit: int = 15):
    """Local prefix/substring search over the cached PyPI simple index -- PyPI
    has no public typeahead-search API, so this is what makes "type and see
    matching package names" possible without hitting PyPI on every keystroke."""
    query = (query or "").strip().lower()
    if len(query) < 2:
        return []
    index = _pypi_simple_index()
    if not index:
        return []
    prefix = sorted(
        (n for n in index if n.lower().startswith(query)),
        key=lambda n: (len(n), n.lower()),  # shorter/closer names first, then alphabetical
    )
    if len(prefix) >= limit:
        return prefix[:limit]
    prefix_set = set(prefix)
    substr = sorted(
        (n for n in index if query in n.lower() and n not in prefix_set),
        key=lambda n: (len(n), n.lower()),
    )
    return (prefix + substr)[:limit]


def pypi_latest_version(name: str):
    """The actual 'fill in the latest version automatically' lookup for Python."""
    name = (name or "").strip()
    if not name or not _PIP_NAME_RE.match(name):
        return None
    try:
        resp = httpx.get(PYPI_JSON_URL.format(name=name), timeout=10, follow_redirects=True)
        if resp.status_code != 200:
            return None
        return resp.json().get("info", {}).get("version")
    except (httpx.HTTPError, ValueError):
        return None


def search_maven_packages(query: str, limit: int = 15):
    """Maven Central's real search API -- unlike PyPI, it directly returns each
    match's latest version, so a selected suggestion can fill the whole
    group:artifact:version coordinate in one step."""
    query = (query or "").strip()
    if len(query) < 2:
        return []
    try:
        resp = httpx.get(
            MAVEN_SEARCH_URL,
            params={"q": f"a:{query}*", "rows": limit, "wt": "json"},
            timeout=10,
        )
        if resp.status_code != 200:
            return []
        docs = resp.json().get("response", {}).get("docs", [])
    except (httpx.HTTPError, ValueError):
        return []
    return [
        {"group": d.get("g"), "artifact": d.get("a"), "version": d.get("latestVersion") or d.get("v")}
        for d in docs
        if d.get("g") and d.get("a")
    ]


_APT_SEARCH_QUERY_RE = re.compile(r"^[A-Za-z0-9 +._-]{2,80}$")


def search_apt_packages(query: str, limit: int = 15):
    """`apt-cache search` runs entirely against the local apt cache (already
    refreshed by `apt-get update` during installs), so this needs no network
    call and works even if outbound network is restricted. apt always installs
    whatever the repo's current version is -- there's no separate "latest
    version" to fill in for C/C++ the way there is for pip/Maven."""
    query = (query or "").strip()
    if not _APT_SEARCH_QUERY_RE.match(query):
        return []
    try:
        proc = subprocess.run(
            ["apt-cache", "search", "--", query], capture_output=True, text=True, timeout=10
        )
    except Exception:
        return []
    results = []
    for line in proc.stdout.splitlines():
        if " - " in line:
            name, desc = line.split(" - ", 1)
        else:
            name, desc = line, ""
        results.append({"name": name.strip(), "description": desc.strip()})
        if len(results) >= limit:
            break
    return results
