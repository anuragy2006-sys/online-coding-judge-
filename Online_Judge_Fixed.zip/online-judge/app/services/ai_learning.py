"""
AI learning features: personalised tutor chat, progressive hints, line-by-line explanation.

With ANTHROPIC_API_KEY set these call Claude (with the student's real problem,
code and verdict as context). Without a key they fall back to rule-based logic
that still uses the student's actual code, verdict and the problem's topic --
no canned lorem-ipsum. Tutor/hint prompts forbid handing over complete solutions.
"""
import re
import json
import httpx

from app.config import ANTHROPIC_API_KEY, ANTHROPIC_MODEL
from app.services import ai_review

ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"

TUTOR_SYSTEM = (
    "You are CodeJudge Tutor, a patient programming mentor inside an online judge used by college students. "
    "Teach rather than solve: ask guiding questions, point to the concept, explain errors, and show tiny "
    "snippets only when needed. NEVER output a complete working solution to the current problem. "
    "Keep answers under 180 words, use short paragraphs or bullets, and adapt to the student's level."
)


def _claude_chat(messages, system, max_tokens=600) -> str:
    headers = {"x-api-key": ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json"}
    body = {"model": ANTHROPIC_MODEL, "max_tokens": max_tokens, "system": system, "messages": messages}
    with httpx.Client(timeout=40) as client:
        r = client.post(ANTHROPIC_URL, headers=headers, json=body)
        r.raise_for_status()
        return "\n".join(b["text"] for b in r.json().get("content", []) if b.get("type") == "text").strip()


# ----------------------------------------------------------------- HINTS ----
_TOPIC_HINTS = {
    "arrays": ("Think about what information you need to carry while scanning the array once.",
               "A single pass with a running value (sum / max / count) usually works. Decide what the running value represents before the loop.",
               "Pseudo-code: initialise the accumulator -> for each element update it -> print it after the loop. Check n = 1 and negative numbers."),
    "strings": ("Break the string into the smallest unit you must compare or count.",
                "Consider two pointers (start/end) or a frequency table over characters. Decide how to handle case and spaces.",
                "Pseudo-code: normalise the string -> walk it with the chosen technique -> compare/collect -> print. Test an empty or 1-character string."),
    "math": ("Look for a formula or invariant before writing loops.",
             "Reduce the problem with modulo, gcd, or a closed form; check whether values can overflow 32-bit integers.",
             "Pseudo-code: derive the formula on paper for 3 small inputs -> implement -> verify against the samples. Use 64-bit types in C/C++/Java."),
    "sorting": ("Ask: does sorting the data first make the answer obvious?",
                "After sorting, neighbours or two pointers often solve it in one more pass. Cost: O(n log n).",
                "Pseudo-code: read -> sort -> sweep with two indices/neighbours -> output. Keep a copy if you need original positions."),
    "dynamic programming": ("Define the state: what is the smallest sub-question whose answer you can reuse?",
                            "Write the recurrence for dp[i] in terms of smaller indices and fix the base cases.",
                            "Pseudo-code: dp[0..n] init base cases -> for i in 1..n: dp[i] = combine(dp[i-1], dp[i-2], ...) -> answer dp[n]."),
    "recursion": ("Identify the base case and how the input shrinks on each call.",
                  "Write the recursive relation in words, then check it terminates for every input.",
                  "Pseudo-code: if base: return value; else return combine(f(smaller input)). Watch recursion depth limits."),
    "searching": ("If the data is sorted (or the answer is monotonic) you can halve the search space.",
                  "Binary search: keep lo/hi, test mid, discard half. Decide whether the loop uses <= or <.",
                  "Pseudo-code: lo=0, hi=n-1 -> while lo<=hi: mid=(lo+hi)//2 -> compare -> move lo or hi -> return result."),
    "hashing": ("What do you keep looking up again and again? A hash map/set makes that O(1).",
                "Store what you've seen (value -> index/count) while scanning once.",
                "Pseudo-code: empty map -> for each x: check the needed complement in the map -> then insert x."),
}
_GENERIC = (
    "Restate the problem in your own words and work the first sample by hand - what steps did you actually take?",
    "Turn those hand steps into an algorithm and estimate its complexity against the constraints.",
    "Pseudo-code: read input -> process with the algorithm you found -> print. Then try the smallest and largest valid inputs.",
)
_VERDICT_NOTE = {
    "Wrong Answer": "Your last attempt gave a Wrong Answer: re-check edge cases (empty/min/max values) and output formatting.",
    "Time Limit Exceeded": "Your last attempt was too slow: compare your loops against the constraint sizes and look for a faster idea.",
    "Runtime Error": "Your last attempt crashed: check index bounds, division by zero and input parsing.",
    "Compilation Error": "Your last attempt didn't compile: fix the first compiler error before anything else.",
    "Memory Limit Exceeded": "Your last attempt used too much memory: avoid copying large structures.",
}


def get_hint(level: int, problem, source_code: str = "", language: str = "python", last_verdict: str = "",
             last_error: str = "") -> dict:
    level = max(1, min(3, int(level)))
    if ANTHROPIC_API_KEY:
        names = {1: "a gentle conceptual nudge (no algorithm names)", 2: "the key idea / algorithm to use, in words",
                 3: "a step-by-step plan in pseudo-code (still NOT the final code)"}
        prompt = (f"Problem: {problem.title} (topic: {problem.topic}, difficulty: {problem.difficulty})\n"
                  f"{problem.description}\n\nConstraints: {problem.constraints}\n\n"
                  f"Student's {language} code:\n```\n{source_code[:4000]}\n```\nLast verdict: {last_verdict or 'none'}\n"
                  f"{('Error: ' + last_error[:500]) if last_error else ''}\n\n"
                  f"Give hint level {level}/3: {names[level]}. Never give the full solution. Max 90 words.")
        try:
            return {"level": level, "hint": _claude_chat([{"role": "user", "content": prompt}], TUTOR_SYSTEM, 300),
                    "source": "claude"}
        except Exception:
            pass
    bank = _TOPIC_HINTS.get((problem.topic or "").strip().lower(), _GENERIC)
    hint = bank[level - 1]
    note = _VERDICT_NOTE.get(last_verdict)
    if note and level >= 2:
        hint += "\n\n" + note
    if source_code.strip() and level == 3:
        rev = ai_review._heuristic_review(source_code)
        hint += "\n\nAbout your current code:\n" + rev[:500]
    return {"level": level, "hint": hint, "source": "rules"}


# ----------------------------------------------------------------- TUTOR ----
def tutor_reply(history, question: str, problem=None, source_code: str = "", language: str = "python",
                last_verdict: str = "", last_error: str = "") -> dict:
    ctx = ""
    if problem is not None:
        ctx += f"Current problem: {problem.title} [{problem.topic}, {problem.difficulty}]\n{problem.description[:1500]}\n"
    if source_code.strip():
        ctx += f"\nStudent's current {language} code:\n```\n{source_code[:3500]}\n```\n"
    if last_verdict:
        ctx += f"Last verdict: {last_verdict}\n{last_error[:500]}\n"
    if ANTHROPIC_API_KEY:
        msgs = [{"role": h["role"], "content": h["content"]} for h in history[-8:]]
        msgs.append({"role": "user", "content": (ctx + "\nStudent question: " + question).strip()})
        try:
            return {"reply": _claude_chat(msgs, TUTOR_SYSTEM, 600), "source": "claude"}
        except Exception:
            pass
    return {"reply": _rule_tutor(question, problem, source_code, language, last_verdict, last_error), "source": "rules"}


def _rule_tutor(q, problem, code, lang, verdict, err) -> str:
    ql = q.lower()
    if re.search(r"\b(error|wrong|fail|bug|not working|crash|why)\b", ql) and (err or verdict or code):
        parts = []
        if err:
            parts.append(ai_review._heuristic_error_explanation(err))
        elif verdict in _VERDICT_NOTE:
            parts.append(_VERDICT_NOTE[verdict])
        if code.strip():
            parts.append("Quick review of your code:\n" + ai_review._heuristic_review(code)[:600])
        if parts:
            return "\n\n".join(parts)
    if re.search(r"\b(optimi[sz]e|faster|complexity|time limit|tle|efficient)\b", ql) and code.strip():
        return ai_review._heuristic_review(code)[:900]
    if re.search(r"\b(explain|understand|what does)\b", ql) and code.strip():
        return ai_review._heuristic_teach_me(lang, code, problem.title if problem else "")[:1200]
    if problem is not None and re.search(r"\b(hint|stuck|approach|how|start|idea)\b", ql):
        return get_hint(2, problem, code, lang, verdict, err)["hint"]
    base = "I can help you reason about this step by step. "
    if problem is not None:
        base += f"For '{problem.title}' ({problem.topic}), try this: work the first sample by hand and write down each step. "
    base += ("Ask me about an error, the time complexity of your code, to explain a snippet, or for a hint. "
             "(Connect an Anthropic API key to unlock free-form conversational tutoring.)")
    return base


# ------------------------------------------------------- LINE BY LINE -------
_PY_RULES = [
    (r"^\s*import\s+(.+)", "Imports the module(s) {0} so their functions can be used."),
    (r"^\s*from\s+(\S+)\s+import\s+(.+)", "Imports {1} from the {0} module."),
    (r"^\s*def\s+(\w+)\s*\((.*)\)", "Defines a function named `{0}` taking ({1})."),
    (r"^\s*class\s+(\w+)", "Defines a class named `{0}`."),
    (r"^\s*for\s+(.+?)\s+in\s+(.+):", "Loop: repeats the block below, setting {0} to each item of {1}."),
    (r"^\s*while\s+(.+):", "Loop: keeps repeating the block below while `{0}` is true."),
    (r"^\s*elif\s+(.+):", "Else-if: if the earlier conditions failed and `{0}` is true, run the block below."),
    (r"^\s*if\s+(.+):", "Condition: runs the block below only when `{0}` is true."),
    (r"^\s*else\s*:", "Fallback: runs when none of the conditions above were true."),
    (r"^\s*try\s*:", "Starts a block where errors are caught instead of crashing."),
    (r"^\s*except\s*(.*):", "Handles errors of type {0} raised in the try block."),
    (r"^\s*return\b\s*(.*)", "Sends {0} back to the caller and leaves the function."),
    (r"^\s*print\s*\((.*)\)", "Prints {0} to the output."),
    (r"^\s*(\w+)\s*=\s*.*input\(\)", "Reads a line of input from the user and stores it in `{0}`."),
    (r"^\s*(\w+)\s*=\s*(.+)", "Creates/updates variable `{0}` with the value of {1}."),
    (r"^\s*(\w+)\s*([+\-*/%]=)\s*(.+)", "Updates `{0}` using {1} with {2}."),
    (r"^\s*break\b", "Exits the nearest loop immediately."),
    (r"^\s*continue\b", "Skips to the next iteration of the loop."),
]
_C_RULES = [
    (r"^\s*#\s*include\s*(.+)", "Includes the header {0} to use its library functions."),
    (r"^\s*using\s+namespace\s+(\w+)", "Lets you write names from `{0}` without the prefix."),
    (r"^\s*import\s+(.+);", "Imports {0}."),
    (r"^\s*(public\s+)?class\s+(\w+)", "Declares the class `{1}` (a container for the program)."),
    (r"^\s*(public\s+static\s+)?(int|void)\s+main\s*\(", "Program entry point - execution starts here."),
    (r"^\s*(int|long|double|float|char|bool|string|String|auto)\s+(\w+)\s*(=\s*(.+))?;", "Declares variable `{1}` of type {0}."),
    (r"^\s*for\s*\((.+)\)", "Loop: (init; condition; step) = ({0})."),
    (r"^\s*while\s*\((.+)\)", "Loop: repeats while `{0}` is true."),
    (r"^\s*else\s+if\s*\((.+)\)", "Else-if: checks `{0}` when earlier conditions failed."),
    (r"^\s*if\s*\((.+)\)", "Condition: runs the next block only if `{0}` is true."),
    (r"^\s*else\b", "Fallback when the conditions above were false."),
    (r"^\s*return\b\s*(.*);", "Returns {0} from the function."),
    (r"^\s*(printf|System\.out\.println?|cout)\b(.*)", "Prints output to the screen."),
    (r"^\s*(scanf|cin|sc\.next\w*|Scanner)\b(.*)", "Reads input from the user."),
    (r"^\s*break;", "Exits the nearest loop."),
    (r"^\s*continue;", "Skips to the next loop iteration."),
    (r"^\s*(\w+)\s*([+\-*/%]?=)\s*(.+);", "Assigns/updates `{0}` ({1}) using {2}."),
]


def _rule_line(line: str, lang: str) -> str:
    s = line.strip()
    if not s:
        return ""
    if s in ("{", "}", "};"):
        return "Marks the start/end of a code block."
    if s.startswith(("#", "//")) and not s.startswith("#include"):
        return "A comment - ignored by the computer, written for humans."
    rules = _PY_RULES if lang == "python" else _C_RULES
    for pat, tmpl in rules:
        m = re.match(pat, line)
        if m:
            try:
                return tmpl.format(*[(g or "").strip() for g in m.groups()])
            except (IndexError, KeyError):
                return tmpl
    return "Executes the statement `" + s[:60] + "`."


def explain_lines(language: str, source_code: str, level: str = "beginner") -> dict:
    lines = source_code.splitlines()[:150]
    if ANTHROPIC_API_KEY:
        numbered = "\n".join(f"{i}: {l}" for i, l in enumerate(lines, 1))
        prompt = (f"Explain this {language} code line by line for a {level}. Return ONLY a JSON array of objects "
                  f'{{"line": <number>, "explanation": "<one sentence>"}} covering every non-blank line.\n\n{numbered}')
        try:
            raw = _claude_chat([{"role": "user", "content": prompt}], "You explain code precisely and concisely.", 2500)
            data = json.loads(re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.M).strip())
            items = [{"line": int(d["line"]), "code": lines[int(d["line"]) - 1] if 0 < int(d["line"]) <= len(lines) else "",
                      "explanation": str(d["explanation"])} for d in data]
            return {"items": items, "source": "claude"}
        except Exception:
            pass
    items = [{"line": i, "code": l, "explanation": _rule_line(l, language)} for i, l in enumerate(lines, 1) if l.strip()]
    return {"items": items, "source": "rules"}
