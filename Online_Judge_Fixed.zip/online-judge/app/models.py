import datetime as dt
from sqlalchemy import (
    Column, Integer, String, Text, Boolean, DateTime, ForeignKey, Float
)
from sqlalchemy.orm import relationship
from app.database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    email = Column(String(120), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    is_admin = Column(Boolean, default=False)   # legacy flag, kept in sync with role == "admin"
    role = Column(String(20), default="student")  # student | faculty | admin
    xp = Column(Integer, default=0)
    bio = Column(Text, default="")
    last_active_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

    submissions = relationship("Submission", back_populates="user")
    bookmarks = relationship("Bookmark", back_populates="user")

    @property
    def is_staff(self):
        return bool(self.is_admin) or self.role in ("admin", "faculty")

    @property
    def level(self):
        # 100 XP per level at the start, slowly growing: level n needs 100*n*(n-1)/2*... keep simple & monotonic
        xp = self.xp or 0
        lvl = 1
        need = 100
        while xp >= need:
            xp -= need
            lvl += 1
            need += 50
        return lvl

    @property
    def solved_count(self):
        solved_ids = {
            s.problem_id for s in self.submissions if s.verdict == "Accepted"
        }
        return len(solved_ids)

    @property
    def total_submissions(self):
        return len(self.submissions)

    @property
    def accuracy(self):
        if not self.submissions:
            return 0
        ok = sum(1 for s in self.submissions if s.verdict == "Accepted")
        return round(ok / len(self.submissions) * 100, 1)


class Problem(Base):
    __tablename__ = "problems"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(150), nullable=False)
    slug = Column(String(160), unique=True, index=True, nullable=False)
    description = Column(Text, nullable=False)
    constraints = Column(Text, default="")
    difficulty = Column(String(10), default="Easy")   # Easy / Medium / Hard
    topic = Column(String(50), default="Arrays")
    time_limit_seconds = Column(Float, default=2.0)
    starter_code = Column(Text, default="")
    points = Column(Integer, default=100)
    is_published = Column(Boolean, default=True)
    tags = Column(String(200), default="")
    created_at = Column(DateTime, default=dt.datetime.utcnow)

    test_cases = relationship(
        "TestCase", back_populates="problem", cascade="all, delete-orphan"
    )
    # cascade="all, delete-orphan" here (matching test_cases above) is required, not optional:
    # Submission.problem_id and Bookmark.problem_id are both NOT NULL, so without an explicit
    # cascade SQLAlchemy's default delete behavior (try to null out the child FK) raises an
    # IntegrityError and the whole delete fails with a 500 for any problem that has real
    # submissions or bookmarks against it -- i.e. any problem actually used by students.
    submissions = relationship(
        "Submission", back_populates="problem", cascade="all, delete-orphan"
    )
    bookmarks = relationship(
        "Bookmark", back_populates="problem", cascade="all, delete-orphan"
    )


class TestCase(Base):
    __tablename__ = "test_cases"

    id = Column(Integer, primary_key=True, index=True)
    problem_id = Column(Integer, ForeignKey("problems.id"), nullable=False)
    input_data = Column(Text, default="")
    expected_output = Column(Text, default="")
    is_sample = Column(Boolean, default=False)  # True = public (shown to students); False = hidden
    weight = Column(Integer, default=1)

    problem = relationship("Problem", back_populates="test_cases")


class Submission(Base):
    __tablename__ = "submissions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    problem_id = Column(Integer, ForeignKey("problems.id"), nullable=False)
    language = Column(String(20), nullable=False)
    source_code = Column(Text, nullable=False)
    verdict = Column(String(30), default="Pending")
    runtime_ms = Column(Float, default=0)
    passed_cases = Column(Integer, default=0)
    total_cases = Column(Integer, default=0)
    error_message = Column(Text, default="")
    ai_review = Column(Text, default="")
    score = Column(Float, default=0)             # 0..problem.points
    contest_id = Column(Integer, ForeignKey("contests.id"), nullable=True)
    max_memory_kb = Column(Integer, default=0)
    similarity_score = Column(Float, default=0)  # highest similarity (0..100) vs other users
    created_at = Column(DateTime, default=dt.datetime.utcnow)

    user = relationship("User", back_populates="submissions")
    problem = relationship("Problem", back_populates="submissions")


class Bookmark(Base):
    __tablename__ = "bookmarks"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    problem_id = Column(Integer, ForeignKey("problems.id"), nullable=False)

    user = relationship("User", back_populates="bookmarks")
    problem = relationship("Problem", back_populates="bookmarks")


class InstalledPackage(Base):
    """A library/module/package made available to submitted code, for a given
    language. Installed on-demand from the Extensions page (see
    app/services/package_manager.py for how each language actually gets it)."""
    __tablename__ = "installed_packages"

    id = Column(Integer, primary_key=True, index=True)
    language = Column(String(10), nullable=False)      # python | c | cpp | java
    name = Column(String(200), nullable=False)          # pip name / apt pkg / "group:artifact:version"
    version = Column(String(50), default="")
    # C/C++ only: extra linker flags this package needs at compile time, e.g. "-lcurl -lssl".
    link_flags = Column(String(200), default="")
    # Java only: filename of the downloaded jar under app/../javalibs/, added to the classpath.
    jar_filename = Column(String(255), default="")
    status = Column(String(20), default="installed")    # installed | failed
    log = Column(Text, default="")
    installed_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

    installed_by = relationship("User")


# ------------------------------------------------------------------ upgrade ---

class XPEvent(Base):
    """Immutable XP ledger: User.xp is the sum of these rows."""
    __tablename__ = "xp_events"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    amount = Column(Integer, nullable=False)
    reason = Column(String(120), nullable=False)
    ref = Column(String(60), default="")          # e.g. "problem:12" -> prevents double awards
    created_at = Column(DateTime, default=dt.datetime.utcnow)


class UserBadge(Base):
    __tablename__ = "user_badges"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    badge_key = Column(String(50), nullable=False)
    awarded_at = Column(DateTime, default=dt.datetime.utcnow)


class Contest(Base):
    __tablename__ = "contests"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(150), nullable=False)
    slug = Column(String(160), unique=True, index=True, nullable=False)
    description = Column(Text, default="")
    start_time = Column(DateTime, nullable=False)   # stored in UTC
    end_time = Column(DateTime, nullable=False)
    penalty_minutes = Column(Integer, default=10)   # time penalty per wrong attempt
    is_published = Column(Boolean, default=True)
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

    problems = relationship("ContestProblem", back_populates="contest",
                            cascade="all, delete-orphan", order_by="ContestProblem.position")
    participants = relationship("ContestParticipant", back_populates="contest", cascade="all, delete-orphan")


class ContestProblem(Base):
    __tablename__ = "contest_problems"
    id = Column(Integer, primary_key=True)
    contest_id = Column(Integer, ForeignKey("contests.id"), nullable=False, index=True)
    problem_id = Column(Integer, ForeignKey("problems.id"), nullable=False)
    position = Column(Integer, default=0)
    points = Column(Integer, default=100)

    contest = relationship("Contest", back_populates="problems")
    problem = relationship("Problem")


class ContestParticipant(Base):
    __tablename__ = "contest_participants"
    id = Column(Integer, primary_key=True)
    contest_id = Column(Integer, ForeignKey("contests.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    joined_at = Column(DateTime, default=dt.datetime.utcnow)

    contest = relationship("Contest", back_populates="participants")
    user = relationship("User")


class SimilarityReport(Base):
    __tablename__ = "similarity_reports"
    id = Column(Integer, primary_key=True)
    submission_id = Column(Integer, ForeignKey("submissions.id"), nullable=False, index=True)
    other_submission_id = Column(Integer, ForeignKey("submissions.id"), nullable=False)
    problem_id = Column(Integer, ForeignKey("problems.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    other_user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    similarity = Column(Float, nullable=False)    # 0..100
    reviewed = Column(Boolean, default=False)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

    submission = relationship("Submission", foreign_keys=[submission_id])
    other_submission = relationship("Submission", foreign_keys=[other_submission_id])
    user = relationship("User", foreign_keys=[user_id])
    other_user = relationship("User", foreign_keys=[other_user_id])


class TutorMessage(Base):
    """Persisted AI-tutor conversation so a student can resume where they left off."""
    __tablename__ = "tutor_messages"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    problem_id = Column(Integer, ForeignKey("problems.id"), nullable=True)
    role = Column(String(10), nullable=False)     # user | assistant
    content = Column(Text, nullable=False)
    created_at = Column(DateTime, default=dt.datetime.utcnow)


class HintUsage(Base):
    __tablename__ = "hint_usage"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    problem_id = Column(Integer, ForeignKey("problems.id"), nullable=False)
    level = Column(Integer, nullable=False)       # 1..3
    created_at = Column(DateTime, default=dt.datetime.utcnow)
