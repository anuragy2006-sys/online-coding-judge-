/* CodeJudge AI shared front-end helpers: theme, mobile menu, toasts, fetch wrapper, timers. */
(function () {
  const root = document.documentElement;
  const saved = localStorage.getItem('cj-theme');
  const prefersLight = window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches;
  root.dataset.theme = saved || (prefersLight ? 'light' : 'dark');

  window.CJ = {
    theme: () => root.dataset.theme,
    monacoTheme: () => (root.dataset.theme === 'light' ? 'vs' : 'vs-dark'),
    toast(msg, kind) {
      const box = document.getElementById('toasts'); if (!box) return;
      const t = document.createElement('div'); t.className = 'toast ' + (kind || 'info'); t.setAttribute('role', 'status');
      t.textContent = msg; box.appendChild(t); setTimeout(() => t.remove(), 4500);
    },
    /* JSON POST/GET with unified error handling. Resolves to parsed JSON or throws Error(message). */
    async api(url, opts) {
      opts = opts || {};
      const init = { method: opts.method || (opts.body ? 'POST' : 'GET'), headers: {}, credentials: 'same-origin' };
      if (opts.body) { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(opts.body); }
      let res;
      try { res = await fetch(url, init); } catch (e) { throw new Error('Network error - check your connection.'); }
      let data = null; try { data = await res.json(); } catch (e) {}
      if (res.status === 401) { window.location = '/login'; throw new Error('Please log in.'); }
      if (!res.ok) throw new Error((data && (data.detail || data.stderr)) || ('Request failed (' + res.status + ')'));
      return data;
    },
    busy(btn, on, label) {
      if (!btn) return; if (on) { btn.dataset.l = btn.innerHTML; btn.innerHTML = '<span class="spinner"></span> ' + (label || 'Working...'); btn.disabled = true; btn.setAttribute('aria-busy', 'true'); }
      else { btn.innerHTML = btn.dataset.l || btn.innerHTML; btn.disabled = false; btn.removeAttribute('aria-busy'); }
    },
    esc: s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])),
    fmtTime(sec) { sec = Math.max(0, sec | 0); const d = (sec / 86400) | 0, h = ((sec % 86400) / 3600) | 0, m = ((sec % 3600) / 60) | 0, s = sec % 60, p = n => String(n).padStart(2, '0'); return (d ? d + 'd ' : '') + p(h) + ':' + p(m) + ':' + p(s); },
    /* countdown element: data-seconds -> ticks down, calls onDone at 0 */
    countdown(el, seconds, onDone) {
      let left = seconds, end = Date.now() + seconds * 1000;
      const tick = () => { left = Math.round((end - Date.now()) / 1000); el.textContent = CJ.fmtTime(left); el.classList.toggle('low', left <= 300 && left > 0);
        if (left <= 0) { clearInterval(iv); onDone && onDone(); } };
      const iv = setInterval(tick, 1000); tick(); return { resync(s) { end = Date.now() + s * 1000; } };
    },
  };

  document.addEventListener('DOMContentLoaded', function () {
    const tb = document.getElementById('themeToggle');
    const paint = () => { if (tb) { tb.textContent = root.dataset.theme === 'light' ? '🌙' : '☀️'; tb.setAttribute('aria-label', 'Switch to ' + (root.dataset.theme === 'light' ? 'dark' : 'light') + ' mode'); } };
    paint();
    tb && tb.addEventListener('click', () => {
      root.dataset.theme = root.dataset.theme === 'light' ? 'dark' : 'light';
      localStorage.setItem('cj-theme', root.dataset.theme); paint();
      window.dispatchEvent(new Event('themechange'));
    });
    const mb = document.getElementById('menuBtn'), nav = document.querySelector('.navbar');
    mb && mb.addEventListener('click', () => { nav.classList.toggle('open'); mb.setAttribute('aria-expanded', nav.classList.contains('open')); });
    document.querySelectorAll('form[data-confirm]').forEach(f => f.addEventListener('submit', e => { if (!confirm(f.dataset.confirm)) e.preventDefault(); }));
    document.querySelectorAll('form:not([data-nobusy])').forEach(f => f.addEventListener('submit', () => {
      const b = f.querySelector('button[type=submit],button:not([type])'); if (b && !b.disabled) setTimeout(() => CJ.busy(b, true, 'Please wait...'), 0); }));
    // local time rendering for UTC timestamps: <time data-utc="2026-01-01T10:00:00">
    document.querySelectorAll('time[data-utc]').forEach(t => { const d = new Date(t.dataset.utc + 'Z'); if (!isNaN(d)) t.textContent = d.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }); });
  });
  window.addEventListener('themechange', () => { if (window.monaco && monaco.editor) monaco.editor.setTheme(CJ.monacoTheme()); });
})();
