import re
import datetime as dt
from fastapi import APIRouter, Request, Depends, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session

from app.database import get_db
from app import models
from app.auth import get_current_user
from app.templating import templates
from app.services import contests as contest_svc

router = APIRouter()
DIFFICULTIES = ("Easy", "Medium", "Hard")
ROLES = ("student", "faculty", "admin")


def _admin(request, db):
    user = get_current_user(request, db)
    if not user or not (user.is_admin or user.role == "admin"):
        return None
    return user


def _staff(request, db):
    user = get_current_user(request, db)
    return user if user and user.is_staff else None


def slugify(title: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-") or "item"


def _unique_slug(db, model, base):
    slug, i = base, 2
    while db.query(model).filter(model.slug == slug).first():
        slug = f"{base}-{i}"
        i += 1
    return slug


def _parse_local_dt(value: str, tz_offset_min: int) -> dt.datetime:
    """<input type=datetime-local> is in the admin's local time; the browser also sends its
    UTC offset (minutes, as JS getTimezoneOffset). Store everything as naive UTC."""
    try:
        local = dt.datetime.fromisoformat(value)
    except ValueError:
        raise HTTPException(status_code=422, detail="Invalid date/time.")
    return local + dt.timedelta(minutes=tz_offset_min)


@router.get("/admin", response_class=HTMLResponse)
def admin_home(request: Request, db: Session = Depends(get_db)):
    user = _staff(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    stats = {
        "users": db.query(models.User).count(),
        "problems": db.query(models.Problem).count(),
        "submissions": db.query(models.Submission).count(),
        "accepted": db.query(models.Submission).filter(models.Submission.verdict == "Accepted").count(),
        "contests": db.query(models.Contest).count(),
    }
    return templates.TemplateResponse("admin.html", {
        "request": request, "user": user, "stats": stats,
        "problems": db.query(models.Problem).order_by(models.Problem.id).all(),
        "users": db.query(models.User).order_by(models.User.id).all(),
        "contests": db.query(models.Contest).order_by(models.Contest.start_time.desc()).all(),
        "is_admin": bool(user.is_admin or user.role == "admin"), "roles": ROLES,
        "notice": request.query_params.get("notice", ""),
    })


@router.post("/admin/problems/create")
def create_problem(
    request: Request, title: str = Form(...), description: str = Form(...), constraints: str = Form(""),
    difficulty: str = Form("Easy"), topic: str = Form("Arrays"), time_limit_seconds: float = Form(2.0),
    starter_code: str = Form(""), points: int = Form(100), is_published: bool = Form(True),
    db: Session = Depends(get_db),
):
    user = _staff(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    if difficulty not in DIFFICULTIES:
        raise HTTPException(status_code=422, detail="Invalid difficulty.")
    if not (0.1 <= time_limit_seconds <= 15):
        raise HTTPException(status_code=422, detail="Time limit must be between 0.1 and 15 seconds.")
    problem = models.Problem(
        title=title.strip()[:150], slug=_unique_slug(db, models.Problem, slugify(title)),
        description=description, constraints=constraints, difficulty=difficulty, topic=topic.strip()[:50] or "General",
        time_limit_seconds=time_limit_seconds, starter_code=starter_code, points=max(1, min(points, 1000)),
        is_published=is_published,
    )
    db.add(problem)
    db.commit()
    return RedirectResponse(url="/admin?notice=Problem+created", status_code=303)


@router.post("/admin/problems/{problem_id}/update")
def update_problem(
    problem_id: int, request: Request, title: str = Form(...), description: str = Form(...),
    constraints: str = Form(""), difficulty: str = Form("Easy"), topic: str = Form("General"),
    time_limit_seconds: float = Form(2.0), points: int = Form(100), is_published: bool = Form(False),
    db: Session = Depends(get_db),
):
    user = _staff(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    p = db.get(models.Problem, problem_id)
    if not p or difficulty not in DIFFICULTIES:
        raise HTTPException(status_code=404, detail="Problem not found or invalid input.")
    p.title, p.description, p.constraints = title.strip()[:150], description, constraints
    p.difficulty, p.topic, p.points = difficulty, topic.strip()[:50] or "General", max(1, min(points, 1000))
    p.time_limit_seconds = max(0.1, min(time_limit_seconds, 15))
    p.is_published = is_published
    db.commit()
    return RedirectResponse(url="/admin?notice=Problem+updated", status_code=303)


@router.post("/admin/problems/{problem_id}/delete")
def delete_problem(problem_id: int, request: Request, db: Session = Depends(get_db)):
    user = _admin(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    p = db.query(models.Problem).filter(models.Problem.id == problem_id).first()
    if p:
        db.query(models.ContestProblem).filter_by(problem_id=p.id).delete()
        db.query(models.SimilarityReport).filter_by(problem_id=p.id).delete()
        db.query(models.HintUsage).filter_by(problem_id=p.id).delete()
        db.query(models.TutorMessage).filter_by(problem_id=p.id).delete()
        db.delete(p)
        db.commit()
    return RedirectResponse(url="/admin?notice=Problem+deleted", status_code=303)


@router.post("/admin/problems/{problem_id}/add-testcase")
def add_testcase(
    problem_id: int, request: Request, input_data: str = Form(""), expected_output: str = Form(""),
    is_sample: bool = Form(False), weight: int = Form(1), db: Session = Depends(get_db),
):
    user = _staff(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    if not db.get(models.Problem, problem_id):
        raise HTTPException(status_code=404, detail="Problem not found.")
    db.add(models.TestCase(problem_id=problem_id, input_data=input_data, expected_output=expected_output,
                           is_sample=is_sample, weight=max(1, min(weight, 100))))
    db.commit()
    return RedirectResponse(url=f"/admin/problems/{problem_id}/tests", status_code=303)


@router.get("/admin/problems/{problem_id}/tests", response_class=HTMLResponse)
def manage_tests(problem_id: int, request: Request, db: Session = Depends(get_db)):
    user = _staff(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    p = db.get(models.Problem, problem_id)
    if not p:
        raise HTTPException(status_code=404, detail="Problem not found.")
    return templates.TemplateResponse("admin_tests.html", {"request": request, "user": user, "problem": p})


@router.post("/admin/testcases/{tc_id}/update")
def update_testcase(tc_id: int, request: Request, input_data: str = Form(""), expected_output: str = Form(""),
                    is_sample: bool = Form(False), weight: int = Form(1), db: Session = Depends(get_db)):
    user = _staff(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    tc = db.get(models.TestCase, tc_id)
    if not tc:
        raise HTTPException(status_code=404, detail="Test case not found.")
    tc.input_data, tc.expected_output, tc.is_sample = input_data, expected_output, is_sample
    tc.weight = max(1, min(weight, 100))
    db.commit()
    return RedirectResponse(url=f"/admin/problems/{tc.problem_id}/tests", status_code=303)


@router.post("/admin/testcases/{tc_id}/delete")
def delete_testcase(tc_id: int, request: Request, db: Session = Depends(get_db)):
    user = _staff(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    tc = db.get(models.TestCase, tc_id)
    if tc:
        pid = tc.problem_id
        db.delete(tc)
        db.commit()
        return RedirectResponse(url=f"/admin/problems/{pid}/tests", status_code=303)
    return RedirectResponse(url="/admin", status_code=303)


# ---------------------------------------------------------------- users ------
@router.post("/admin/users/{user_id}/toggle-admin")
def toggle_admin(user_id: int, request: Request, db: Session = Depends(get_db)):
    admin_user = _admin(request, db)
    if not admin_user:
        return RedirectResponse(url="/login", status_code=303)
    target = db.get(models.User, user_id)
    if target and target.id != admin_user.id:
        make_admin = not (target.is_admin or target.role == "admin")
        target.is_admin = make_admin
        target.role = "admin" if make_admin else "student"
        db.commit()
    return RedirectResponse(url="/admin", status_code=303)


@router.post("/admin/users/{user_id}/role")
def set_role(user_id: int, request: Request, role: str = Form(...), db: Session = Depends(get_db)):
    admin_user = _admin(request, db)
    if not admin_user:
        return RedirectResponse(url="/login", status_code=303)
    if role not in ROLES:
        raise HTTPException(status_code=422, detail="Invalid role.")
    target = db.get(models.User, user_id)
    if not target:
        raise HTTPException(status_code=404, detail="User not found.")
    if target.id == admin_user.id and role != "admin":
        return RedirectResponse(url="/admin?notice=You+cannot+demote+yourself", status_code=303)
    target.role, target.is_admin = role, role == "admin"
    db.commit()
    return RedirectResponse(url="/admin?notice=Role+updated", status_code=303)


@router.post("/admin/users/{user_id}/delete")
def delete_user(user_id: int, request: Request, db: Session = Depends(get_db)):
    admin_user = _admin(request, db)
    if not admin_user:
        return RedirectResponse(url="/login", status_code=303)
    target = db.get(models.User, user_id)
    if not target or target.id == admin_user.id:
        return RedirectResponse(url="/admin?notice=Cannot+delete+that+user", status_code=303)
    sub_ids = [s.id for s in target.submissions]
    if sub_ids:
        db.query(models.SimilarityReport).filter(
            (models.SimilarityReport.submission_id.in_(sub_ids)) |
            (models.SimilarityReport.other_submission_id.in_(sub_ids))).delete(synchronize_session=False)
    for m in (models.XPEvent, models.UserBadge, models.TutorMessage, models.HintUsage, models.ContestParticipant):
        db.query(m).filter_by(user_id=target.id).delete()
    for sub in list(target.submissions):
        db.delete(sub)
    for b in list(target.bookmarks):
        db.delete(b)
    db.delete(target)
    db.commit()
    return RedirectResponse(url="/admin?notice=User+deleted", status_code=303)


# -------------------------------------------------------------- contests -----
@router.post("/admin/contests/create")
def create_contest(
    request: Request, title: str = Form(...), description: str = Form(""),
    start_time: str = Form(...), end_time: str = Form(...), tz_offset: int = Form(0),
    penalty_minutes: int = Form(10), problem_ids: str = Form(""), db: Session = Depends(get_db),
):
    user = _staff(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    start, end = _parse_local_dt(start_time, tz_offset), _parse_local_dt(end_time, tz_offset)
    if end <= start:
        raise HTTPException(status_code=422, detail="End time must be after start time.")
    c = models.Contest(title=title.strip()[:150], slug=_unique_slug(db, models.Contest, slugify(title)),
                       description=description, start_time=start, end_time=end,
                       penalty_minutes=max(0, min(penalty_minutes, 120)), created_by_id=user.id)
    db.add(c)
    db.flush()
    for pos, pid in enumerate([x for x in re.split(r"[,\s]+", problem_ids) if x.isdigit()]):
        p = db.get(models.Problem, int(pid))
        if p:
            db.add(models.ContestProblem(contest_id=c.id, problem_id=p.id, position=pos, points=p.points or 100))
    db.commit()
    return RedirectResponse(url="/admin?notice=Contest+created", status_code=303)


@router.post("/admin/contests/{contest_id}/delete")
def delete_contest(contest_id: int, request: Request, db: Session = Depends(get_db)):
    user = _staff(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    c = db.get(models.Contest, contest_id)
    if c:
        db.query(models.Submission).filter_by(contest_id=c.id).update({"contest_id": None})
        db.delete(c)
        db.commit()
    return RedirectResponse(url="/admin?notice=Contest+deleted", status_code=303)
