from fastapi import APIRouter, Request, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session

from app.database import get_db
from app import models
from app.auth import get_current_user
from app.templating import templates
from app.services import gamification, analytics, contests as contest_svc

router = APIRouter()


def student_context(db: Session, target: models.User):
    subs = sorted(target.submissions, key=lambda s: s.created_at, reverse=True)
    difficulty_counts = {"Easy": 0, "Medium": 0, "Hard": 0}
    for p, _ in gamification.solved_problem_rows(db, target.id):
        difficulty_counts[p.difficulty] = difficulty_counts.get(p.difficulty, 0) + 1
    cur, longest = gamification.streak_days(db, target.id)
    ranking = gamification.global_ranking(db)
    my_rank = next((r["rank"] for r in ranking if r["user"].id == target.id), None)
    return {
        "subs": subs, "difficulty_counts": difficulty_counts, "streak": cur, "longest_streak": longest,
        "heatmap": gamification.heatmap(db, target.id), "level": gamification.level_progress(target.xp or 0),
        "badges": gamification.user_badges(db, target.id), "all_badges": gamification.BADGES,
        "rank": my_rank, "rank_total": len(ranking),
        "topics": analytics.topic_stats(db, target.id),
    }


@router.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    ctx = student_context(db, user)
    total_problems = db.query(models.Problem).filter(models.Problem.is_published == True).count()  # noqa: E712
    running = [c for c in db.query(models.Contest).filter(models.Contest.is_published == True).all()  # noqa: E712
               if contest_svc.status(c) in ("running", "upcoming")]
    running.sort(key=lambda c: c.start_time)
    return templates.TemplateResponse("dashboard.html", {
        "request": request, "user": user, "recent_submissions": ctx["subs"][:8],
        "recommended": analytics.recommend_problems(db, user.id, 4),
        "total_problems": total_problems, "contests": running[:3],
        "contest_status": contest_svc.status, **{k: v for k, v in ctx.items() if k != "subs"},
    })


@router.get("/leaderboard", response_class=HTMLResponse)
def leaderboard(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    return templates.TemplateResponse("leaderboard.html", {
        "request": request, "user": user, "ranked": gamification.global_ranking(db),
        "level_of": gamification.level_progress,
    })


@router.get("/profile", response_class=HTMLResponse)
def my_profile(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    return RedirectResponse(url=f"/u/{user.username}", status_code=303)


@router.get("/u/{username}", response_class=HTMLResponse)
def public_profile(username: str, request: Request, db: Session = Depends(get_db)):
    viewer = get_current_user(request, db)
    if not viewer:
        return RedirectResponse(url="/login", status_code=303)
    target = db.query(models.User).filter(models.User.username == username).first()
    if not target:
        raise HTTPException(status_code=404, detail="User not found.")
    ctx = student_context(db, target)
    own = viewer.id == target.id or viewer.is_staff
    return templates.TemplateResponse("profile.html", {
        "request": request, "user": viewer, "target": target, "own": own,
        "submissions": ctx["subs"][:20] if own else [],
        "languages_used": sorted({s.language for s in ctx["subs"]}),
        "history": contest_svc.user_history(db, target),
        **{k: v for k, v in ctx.items() if k != "subs"},
    })


@router.post("/profile/bio")
async def update_bio(request: Request, db: Session = Depends(get_db)):
    from fastapi import Form
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    form = await request.form()
    user.bio = str(form.get("bio", ""))[:300]
    db.commit()
    return RedirectResponse(url=f"/u/{user.username}", status_code=303)
