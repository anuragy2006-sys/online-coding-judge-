import asyncio
from fastapi import APIRouter, Request, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from sqlalchemy.orm import Session

from app.database import get_db
from app import models
from app.auth import get_current_user, require_user_json
from app.templating import templates
from app.services import analytics, ai_learning

router = APIRouter()


@router.get("/learn", response_class=HTMLResponse)
def learning_page(request: Request, db: Session = Depends(get_db)):
    """Smart weakness detection + personalised roadmap + recommendations."""
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    return templates.TemplateResponse("learn.html", {
        "request": request, "user": user,
        "topics": analytics.topic_stats(db, user.id),
        "insights": analytics.error_insights(db, user.id),
        "roadmap": analytics.build_roadmap(db, user.id),
        "recommended": analytics.recommend_problems(db, user.id, 6),
    })


async def _body(request):
    try:
        b = await request.json()
        assert isinstance(b, dict)
        return b
    except Exception:
        raise HTTPException(status_code=400, detail="Malformed request body: expected a JSON object.")


def _problem_ctx(db, user, slug):
    problem = db.query(models.Problem).filter(models.Problem.slug == slug).first() if slug else None
    last = None
    if problem:
        last = db.query(models.Submission).filter_by(user_id=user.id, problem_id=problem.id).order_by(
            models.Submission.id.desc()).first()
    return problem, last


@router.post("/api/hint")
async def hint(request: Request, db: Session = Depends(get_db), user=Depends(require_user_json)):
    b = await _body(request)
    problem, last = _problem_ctx(db, user, b.get("slug"))
    if not problem:
        raise HTTPException(status_code=404, detail="Problem not found.")
    try:
        level = int(b.get("level", 1))
    except (TypeError, ValueError):
        raise HTTPException(status_code=422, detail="level must be 1, 2 or 3.")
    if level not in (1, 2, 3):
        raise HTTPException(status_code=422, detail="level must be 1, 2 or 3.")
    db.add(models.HintUsage(user_id=user.id, problem_id=problem.id, level=level))
    db.commit()
    res = await asyncio.to_thread(
        ai_learning.get_hint, level, problem, str(b.get("source_code", ""))[:8000], str(b.get("language", "python")),
        last.verdict if last else "", (last.error_message if last else "") or "")
    return JSONResponse(res)


@router.get("/api/tutor/history")
def tutor_history(slug: str = "", db: Session = Depends(get_db), user=Depends(require_user_json)):
    problem, _ = _problem_ctx(db, user, slug)
    q = db.query(models.TutorMessage).filter_by(user_id=user.id, problem_id=problem.id if problem else None)
    msgs = q.order_by(models.TutorMessage.id.desc()).limit(30).all()[::-1]
    return JSONResponse({"messages": [{"role": m.role, "content": m.content} for m in msgs]})


@router.post("/api/tutor")
async def tutor(request: Request, db: Session = Depends(get_db), user=Depends(require_user_json)):
    b = await _body(request)
    question = str(b.get("message", "")).strip()
    if not question or len(question) > 1500:
        raise HTTPException(status_code=422, detail="Message must be 1-1500 characters.")
    problem, last = _problem_ctx(db, user, b.get("slug"))
    pid = problem.id if problem else None
    hist = [{"role": m.role, "content": m.content} for m in
            db.query(models.TutorMessage).filter_by(user_id=user.id, problem_id=pid)
            .order_by(models.TutorMessage.id.desc()).limit(8).all()[::-1]]
    res = await asyncio.to_thread(
        ai_learning.tutor_reply, hist, question, problem, str(b.get("source_code", ""))[:8000],
        str(b.get("language", "python")), last.verdict if last else "", (last.error_message if last else "") or "")
    db.add(models.TutorMessage(user_id=user.id, problem_id=pid, role="user", content=question))
    db.add(models.TutorMessage(user_id=user.id, problem_id=pid, role="assistant", content=res["reply"]))
    db.commit()
    return JSONResponse(res)


@router.post("/api/tutor/clear")
def tutor_clear(slug: str = "", db: Session = Depends(get_db), user=Depends(require_user_json)):
    problem, _ = _problem_ctx(db, user, slug)
    db.query(models.TutorMessage).filter_by(user_id=user.id, problem_id=problem.id if problem else None).delete()
    db.commit()
    return JSONResponse({"ok": True})
