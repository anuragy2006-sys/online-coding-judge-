import asyncio

from fastapi import APIRouter, Request, Depends, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from sqlalchemy.orm import Session

from app.database import get_db
from app import models
from app.auth import get_current_user
from app.services import package_manager
from app.templating import templates

router = APIRouter()

LANGUAGES = ["python", "c", "cpp", "java"]


@router.get("/extensions", response_class=HTMLResponse)
def extensions_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)

    packages_by_language = {
        lang: package_manager.list_packages(db, lang) for lang in LANGUAGES
    }
    return templates.TemplateResponse("extensions.html", {
        "request": request,
        "user": user,
        "packages_by_language": packages_by_language,
        "result": None,
    })


@router.post("/extensions/install", response_class=HTMLResponse)
async def extensions_install(
    request: Request,
    language: str = Form(...),
    name: str = Form(...),
    version: str = Form(""),
    link_flags: str = Form(""),
    db: Session = Depends(get_db),
):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    if not (user.is_admin or user.role == "admin"):
        raise HTTPException(status_code=403, detail="Only admins can install server-wide packages.")

    language = language.lower()
    if language not in LANGUAGES:
        result = package_manager.InstallResult(False, f"Unknown language: {language}")
    else:
        # install_package() shells out to pip/apt-get or downloads a jar over the
        # network -- can take real seconds. This route is `async def`, so running
        # it inline would block the event loop and freeze the whole site for every
        # other user until the install finishes (the same class of bug fixed
        # earlier in /judge/run and the AI Doctor endpoints). Offload to a thread.
        result = await asyncio.to_thread(
            package_manager.install_package, db, language, name, version, link_flags, user
        )

    packages_by_language = {
        lang: package_manager.list_packages(db, lang) for lang in LANGUAGES
    }
    return templates.TemplateResponse("extensions.html", {
        "request": request,
        "user": user,
        "packages_by_language": packages_by_language,
        "result": {"ok": result.ok, "message": result.message, "language": language, "name": name},
    })


@router.get("/extensions/search")
async def extensions_search(request: Request, language: str, q: str = "", db: Session = Depends(get_db)):
    """Typeahead suggestions for the install form's name field."""
    user = get_current_user(request, db)
    if not user:
        return JSONResponse({"results": [], "error": "Login required."}, status_code=401)

    language = language.lower()
    q = (q or "").strip()
    if len(q) < 2:
        return JSONResponse({"results": []})

    # All three of these are blocking (network call or subprocess) -- see the
    # asyncio.to_thread note on /extensions/install for why this matters.
    if language == "python":
        names = await asyncio.to_thread(package_manager.search_python_packages, q)
        results = [{"name": n} for n in names]
    elif language in ("c", "cpp"):
        results = await asyncio.to_thread(package_manager.search_apt_packages, q)
    elif language == "java":
        results = await asyncio.to_thread(package_manager.search_maven_packages, q)
    else:
        results = []
    return JSONResponse({"results": results})


@router.get("/extensions/latest-version")
async def extensions_latest_version(request: Request, language: str, name: str, db: Session = Depends(get_db)):
    """The 'auto-fill the latest version' lookup, fired once a Python package
    name is chosen (Maven suggestions already carry their version; apt has no
    separate version concept -- see search_apt_packages)."""
    user = get_current_user(request, db)
    if not user:
        return JSONResponse({"version": None, "error": "Login required."}, status_code=401)
    if language.lower() != "python":
        return JSONResponse({"version": None})
    version = await asyncio.to_thread(package_manager.pypi_latest_version, (name or "").strip())
    return JSONResponse({"version": version})


@router.post("/extensions/{package_id}/uninstall", response_class=HTMLResponse)
async def extensions_uninstall(package_id: int, request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    if not (user.is_admin or user.role == "admin"):
        raise HTTPException(status_code=403, detail="Only admins can uninstall server-wide packages.")

    pkg = db.query(models.InstalledPackage).filter(models.InstalledPackage.id == package_id).first()
    result = None
    if pkg:
        # uninstall_package() shells out to pip/apt-get (or deletes a jar) --
        # same asyncio.to_thread reasoning as /extensions/install: this is a
        # blocking call and this route is `async def`.
        pkg_language, pkg_name = pkg.language, pkg.name
        outcome = await asyncio.to_thread(package_manager.uninstall_package, db, pkg)
        result = {
            "ok": outcome.ok,
            "message": outcome.message,
            "language": pkg_language,
            "name": pkg_name,
            "action": "uninstall",
        }

    packages_by_language = {
        lang: package_manager.list_packages(db, lang) for lang in LANGUAGES
    }
    return templates.TemplateResponse("extensions.html", {
        "request": request,
        "user": user,
        "packages_by_language": packages_by_language,
        "result": result,
    })


@router.post("/extensions/detect")
async def extensions_detect(request: Request, db: Session = Depends(get_db)):
    """Used by the problem editor: scan the current code for imports/includes and
    report which ones are stdlib, already installed, or missing."""
    user = get_current_user(request, db)
    if not user:
        return JSONResponse({"modules": [], "error": "Login required."}, status_code=401)
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"modules": []}, status_code=400)
    language = (body.get("language") or "python").lower()
    source_code = body.get("source_code") or ""
    modules = package_manager.check_modules(db, language, source_code)
    return JSONResponse({"modules": modules})
