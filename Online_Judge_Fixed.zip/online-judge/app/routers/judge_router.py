import asyncio
import datetime as dt

from fastapi import APIRouter, Request, Depends, Form, HTTPException
from fastapi.responses import JSONResponse, RedirectResponse, HTMLResponse
from sqlalchemy.orm import Session

from app.database import get_db
from app import models
from app.auth import get_current_user, require_user_json
from app.config import MAX_SOURCE_BYTES
from app.services.executor import run_code
from app.services.judge_service import judge_submission
from app.services import ai_review, ai_learning, gamification, similarity, contests as contest_svc
from app.templating import templates

router = APIRouter()

LANGUAGES = ("python", "c", "cpp", "java")


def _clean_lang(lang) -> str:
    lang = str(lang or "python").lower().strip()
    lang = "cpp" if lang == "c++" else lang
    if lang not in LANGUAGES:
        raise HTTPException(status_code=422, detail=f"Unsupported language. Choose one of: {', '.join(LANGUAGES)}.")
    return lang


def _clean_code(code) -> str:
    if not isinstance(code, str):
        raise HTTPException(status_code=422, detail="source_code must be text.")
    if len(code.encode("utf-8", errors="ignore")) > MAX_SOURCE_BYTES:
        raise HTTPException(status_code=413, detail=f"Source code too large (max {MAX_SOURCE_BYTES // 1024} KB).")
    return code


async def _parse_json_body(request: Request) -> dict:
    try:
        body = await request.json()
        if not isinstance(body, dict):
            raise ValueError
        return body
    except Exception:
        raise HTTPException(status_code=400, detail="Malformed request body: expected a JSON object.")


@router.post("/judge/run")
async def run_custom(request: Request, db: Session = Depends(get_db)):
    """Run code with custom stdin (custom test case). Login required; rate limited."""
    user = get_current_user(request, db)
    if not user:
        return JSONResponse({"status": "INTERNAL_ERROR", "stdout": "", "stderr": "Please log in to run code.",
                             "runtime_ms": 0.0}, status_code=401)
    try:
        body = await _parse_json_body(request)
        language, source_code = _clean_lang(body.get("language")), _clean_code(body.get("source_code", ""))
    except HTTPException as e:
        return JSONResponse({"status": "INTERNAL_ERROR", "stdout": "", "stderr": e.detail, "runtime_ms": 0.0},
                            status_code=e.status_code)
    stdin_data = str(body.get("stdin", ""))
    # run_code blocks (compile + run); a worker thread keeps the event loop free for other users.
    result = await asyncio.to_thread(run_code, language, source_code, stdin_data)
    return JSONResponse({"status": result.status, "stdout": result.stdout, "stderr": result.stderr,
                         "runtime_ms": round(result.runtime_ms, 1), "memory_kb": result.memory_kb})


@router.post("/api/problems/{slug}/run-samples")
async def run_samples(slug: str, request: Request, db: Session = Depends(get_db),
                      user=Depends(require_user_json)):
    """Runs the code against the PUBLIC test cases only and returns per-case results."""
    problem = db.query(models.Problem).filter(models.Problem.slug == slug).first()
    if not problem:
        raise HTTPException(status_code=404, detail="Problem not found.")
    body = await _parse_json_body(request)
    language, code = _clean_lang(body.get("language")), _clean_code(body.get("source_code", ""))
    result = await asyncio.to_thread(judge_submission, language, code, problem, True)
    return JSONResponse({k: result[k] for k in ("verdict", "passed_cases", "total_cases", "runtime_ms",
                                                "error_message", "case_results")})


@router.post("/problems/{slug}/submit", response_class=HTMLResponse)
def submit_solution(
    slug: str,
    request: Request,
    language: str = Form(...),
    source_code: str = Form(...),
    contest: str = Form(""),
    db: Session = Depends(get_db),
):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    problem = db.query(models.Problem).filter(models.Problem.slug == slug).first()
    if not problem:
        return RedirectResponse(url="/problems", status_code=303)
    language, source_code = _clean_lang(language), _clean_code(source_code)

    contest_obj = None
    if contest:
        contest_obj = db.query(models.Contest).filter(models.Contest.slug == contest).first()
        if (not contest_obj or contest_svc.status(contest_obj) != "running"
                or not contest_svc.is_contest_problem(contest_obj, problem.id)):
            raise HTTPException(status_code=403, detail="This contest is not accepting submissions for that problem.")
        contest_svc.join(db, contest_obj, user)
    elif not problem.is_published and not user.is_staff:
        raise HTTPException(status_code=403, detail="This problem is not available yet.")

    result = judge_submission(language, source_code, problem)
    submission = models.Submission(
        user_id=user.id, problem_id=problem.id, language=language, source_code=source_code,
        verdict=result["verdict"], runtime_ms=result["runtime_ms"], passed_cases=result["passed_cases"],
        total_cases=result["total_cases"], error_message=result["error_message"], score=result["score"],
        max_memory_kb=result["max_memory_kb"], contest_id=contest_obj.id if contest_obj else None,
    )
    db.add(submission)
    db.commit()
    db.refresh(submission)

    try:
        similarity.check_submission(db, submission, problem)
    except Exception:
        db.rollback()          # plagiarism check must never block a submission
    reward = gamification.on_submission(db, user, submission, problem)
    qs = f"?xp={reward['xp']}" + (f"&badges={','.join(reward['badges'])}" if reward["badges"] else "")
    return RedirectResponse(url=f"/submissions/{submission.id}{qs}", status_code=303)


@router.get("/submissions/{submission_id}", response_class=HTMLResponse)
def submission_result(submission_id: int, request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    submission = db.query(models.Submission).filter(models.Submission.id == submission_id).first()
    if not submission or (submission.user_id != user.id and not user.is_staff):
        return RedirectResponse(url="/problems", status_code=303)
    try:
        xp = max(0, min(int(request.query_params.get("xp", 0)), 1000))
    except ValueError:
        xp = 0
    new_badges = [gamification.BADGES[k] for k in request.query_params.get("badges", "").split(",")
                  if k in gamification.BADGES]
    return templates.TemplateResponse("submit_result.html", {
        "request": request, "user": user, "submission": submission, "xp_gained": xp, "new_badges": new_badges,
    })


@router.get("/submissions", response_class=HTMLResponse)
def submission_history(request: Request, verdict: str = "", language: str = "", problem: str = "",
                       db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    q = db.query(models.Submission).filter(models.Submission.user_id == user.id)
    if verdict:
        q = q.filter(models.Submission.verdict == verdict)
    if language:
        q = q.filter(models.Submission.language == language)
    if problem.isdigit():
        q = q.filter(models.Submission.problem_id == int(problem))
    subs = q.order_by(models.Submission.created_at.desc()).limit(500).all()
    all_verdicts = sorted({r[0] for r in db.query(models.Submission.verdict).filter(
        models.Submission.user_id == user.id).distinct()})
    return templates.TemplateResponse("submission_history.html", {
        "request": request, "user": user, "submissions": subs, "all_verdicts": all_verdicts,
        "f_verdict": verdict, "f_language": language,
    })


# ------------------------------------------------------------- AI DOCTOR ---
# Every ai_review.* call below is potentially blocking: when ANTHROPIC_API_KEY is
# set, it makes a synchronous HTTP request (httpx.Client, up to 30s timeout) to the
# Anthropic API. These routes are `async def`, so calling it inline would freeze the
# event loop -- and therefore every other user's request -- for the duration of that
# call. Running it via asyncio.to_thread keeps the server responsive to everyone else
# while one person's AI Doctor request is in flight. (This is dormant in environments
# without the API key configured, since the heuristic fallback is fast, but it's a
# real bug waiting to happen the moment a key is set.)

@router.post("/ai/review")
async def ai_review_endpoint(request: Request, user=Depends(require_user_json)):
    body = await _parse_json_body(request)
    result = await asyncio.to_thread(
        ai_review.review_code, body.get("language", "python"), body.get("source_code", ""), body.get("verdict", "")
    )
    return JSONResponse({"result": result})


@router.post("/ai/explain-error")
async def ai_explain_error_endpoint(request: Request, user=Depends(require_user_json)):
    body = await _parse_json_body(request)
    result = await asyncio.to_thread(
        ai_review.explain_error,
        body.get("language", "python"), body.get("source_code", ""), body.get("error_message", "")
    )
    return JSONResponse({"result": result})


@router.post("/ai/explain-code")
async def ai_explain_code_endpoint(request: Request, user=Depends(require_user_json)):
    body = await _parse_json_body(request)
    result = await asyncio.to_thread(
        ai_review.explain_code,
        body.get("language", "python"), body.get("source_code", ""), body.get("level", "beginner")
    )
    return JSONResponse({"result": result})


@router.post("/ai/optimize")
async def ai_optimize_endpoint(request: Request, user=Depends(require_user_json)):
    body = await _parse_json_body(request)
    result = await asyncio.to_thread(
        ai_review.optimize_code, body.get("language", "python"), body.get("source_code", "")
    )
    return JSONResponse({"result": result})


@router.post("/ai/convert")
async def ai_convert_endpoint(request: Request, user=Depends(require_user_json)):
    body = await _parse_json_body(request)
    result = await asyncio.to_thread(
        ai_review.convert_code,
        body.get("source_language", "python"),
        body.get("target_language", "python"),
        body.get("source_code", ""),
    )
    return JSONResponse(result)  # {converted_code, explanation}


@router.post("/ai/fix")
async def ai_fix_endpoint(request: Request, user=Depends(require_user_json)):
    body = await _parse_json_body(request)
    result = await asyncio.to_thread(
        ai_review.fix_code,
        body.get("language", "python"),
        body.get("source_code", ""),
        body.get("error_message", ""),
    )
    return JSONResponse(result)  # {diagnosis, fixed_code}


@router.post("/ai/teach")
async def ai_teach_endpoint(request: Request, user=Depends(require_user_json)):
    body = await _parse_json_body(request)
    result = await asyncio.to_thread(
        ai_review.teach_me_code,
        body.get("language", "python"),
        body.get("source_code", ""),
        body.get("problem_title", ""),
    )
    return JSONResponse({"result": result})


@router.post("/ai/alternatives")
async def ai_alternatives_endpoint(request: Request, user=Depends(require_user_json)):
    body = await _parse_json_body(request)
    result = await asyncio.to_thread(
        ai_review.generate_alternatives,
        body.get("language", "python"),
        body.get("source_code", ""),
        body.get("problem_description", ""),
    )
    return JSONResponse({"result": result})


@router.post("/ai/suggest")
async def ai_suggest_endpoint(request: Request, user=Depends(require_user_json)):
    body = await _parse_json_body(request)
    result = await asyncio.to_thread(
        ai_review.suggest_code,
        body.get("language", "python"),
        body.get("source_code", ""),
    )
    return JSONResponse({"result": result})


@router.post("/ai/report")
async def ai_report_endpoint(request: Request, user=Depends(require_user_json)):
    body = await _parse_json_body(request)
    result = await asyncio.to_thread(
        ai_review.generate_intelligence_report,
        body.get("language", "python"),
        body.get("source_code", ""),
    )
    return JSONResponse(result)


@router.post("/ai/correctness")
async def ai_correctness_endpoint(request: Request, user=Depends(require_user_json)):
    """'How likely is this code to be correct' -- grounds the estimate in one
    real execution of the code (same executor as Run/Submit) before asking
    for a score, rather than judging from static reading alone."""
    body = await _parse_json_body(request)
    language = body.get("language", "python")
    source_code = body.get("source_code", "")
    stdin_data = body.get("stdin", "")
    problem_description = body.get("problem_description", "")

    # Both calls below are blocking (subprocess execution, then a network/CPU
    # call for the score) -- to_thread keeps this route from blocking the
    # event loop for every other user, same reasoning as every other AI/judge
    # endpoint in this file.
    run_result = await asyncio.to_thread(run_code, language, source_code, stdin_data)
    run_result_dict = {"status": run_result.status, "stdout": run_result.stdout, "stderr": run_result.stderr}

    result = await asyncio.to_thread(
        ai_review.correctness_score, language, source_code, run_result_dict, problem_description
    )
    result["run_status"] = run_result.status
    return JSONResponse(result)


@router.post("/ai/explain-lines")
async def ai_explain_lines_endpoint(request: Request, user=Depends(require_user_json)):
    body = await _parse_json_body(request)
    lang, code = _clean_lang(body.get("language", "python")), _clean_code(body.get("source_code", ""))
    result = await asyncio.to_thread(ai_learning.explain_lines, lang, code, body.get("level", "beginner"))
    return JSONResponse(result)
