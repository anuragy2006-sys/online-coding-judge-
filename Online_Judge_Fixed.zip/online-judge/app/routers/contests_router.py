from fastapi import APIRouter, Request, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from sqlalchemy.orm import Session

from app.database import get_db
from app import models
from app.auth import get_current_user, require_user_json
from app.templating import templates
from app.services import contests as svc

router = APIRouter()


@router.get("/contests", response_class=HTMLResponse)
def contests_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    allc = db.query(models.Contest).filter(models.Contest.is_published == True).all()  # noqa: E712
    groups = {"running": [], "upcoming": [], "ended": []}
    for c in allc:
        groups[svc.status(c)].append(c)
    groups["upcoming"].sort(key=lambda c: c.start_time)
    groups["ended"].sort(key=lambda c: c.end_time, reverse=True)
    joined = {p.contest_id for p in db.query(models.ContestParticipant).filter_by(user_id=user.id)}
    return templates.TemplateResponse("contests.html", {
        "request": request, "user": user, "groups": groups, "joined": joined,
        "history": svc.user_history(db, user), "seconds_left": svc.seconds_left,
    })


def _get_contest(db, slug):
    c = db.query(models.Contest).filter(models.Contest.slug == slug).first()
    if not c or not c.is_published:
        raise HTTPException(status_code=404, detail="Contest not found.")
    return c


@router.get("/contests/{slug}", response_class=HTMLResponse)
def contest_detail(slug: str, request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    c = _get_contest(db, slug)
    st = svc.status(c)
    joined = db.query(models.ContestParticipant).filter_by(contest_id=c.id, user_id=user.id).first() is not None
    solved = {r[0] for r in db.query(models.Submission.problem_id).filter(
        models.Submission.user_id == user.id, models.Submission.contest_id == c.id,
        models.Submission.verdict == "Accepted")}
    return templates.TemplateResponse("contest_detail.html", {
        "request": request, "user": user, "contest": c, "status": st, "joined": joined,
        "seconds_left": svc.seconds_left(c), "solved": solved,
        "show_problems": st != "upcoming" or user.is_staff,
        "leaderboard": svc.leaderboard(db, c) if st != "upcoming" else [],
    })


@router.post("/contests/{slug}/join")
def join_contest(slug: str, request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    c = _get_contest(db, slug)
    if svc.status(c) == "ended":
        raise HTTPException(status_code=403, detail="This contest has ended.")
    svc.join(db, c, user)
    return RedirectResponse(url=f"/contests/{slug}", status_code=303)


@router.get("/api/contests/{slug}/leaderboard")
def leaderboard_json(slug: str, db: Session = Depends(get_db), user=Depends(require_user_json)):
    """Polled by the contest page every few seconds for the live leaderboard."""
    c = _get_contest(db, slug)
    if svc.status(c) == "upcoming":
        return JSONResponse({"status": "upcoming", "seconds_left": svc.seconds_left(c), "rows": [], "problems": []})
    rows = svc.leaderboard(db, c)
    probs = [{"id": cp.problem_id, "title": cp.problem.title, "points": cp.points} for cp in c.problems]
    return JSONResponse({
        "status": svc.status(c), "seconds_left": svc.seconds_left(c), "me": user.id, "problems": probs,
        "rows": [{
            "rank": r["rank"], "username": r["user"].username, "user_id": r["user"].id, "points": r["points"],
            "solved": r["solved"], "penalty": r["penalty"],
            "cells": {str(pid): {"best": cell["best"], "ac": cell["ac_min"] is not None, "tries": cell["tries"]}
                      for pid, cell in r["per"].items()},
        } for r in rows],
    })
