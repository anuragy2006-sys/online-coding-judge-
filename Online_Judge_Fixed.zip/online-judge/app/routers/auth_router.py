import re
from fastapi import APIRouter, Request, Depends, Form
from fastapi.responses import RedirectResponse, HTMLResponse
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.database import get_db
from app import models
from app.auth import (
    hash_password, verify_password, set_session_cookie, get_current_user, set_no_store_headers
)
from app.config import MIN_PASSWORD_LENGTH, SESSION_COOKIE_NAME, COOKIE_SECURE
from app.templating import templates

router = APIRouter()


@router.get("/register", response_class=HTMLResponse)
def register_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if user:
        response = RedirectResponse(url="/dashboard", status_code=303)
        return set_no_store_headers(response)

    response = templates.TemplateResponse("register.html", {"request": request, "user": user, "error": None})
    return set_no_store_headers(response)


@router.post("/register")
def register_submit(
    request: Request,
    username: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db),
):
    # The registration form's password field only enforces minlength="4" on the client
    # side (HTML attribute) -- that's trivially bypassed by posting directly to this
    # endpoint (curl, a script, a modified request), so it must also be checked here.
    username, email = username.strip(), email.strip()
    err = None
    if not re.fullmatch(r"[A-Za-z0-9_.-]{3,30}", username):
        err = "Username must be 3-30 characters: letters, numbers, _ . -"
    elif not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email) or len(email) > 120:
        err = "Please enter a valid email address."
    elif len(password) < MIN_PASSWORD_LENGTH or password.isdigit() or password.isalpha():
        err = f"Password must be at least {MIN_PASSWORD_LENGTH} characters and mix letters with numbers or symbols."
    if err:
        response = templates.TemplateResponse(
            "register.html",
            {"request": request, "user": None, "error": err},
            status_code=400,
        )
        return set_no_store_headers(response)

    existing = db.query(models.User).filter(
        (models.User.username == username) | (func.lower(models.User.email) == email.strip().lower())
    ).first()
    if existing:
        response = templates.TemplateResponse(
            "register.html",
            {"request": request, "user": None, "error": "Username or email already taken."},
            status_code=400,
        )
        return set_no_store_headers(response)

    user = models.User(
        username=username,
        email=email,
        hashed_password=hash_password(password),
        is_admin=False,
        role="student",
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    response = RedirectResponse(url="/dashboard", status_code=303)
    set_session_cookie(response, user.id)
    return set_no_store_headers(response)


@router.get("/login", response_class=HTMLResponse)
def login_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if user:
        response = RedirectResponse(url="/dashboard", status_code=303)
        return set_no_store_headers(response)

    response = templates.TemplateResponse("login.html", {"request": request, "user": user, "error": None})
    return set_no_store_headers(response)


@router.post("/login")
def login_submit(
    request: Request,
    email: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db),
):
    user = db.query(models.User).filter(func.lower(models.User.email) == email.strip().lower()).first()
    if not user or not verify_password(password, user.hashed_password):
        response = templates.TemplateResponse(
            "login.html",
            {"request": request, "user": None, "error": "Invalid email or password."},
            status_code=400,
        )
        return set_no_store_headers(response)

    response = RedirectResponse(url="/dashboard", status_code=303)
    set_session_cookie(response, user.id)
    return set_no_store_headers(response)


@router.get("/logout")
def logout():
    response = RedirectResponse(url="/", status_code=303)
    response.delete_cookie(SESSION_COOKIE_NAME, httponly=True, samesite="lax", secure=COOKIE_SECURE)
    return set_no_store_headers(response)
