from fastapi import APIRouter, Request, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from sqlalchemy.orm import Session

from app.database import get_db
from app import models
from app.auth import get_current_user
from app.templating import templates
from app.services import analytics, gamification, reports

router = APIRouter()


def _staff(request, db):
    u = get_current_user(request, db)
    return u if u and u.is_staff else None


def student_stats(db, student):
    subs = sorted([s for s in student.submissions if s.verdict != "Pending"], key=lambda s: s.created_at, reverse=True)
    ok = sum(1 for s in subs if s.verdict == "Accepted")
    ranking = gamification.global_ranking(db)
    return {
        "solved": student.solved_count, "submissions": len(subs), "accuracy": round(ok / len(subs) * 100, 1) if subs else 0,
        "level": gamification.level_progress(student.xp or 0)["level"], "streak": gamification.streak_days(db, student.id)[0],
        "rank": next((r["rank"] for r in ranking if r["user"].id == student.id), "-"),
        "topics": analytics.topic_stats(db, student.id), "insights": analytics.error_insights(db, student.id),
        "recent": subs[:15],
    }


@router.get("/faculty", response_class=HTMLResponse)
def faculty_dashboard(request: Request, db: Session = Depends(get_db)):
    user = _staff(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    ov = analytics.class_overview(db)
    flagged = db.query(models.SimilarityReport).filter_by(reviewed=False).count()
    return templates.TemplateResponse("faculty.html", {"request": request, "user": user, "ov": ov, "flagged": flagged})


@router.get("/faculty/students/{user_id}", response_class=HTMLResponse)
def faculty_student(user_id: int, request: Request, db: Session = Depends(get_db)):
    user = _staff(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    student = db.get(models.User, user_id)
    if not student:
        raise HTTPException(status_code=404, detail="Student not found.")
    return templates.TemplateResponse("faculty_student.html", {
        "request": request, "user": user, "student": student, "st": student_stats(db, student),
        "roadmap": analytics.build_roadmap(db, student.id), "heatmap": gamification.heatmap(db, student.id),
    })


@router.get("/faculty/reports/class.pdf")
def class_pdf(request: Request, db: Session = Depends(get_db)):
    user = _staff(request, db)
    if not user:
        raise HTTPException(status_code=403, detail="Faculty or admin access required.")
    data = reports.class_report_pdf(analytics.class_overview(db), user.username)
    return Response(data, media_type="application/pdf",
                    headers={"Content-Disposition": 'attachment; filename="class-report.pdf"'})


@router.get("/faculty/reports/student/{user_id}.pdf")
def student_pdf(user_id: int, request: Request, db: Session = Depends(get_db)):
    user = _staff(request, db)
    if not user:
        raise HTTPException(status_code=403, detail="Faculty or admin access required.")
    student = db.get(models.User, user_id)
    if not student:
        raise HTTPException(status_code=404, detail="Student not found.")
    data = reports.student_report_pdf(student, student_stats(db, student), user.username)
    return Response(data, media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="student-{student.username}.pdf"'})


@router.get("/faculty/plagiarism", response_class=HTMLResponse)
def plagiarism_page(request: Request, show: str = "open", db: Session = Depends(get_db)):
    user = _staff(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    q = db.query(models.SimilarityReport)
    if show == "open":
        q = q.filter_by(reviewed=False)
    reports_ = q.order_by(models.SimilarityReport.similarity.desc(), models.SimilarityReport.id.desc()).limit(200).all()
    return templates.TemplateResponse("plagiarism.html", {"request": request, "user": user, "reports": reports_, "show": show})


@router.get("/faculty/plagiarism/{report_id}", response_class=HTMLResponse)
def plagiarism_compare(report_id: int, request: Request, db: Session = Depends(get_db)):
    user = _staff(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    r = db.get(models.SimilarityReport, report_id)
    if not r:
        raise HTTPException(status_code=404, detail="Report not found.")
    return templates.TemplateResponse("plagiarism_compare.html", {"request": request, "user": user, "r": r})


@router.post("/faculty/plagiarism/{report_id}/review")
def plagiarism_review(report_id: int, request: Request, db: Session = Depends(get_db)):
    user = _staff(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    r = db.get(models.SimilarityReport, report_id)
    if r:
        r.reviewed = True
        db.commit()
    return RedirectResponse(url="/faculty/plagiarism", status_code=303)
