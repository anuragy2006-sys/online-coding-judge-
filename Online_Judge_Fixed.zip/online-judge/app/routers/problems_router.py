from fastapi import APIRouter, Request, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session

from app.database import get_db
from app import models
from app.auth import get_current_user
from app.templating import templates

router = APIRouter()


@router.get("/problems", response_class=HTMLResponse)
def list_problems(
    request: Request,
    difficulty: str = None,
    topic: str = None,
    db: Session = Depends(get_db),
):
    user = get_current_user(request, db)
    query = db.query(models.Problem).filter(models.Problem.is_published == True)  # noqa: E712
    if difficulty:
        query = query.filter(models.Problem.difficulty == difficulty)
    if topic:
        query = query.filter(models.Problem.topic == topic)
    problems = query.order_by(models.Problem.id).all()

    solved_ids = set()
    bookmarked_ids = set()
    if user:
        solved_ids = {
            s.problem_id for s in user.submissions if s.verdict == "Accepted"
        }
        bookmarked_ids = {b.problem_id for b in user.bookmarks}

    topics = [t[0] for t in db.query(models.Problem.topic).filter(models.Problem.is_published == True).distinct().all()]  # noqa: E712

    return templates.TemplateResponse("problems.html", {
        "request": request,
        "user": user,
        "problems": problems,
        "solved_ids": solved_ids,
        "bookmarked_ids": bookmarked_ids,
        "topics": topics,
        "selected_difficulty": difficulty,
        "selected_topic": topic,
    })


@router.get("/problems/{slug}", response_class=HTMLResponse)
def problem_detail(slug: str, request: Request, contest: str = "", db: Session = Depends(get_db)):
    from app.services import contests as contest_svc
    user = get_current_user(request, db)
    problem = db.query(models.Problem).filter(models.Problem.slug == slug).first()
    if not problem:
        return RedirectResponse(url="/problems", status_code=303)

    contest_obj = None
    if contest:
        contest_obj = db.query(models.Contest).filter(models.Contest.slug == contest).first()
        if not contest_obj or not contest_svc.is_contest_problem(contest_obj, problem.id) \
                or contest_svc.status(contest_obj) == "upcoming":
            return RedirectResponse(url="/contests", status_code=303)
        if contest_svc.status(contest_obj) != "running":
            contest_obj = None          # contest over: practise mode
    elif not problem.is_published and not (user and user.is_staff):
        # Hidden (contest-only) problems unlock once every contest containing them has ended.
        links = db.query(models.ContestProblem).filter_by(problem_id=problem.id).all()
        if not links or any(contest_svc.status(l.contest) != "ended" for l in links):
            return RedirectResponse(url="/problems", status_code=303)

    sample_cases = [tc for tc in problem.test_cases if tc.is_sample]
    is_bookmarked = False
    if user:
        is_bookmarked = any(b.problem_id == problem.id for b in user.bookmarks)

    return templates.TemplateResponse("problem_detail.html", {
        "request": request,
        "user": user,
        "problem": problem,
        "sample_cases": sample_cases,
        "is_bookmarked": is_bookmarked,
        "contest": contest_obj,
        "contest_seconds_left": contest_svc.seconds_left(contest_obj) if contest_obj else 0,
        "hidden_count": len([t for t in problem.test_cases if not t.is_sample]),
    })


@router.post("/problems/{slug}/bookmark")
def toggle_bookmark(slug: str, request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)

    problem = db.query(models.Problem).filter(models.Problem.slug == slug).first()
    if not problem:
        return RedirectResponse(url="/problems", status_code=303)

    existing = db.query(models.Bookmark).filter(
        models.Bookmark.user_id == user.id, models.Bookmark.problem_id == problem.id
    ).first()
    if existing:
        db.delete(existing)
    else:
        db.add(models.Bookmark(user_id=user.id, problem_id=problem.id))
    db.commit()
    return RedirectResponse(url=f"/problems/{slug}", status_code=303)


@router.get("/bookmarks", response_class=HTMLResponse)
def bookmarks_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=303)
    problems = [b.problem for b in user.bookmarks]
    return templates.TemplateResponse("problems.html", {
        "request": request,
        "user": user,
        "problems": problems,
        "solved_ids": {s.problem_id for s in user.submissions if s.verdict == "Accepted"},
        "bookmarked_ids": {b.problem_id for b in user.bookmarks},
        "topics": [],
        "selected_difficulty": None,
        "selected_topic": None,
        "bookmarks_view": True,
    })
