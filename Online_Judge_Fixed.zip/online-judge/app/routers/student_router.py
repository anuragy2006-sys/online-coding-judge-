import asyncio

from fastapi import APIRouter, Request, Depends, UploadFile, File
from fastapi.responses import HTMLResponse, JSONResponse
from sqlalchemy.orm import Session

from app.database import get_db
from app.auth import get_current_user
from app.templating import templates
from app.services import file_import

router = APIRouter()

MAX_IMPORT_FILE_BYTES = 10 * 1024 * 1024  # 10MB -- generous for a screenshot/PDF, not for abuse


@router.get("/student", response_class=HTMLResponse)
def student_workspace(request: Request, db: Session = Depends(get_db)):
    """
    A free-form workspace: paste any code (not tied to a judge problem),
    run it with custom input, and get AI help — review, explain, optimize,
    fix errors, alternative solutions, and language conversion.
    Open to everyone; login is only needed to submit against judge problems.
    """
    user = get_current_user(request, db)
    return templates.TemplateResponse("student.html", {"request": request, "user": user})


@router.post("/student/import-pdf")
async def student_import_pdf(file: UploadFile = File(...)):
    data = await file.read()
    if len(data) > MAX_IMPORT_FILE_BYTES:
        return JSONResponse({"code": "", "error": "PDF is too large (max 10MB)."}, status_code=400)
    if not data:
        return JSONResponse({"code": "", "error": "Empty file."}, status_code=400)

    # Text extraction, and the scanned-PDF OCR fallback, both do real
    # CPU/subprocess/network work -- to_thread so this doesn't block every
    # other user's request while one PDF is being processed.
    result = await asyncio.to_thread(file_import.extract_code_from_pdf, data)
    if not result.code and result.warning:
        return JSONResponse({"code": "", "error": result.warning}, status_code=422)
    return JSONResponse({"code": result.code, "method": result.method, "warning": result.warning})


@router.post("/student/import-image")
async def student_import_image(file: UploadFile = File(...)):
    data = await file.read()
    if len(data) > MAX_IMPORT_FILE_BYTES:
        return JSONResponse({"code": "", "error": "Image is too large (max 10MB)."}, status_code=400)
    if not data:
        return JSONResponse({"code": "", "error": "Empty file."}, status_code=400)

    result = await asyncio.to_thread(file_import.extract_code_from_image, data, file.content_type or "image/png")
    if not result.code and result.warning:
        return JSONResponse({"code": "", "error": result.warning}, status_code=422)
    return JSONResponse({"code": result.code, "method": result.method, "warning": result.warning})
